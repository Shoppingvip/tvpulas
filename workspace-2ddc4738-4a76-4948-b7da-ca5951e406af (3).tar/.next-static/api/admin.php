<?php
// بەڕێوەبردنی دەسەڵاتی بەڕێوەبەر — وەشانێکی PHP ی src/app/api/admin/route.ts
require __DIR__ . '/lib.php';
handle_preflight();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// ---- GET — بارودۆخی بەڕێوەبەر ----
if ($method === 'GET') {
    try {
        $s = settings_row();
        json_out([
            'hasAdminPin' => !empty($s['adminPin']),
            'isAdmin'     => is_admin(),
        ]);
    } catch (Throwable $e) {
        json_out(['hasAdminPin' => false, 'isAdmin' => false]);
    }
}

// ---- POST — کردنەوەی دەسەڵات بە کۆد یان دروستکردنی کۆد بۆ یەکەم جار ----
if ($method === 'POST') {
    try {
        $body = body_json();
        $pin = trim_str($body['pin'] ?? '');
        if (!preg_match('/^\d{3,6}$/', $pin)) {
            json_out(['error' => 'کۆدەکە دەبێت ٣ بۆ ٦ ژمارە بێت'], 400);
        }

        $s = settings_row();

        if (empty($s['adminPin'])) {
            // یەکەم جارە — ئەم کۆدە دەبێت کۆدی بەڕێوەبەر (خاوەن ئەپەکە)
            turso_exec("UPDATE \"Settings\" SET \"adminPin\" = ?, \"updatedAt\" = " . sql_now() . " WHERE \"id\" = 'main'", [$pin]);
            set_admin_cookie($pin);
            json_out(['ok' => true, 'claimed' => true]);
        }

        if ($pin !== (string)$s['adminPin']) {
            json_out(['error' => 'کۆدی بەڕێوەبەر هەڵەیە'], 401);
        }

        set_admin_cookie($pin);
        json_out(['ok' => true, 'claimed' => false]);
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵەیەک ڕوویدا'], 500);
    }
}

// ---- DELETE — قوفڵکردنەوە (دەرچوونی بەڕێوەبەر) ----
if ($method === 'DELETE') {
    set_admin_cookie('');
    json_out(['ok' => true]);
}

json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
