<?php
// وێنە ڕیکلامییەکانی بەشی ماڵەوە — وەشانێکی PHP ی src/app/api/banner/route.ts
require __DIR__ . '/lib.php';
handle_preflight();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// ---- GET — بۆ هەمووان ----
if ($method === 'GET') {
    try {
        $items = turso_rows("SELECT \"id\", \"name\", \"data\" FROM \"Banner\" ORDER BY \"sortOrder\" ASC, \"createdAt\" ASC");
        json_out(['items' => $items]);
    } catch (Throwable $e) {
        json_out(['items' => []]);
    }
}

// ---- POST — زیادکردنی وێنە (تەنها بەڕێوەبەر) ----
if ($method === 'POST') {
    try {
        if (!is_admin()) forbidden();
        $body = body_json();
        $data = trim_str($body['data'] ?? '');

        // پشکنینی شێوەی وێنە — دەبێت data URL بێت
        if (!preg_match('/^data:image\/(png|jpe?g|webp|gif);base64,[A-Za-z0-9+\/=]+$/', $data)) {
            json_out(['error' => 'فایلەکە وێنە نییە (PNG، JPG، WEBP یان GIF)'], 400);
        }
        // سنووری قەبارە — ٢.٥ مێگابایت
        if (strlen($data) > 2500000) {
            json_out(['error' => 'قەبارەی وێنەکە زۆر گەورەیە — وێنەی بچووکتر هەڵبژێرە'], 400);
        }

        $name = trim_str($body['name'] ?? '');
        if (mb_strlen($name) > 100) $name = mb_substr($name, 0, 100);
        $count = (int)(turso_scalar("SELECT COUNT(*) FROM \"Banner\"") ?? 0);
        $id = cuid();
        turso_exec(
            "INSERT INTO \"Banner\" (\"id\", \"name\", \"data\", \"sortOrder\") VALUES (?, ?, ?, ?)",
            [$id, $name, $data, $count]
        );
        json_out(['ok' => true, 'id' => $id]);
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵەیەک ڕوویدا لە زیادکردنی وێنە'], 500);
    }
}

// ---- DELETE — سڕینەوەی وێنە (تەنها بەڕێوەبەر) ----
if ($method === 'DELETE') {
    try {
        if (!is_admin()) forbidden();
        $id = isset($_GET['id']) ? (string)$_GET['id'] : '';
        if ($id === 'ALL') {
            turso_exec("DELETE FROM \"Banner\"");
            json_out(['ok' => true]);
        }
        if ($id === '') json_out(['error' => 'ناسنامەی وێنە نەنێردرا'], 400);
        turso_exec("DELETE FROM \"Banner\" WHERE \"id\" = ?", [$id]);
        json_out(['ok' => true]);
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵەیەک ڕوویدا لە سڕینەوەی وێنە'], 500);
    }
}

json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
