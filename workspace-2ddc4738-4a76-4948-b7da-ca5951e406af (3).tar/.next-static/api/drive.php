<?php
// بەڕێوەبردنی فلیمەکانی Google Drive — وەشانێکی PHP ی src/app/api/drive/route.ts + src/lib/drive.ts
require __DIR__ . '/lib.php';
handle_preflight();

const DRIVE_FILE_EXTS = '/\.(mp4|mkv|avi|mov|webm|m4v|mpg|mpeg|ts|flv|wmv|3gp|ogv|mts|m2ts)$/i';

function drive_stream_url(string $fileId): string
{
    return 'https://drive.usercontent.google.com/download?id=' . rawurlencode($fileId) . '&export=download&confirm=t';
}

function drive_thumb_url(string $fileId, int $size = 400): string
{
    return 'https://drive.google.com/thumbnail?id=' . rawurlencode($fileId) . '&sz=w' . $size;
}

function decode_entities(string $s): string
{
    return str_replace(
        ['&amp;', '&lt;', '&gt;', '&quot;', '&#39;', '&nbsp;'],
        ['&', '<', '>', '"', "'", ' '],
        $s
    );
}

function clean_movie_name(string $fileName): string
{
    $n = preg_replace(DRIVE_FILE_EXTS, '', $fileName);
    $n = preg_replace('/_+/', ' ', (string)$n);
    $n = preg_replace('/\.{2,}/', '.', (string)$n);
    $n = preg_replace('/\s+/', ' ', (string)$n);
    $n = trim((string)$n);
    return $n !== '' ? $n : $fileName;
}

// ناسنامەی فایل لە هەر شێوەیەکی بەستەری Drive
function extract_file_id(string $url): ?string
{
    if (preg_match('/[?&]id=([\w-]{10,})/', $url, $m)) return $m[1];
    if (preg_match('/\/file\/d\/([\w-]{10,})/', $url, $m)) return $m[1];
    if (preg_match('/\/download\/([\w-]{10,})/', $url, $m)) return $m[1];
    return null;
}

function extract_folder_id(string $url): ?string
{
    if (preg_match('/\/folders\/([\w-]{10,})/', $url, $m)) return $m[1];
    return null;
}

function extract_drive_id(string $link): ?array
{
    $fid = extract_folder_id($link);
    if ($fid !== null) return ['type' => 'folder', 'id' => $fid];
    $fid = extract_file_id($link);
    if ($fid !== null) return ['type' => 'file', 'id' => $fid];
    return null;
}

// ناوی ڕەسەنی فایلەکە لە پەڕەی Drive وەردەگرێت — «NAME - Google Drive»
function fetch_title(string $fileId): ?string
{
    $r = http_get('https://drive.google.com/file/d/' . rawurlencode($fileId) . '/view', 20, [
        'Accept' => 'text/html,*/*',
        'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
    ]);
    if ($r['status'] < 200 || $r['status'] >= 300) return null;
    if (!preg_match('/<title>([^<]+)<\/title>/i', $r['body'], $m)) return null;
    $t = trim($m[1]);
    if (preg_match('/sign in|google accounts|چوونەژوورەوە/i', $t)) return null;
    $decoded = trim(decode_entities($t));
    // دوا « - » دەدۆزینەوە و بەشی پێش ئەوە ناوی فایلەکەیە
    foreach ([' - ', ' – ', ' — '] as $sep) {
        $i = strrpos($decoded, $sep);
        if ($i !== false && $i > 0 && preg_match('/google/i', substr($decoded, $i + strlen($sep)))) {
            $name = trim(substr($decoded, 0, $i));
            return $name !== '' ? $name : null;
        }
    }
    return $decoded !== '' ? $decoded : null;
}

// پشکنینی دەستگەیشتنی گشتی فایلەکە — تەنها یەک بایت (Range: 0-0)
function verify_file_public(string $fileId): void
{
    $r = http_get(drive_stream_url($fileId), 20, ['Range' => 'bytes=0-0']);
    if (!empty($r['error'])) throw new RuntimeException(net_msg($r));
    if ($r['status'] === 404) {
        throw new RuntimeException('فایلەکە نەدۆزرایەوە — لەوانەیە سڕدرابێتەوە یان بەستەرەکە هەڵە بێت');
    }
    if ($r['status'] === 403 || $r['status'] === 401 || preg_match('/accounts\.google\.com/i', $r['final_url'])) {
        throw new RuntimeException('فایلەکە گشتی نییە — لە Drive بیبەرەوە بە «هەر کەسێک بە بەستەر»');
    }
    if (($r['status'] < 200 || $r['status'] >= 300) && $r['status'] !== 206) {
        throw new RuntimeException('فایلەکە وەڵام نەدایەوە — دووبارە هەوڵ بدە');
    }
}

// ---- ڕێگای ١ — Google Drive API v3 (پێویستی بە API Key هەیە) ----
function list_folder_via_api(string $folderId, string $apiKey): array
{
    $listUrl = 'https://www.googleapis.com/drive/v3/files?q=' . rawurlencode("'" . $folderId . "' in parents and trashed = false") .
        '&fields=' . rawurlencode('nextPageToken,files(id,name,size,thumbnailLink,mimeType)') .
        '&pageSize=200&key=' . rawurlencode($apiKey);
    $r = http_get($listUrl, 30);
    if (!empty($r['error'])) throw new RuntimeException(net_msg($r));
    if ($r['status'] === 403 || $r['status'] === 400) {
        throw new RuntimeException('کلیلی API ەکە کار ناکات یان سنووردارە — پشکنینی بکە یان بیبەسەر بکە');
    }
    if ($r['status'] === 404) throw new RuntimeException('فۆڵدەرەکە نەدۆزرایەوە — بەستەرەکە پشکنین بکە');
    if ($r['status'] < 200 || $r['status'] >= 300) throw new RuntimeException('Google Drive وەڵام نەدایەوە — دووبارە هەوڵ بدە');

    $data = json_decode($r['body'], true);
    $files = [];
    foreach ((is_array($data) && isset($data['files']) && is_array($data['files']) ? $data['files'] : []) as $f) {
        $isVideo = preg_match(DRIVE_FILE_EXTS, (string)($f['name'] ?? '')) || preg_match('/video\//i', (string)($f['mimeType'] ?? ''));
        if (!$isVideo) continue;
        $files[] = [
            'id'        => (string)$f['id'],
            'name'      => (string)($f['name'] ?? ''),
            'thumbnail' => isset($f['thumbnailLink']) ? (string)$f['thumbnailLink'] : null,
            'size'      => isset($f['size']) ? (string)$f['size'] : null,
        ];
    }

    // ناوی فۆڵدەرەکە
    $folderName = 'Google Drive';
    $nr = http_get('https://www.googleapis.com/drive/v3/files/' . rawurlencode($folderId) . '?fields=name&key=' . rawurlencode($apiKey), 15);
    if ($nr['status'] >= 200 && $nr['status'] < 300) {
        $nd = json_decode($nr['body'], true);
        if (is_array($nd) && !empty($nd['name'])) {
            $folderName = mb_substr((string)$nd['name'], 0, 60);
        }
    }
    return ['folderName' => $folderName, 'files' => $files];
}

// ---- ڕێگای ٢ — embeddedfolderview (بێ API Key — بۆ فۆڵدەری گشتی) ----
function list_folder_embedded(string $folderId): array
{
    $url = 'https://drive.google.com/embeddedfolderview?id=' . rawurlencode($folderId) . '#list';
    $r = http_get($url, 30, [
        'Accept' => 'text/html,*/*',
        'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
    ]);
    if (!empty($r['error'])) throw new RuntimeException(net_msg($r));
    if ($r['status'] === 404) throw new RuntimeException('فۆڵدەرەکە نەدۆزرایەوە — بەستەرەکە پشکنین بکە');
    if ($r['status'] === 403 || $r['status'] === 401) {
        throw new RuntimeException('فۆڵدەرەکە گشتی نییە — لە Drive بیبەرەوە بە «هەر کەسێک بە بەستەر»');
    }
    if ($r['status'] < 200 || $r['status'] >= 300) {
        throw new RuntimeException('فۆڵدەرەکە وەڵام نەدایەوە — دووبارە هەوڵ بدە');
    }
    $html = $r['body'];

    // فۆڵدەری تایبەت — پەڕەی چوونەژوورەوە دەگەڕێتەوە
    if (preg_match('/accounts\.google\.com\/(ServiceLogin|v3\/signin)/i', $html)) {
        throw new RuntimeException('فۆڵدەرەکە گشتی نییە — لە Drive بیبەرەوە بە «هەر کەسێک بە بەستەر»');
    }

    $folderName = 'Google Drive';
    if (preg_match('/<title>(?:Google Drive[^—-]*[—-]\s*)?([^<]+)<\/title>/i', $html, $m)) {
        $t = trim(decode_entities($m[1]));
        if ($t !== '') $folderName = $t;
    }

    // هەر تۆمارێک: <div class="flip-entry" id="entry-FILE_ID" ...> ... <div class="flip-entry-title">NAME</div>
    $files = [];
    if (preg_match_all('/<div class="flip-entry" id="entry-([\w-]+)"([\s\S]*?)<div class="flip-entry-title">([\s\S]*?)<\/div>/', $html, $ms, PREG_SET_ORDER)) {
        foreach ($ms as $m) {
            $fileId = $m[1];
            $block = $m[2];
            $name = trim(decode_entities($m[3]));
            if (!preg_match(DRIVE_FILE_EXTS, $name)) continue; // تەنها فایلی ڤیدیۆ
            $thumb = preg_match('/src="(https:\/\/drive\.google\.com\/thumbnail[^"]+)"/', $block, $tm) ? $tm[1] : null;
            $files[] = ['id' => $fileId, 'name' => $name, 'thumbnail' => $thumb, 'size' => null];
        }
    }

    if (count($files) === 0) {
        throw new RuntimeException('هیچ فایلێکی ڤیدیۆ لەم فۆڵدەرەدا نەدۆزرایەوە');
    }

    $folderName = trim(decode_entities($folderName));
    if (mb_strlen($folderName) > 60) $folderName = mb_substr($folderName, 0, 60);
    if ($folderName === '') $folderName = 'Google Drive';
    return ['folderName' => $folderName, 'files' => $files];
}

function list_folder_videos(string $folderId, ?string $apiKey): array
{
    if ($apiKey !== null && $apiKey !== '') {
        try {
            $r = list_folder_via_api($folderId, $apiKey);
            if (count($r['files']) > 0) return $r;
            // ئەگەر بە کلیل هیچ نەدۆزرایەوە — بە embeddedfolderview تاقی بکەرەوە
        } catch (Throwable $e) {
            // کەوتە خوارەوە
        }
    }
    return list_folder_embedded($folderId);
}

// ─────────────────────────────── endpoint ───────────────────────────────

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// ---- GET — خوێندنەوەی هەموو فلیمەکان (بۆ هەمووان) ----
if ($method === 'GET') {
    try {
        ensure_schema();
        $items = turso_rows("SELECT * FROM \"DriveVideo\" ORDER BY \"sortOrder\" ASC, \"createdAt\" ASC");
        $s = turso_one("SELECT \"driveApiKey\" FROM \"Settings\" WHERE \"id\" = 'main'");
        $hasKey = $s ? !empty($s['driveApiKey']) : false;
        json_out(['items' => $items, 'hasKey' => $hasKey]);
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵە لە خوێندنەوەی فلیمەکانی Drive'], 500);
    }
}

// ---- POST — زیادکردن ----
if ($method === 'POST') {
    try {
        if (!is_admin()) forbidden();
        $body = body_json();

        // ---- پاشەکەوتکردنی کلیلی API ----
        if (($body['action'] ?? '') === 'save-key') {
            $key = trim_null($body['apiKey'] ?? null);
            ensure_schema();
            turso_exec(
                "INSERT INTO \"Settings\" (\"id\", \"driveApiKey\", \"updatedAt\") VALUES ('main', ?, " . sql_now() . ") " .
                "ON CONFLICT(\"id\") DO UPDATE SET \"driveApiKey\" = excluded.\"driveApiKey\", \"updatedAt\" = " . sql_now(),
                [$key]
            );
            json_out(['ok' => true, 'hasKey' => $key !== null]);
        }

        $link = trim_str($body['link'] ?? '');
        if ($link === '') json_out(['error' => 'داواکارییەکە بەتاڵە'], 400);

        $parsed = extract_drive_id($link);
        if ($parsed === null) {
            json_out(['error' => 'بەستەرەکە نەناسرا — تکایە بەستەری هاوبەشی فایل یان فۆڵدەر دابنێ (Share → Copy link)'], 400);
        }

        // ---- هێنانی فلیمەکانی فۆڵدەر ----
        if ($parsed['type'] === 'folder') {
            ensure_schema();
            $s = turso_one("SELECT \"driveApiKey\" FROM \"Settings\" WHERE \"id\" = 'main'");
            $apiKey = ($s && !empty($s['driveApiKey'])) ? (string)$s['driveApiKey'] : null;
            $res = list_folder_videos($parsed['id'], $apiKey);

            // ئەوانەی پێشتر هەن فەرامۆش بکە — تەنها نوێیان زیاد بکە
            $existing = [];
            foreach (turso_rows("SELECT \"fileId\" FROM \"DriveVideo\"") as $row) {
                $existing[(string)$row['fileId']] = true;
            }
            $max = (int)(turso_scalar("SELECT MAX(\"sortOrder\") FROM \"DriveVideo\"") ?? -1);
            $order = $max + 1;
            $fresh = [];
            foreach ($res['files'] as $f) {
                if (!isset($existing[(string)$f['id']])) $fresh[] = $f;
            }

            $stmts = [];
            foreach ($fresh as $f) {
                $thumb = $f['thumbnail'] !== null ? $f['thumbnail'] : drive_thumb_url((string)$f['id']);
                $folderName = $res['folderName'] !== null ? $res['folderName'] : 'Google Drive';
                $stmts[] = [
                    'sql'  => "INSERT INTO \"DriveVideo\" (\"id\", \"fileId\", \"name\", \"folderId\", \"folderName\", \"thumbnail\", \"size\", \"sortOrder\") VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    'args' => [cuid(), (string)$f['id'], mb_substr(clean_movie_name((string)$f['name']), 0, 120), $parsed['id'], mb_substr($folderName, 0, 60), $thumb, $f['size'], $order++],
                ];
            }
            // بە پارچە نێردەبن — بۆ فۆڵدەری گەورە
            foreach (array_chunk($stmts, 40) as $chunk) {
                turso_pipeline($chunk);
            }

            json_out([
                'ok'         => true,
                'kind'       => 'folder',
                'imported'   => count($fresh),
                'folderName' => $res['folderName'] !== null ? $res['folderName'] : 'Google Drive',
            ]);
        }

        // ---- زیادکردنی فلیمی تاک ----
        ensure_schema();
        $fid = (string)$parsed['id'];

        // پشکنین — فایلەکە بە گشتی بەشکراوە؟
        verify_file_public($fid);

        $dup = turso_one("SELECT \"name\" FROM \"DriveVideo\" WHERE \"fileId\" = ?", [$fid]);
        if ($dup) {
            json_out(['error' => '«' . (string)$dup['name'] . '» پێشتر زیادکراوە'], 409);
        }

        // ناوی ڕەسەنی فایلەکە — ئەگەر نەکرا ناوی گشتی
        $realName = fetch_title($fid);
        $max = (int)(turso_scalar("SELECT MAX(\"sortOrder\") FROM \"DriveVideo\"") ?? -1);
        $name = $realName !== null ? clean_movie_name($realName) : 'فلیمی Drive';
        $id = cuid();
        turso_exec(
            "INSERT INTO \"DriveVideo\" (\"id\", \"fileId\", \"name\", \"thumbnail\", \"sortOrder\") VALUES (?, ?, ?, ?, ?)",
            [$id, $fid, mb_substr($name, 0, 120), drive_thumb_url($fid), $max + 1]
        );
        json_out(['ok' => true, 'kind' => 'file', 'id' => $id, 'name' => mb_substr($name, 0, 120)]);
    } catch (Throwable $e) {
        $msg = $e->getMessage();
        json_out(['error' => $msg !== '' ? $msg : 'نەکرا فلیمەکە زیاد بکرێت'], 500);
    }
}

// ---- DELETE — سڕینەوە ----
if ($method === 'DELETE') {
    try {
        if (!is_admin()) forbidden();
        ensure_schema();
        $id = isset($_GET['id']) ? (string)$_GET['id'] : '';
        $folderId = isset($_GET['folderId']) ? (string)$_GET['folderId'] : '';
        if ($folderId !== '') {
            turso_exec("DELETE FROM \"DriveVideo\" WHERE \"folderId\" = ?", [$folderId]);
            json_out(['ok' => true]);
        }
        if ($id === '') json_out(['error' => 'ناسنامە نەنێردرا'], 400);
        turso_exec("DELETE FROM \"DriveVideo\" WHERE \"id\" = ?", [$id]);
        json_out(['ok' => true]);
    } catch (Throwable $e) {
        json_out(['error' => 'نەکرا بسڕدرێتەوە'], 500);
    }
}

json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
