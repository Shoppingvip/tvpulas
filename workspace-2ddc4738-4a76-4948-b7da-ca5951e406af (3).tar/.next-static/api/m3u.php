<?php
// شیکەرەوەی M3U — وەشانێکی PHP ی src/app/api/m3u/route.ts + src/lib/m3u.ts
require __DIR__ . '/lib.php';
handle_preflight();

const M3U_AGG_TTL = 300; // ٥ خولەک

function fetch_all_sources(array $sources): array
{
    $live = [];
    $movie = [];
    $all = [];
    $firstError = null;

    foreach ($sources as $src) {
        $r = http_get((string)$src['url'], 60);
        if (!empty($r['error'])) {
            if ($firstError === null) $firstError = net_msg($r);
            continue;
        }
        if ($r['status'] < 200 || $r['status'] >= 300) {
            if ($firstError === null) $firstError = 'لیستەکە وەڵام نەدایەوە';
            continue;
        }
        $text = $r['body'];
        if (strpos($text, '#EXTM3U') === false) {
            if ($firstError === null) $firstError = 'فایلەکە لیستی M3U نییە';
            continue;
        }
        foreach (parse_m3u($text) as $ch) {
            $tagged = $ch;
            $tagged['srcSection'] = (string)$src['section'];
            $all[] = $tagged;
            $sec = (string)$src['section'];
            if ($sec === 'both') {
                // لیستی (هەردووکیان) — بەپێی جۆری خۆکارانە دابەش دەبێت
                if ($ch['kind'] === 'live') $live[] = $tagged;
                else $movie[] = $tagged;
            } elseif ($sec === 'live') {
                $live[] = $tagged;
            } else {
                $movie[] = $tagged;
            }
        }
    }

    return [
        'bySection' => ['live' => $live, 'movie' => $movie, 'all' => $all],
        'error'     => $firstError,
    ];
}

function aggregate_channels(): array
{
    $sources = list_sources();

    // ئەگەر هیچ سەرچاوەیەک نییە بەڵام Xtream هەیە — بەستەری get.php بەکاربهێنە
    if (count($sources) === 0) {
        $s = settings_row();
        if (!empty($s['xtreamHost']) && !empty($s['xtreamUsername']) && !empty($s['xtreamPassword'])) {
            $url = rtrim((string)$s['xtreamHost'], '/') .
                '/get.php?username=' . rawurlencode((string)$s['xtreamUsername']) .
                '&password=' . rawurlencode((string)$s['xtreamPassword']) .
                '&type=m3u_plus&output=ts';
            $sources[] = ['id' => 'xtream', 'name' => 'Xtream', 'url' => $url, 'section' => 'both', 'sortOrder' => 0];
        }
    }

    $fp = implode(';;', array_map(function ($s) {
        return $s['id'] . '|' . $s['url'] . '|' . $s['section'];
    }, $sources));

    $cached = cache_get('m3u-agg');
    if ($cached !== null && is_array($cached['data'] ?? null) && (($cached['data']['fp'] ?? '') === $fp)) {
        if (time() - (int)($cached['at'] ?? 0) < M3U_AGG_TTL) {
            return ['bySection' => $cached['data']['bySection'], 'error' => null];
        }
    }

    $fresh = fetch_all_sources($sources);
    // تەنها کاشی بکە ئەگەر داتای دروست هەبوو — هەڵەی تۆڕ کاش نەکە
    if (!($fresh['error'] !== null && count($fresh['bySection']['all']) === 0)) {
        cache_set('m3u-agg', ['fp' => $fp, 'bySection' => $fresh['bySection']]);
    }
    return $fresh;
}

function pick_list(array $bySection, $section, $kind): array
{
    if ($section === 'live' || $section === 'movie') return $bySection[$section];
    if ($kind === 'live') return $bySection['live'];
    if ($kind === 'movie') return $bySection['movie'];
    return $bySection['all'];
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// ---- GET — گروپەکان — ?section=live یان movie ----
if ($method === 'GET') {
    try {
        $section = isset($_GET['section']) ? (string)$_GET['section'] : '';
        $agg = aggregate_channels();
        $list = pick_list($agg['bySection'], $section, null);

        if (count($list) === 0 && $agg['error'] !== null) {
            json_out(['error' => $agg['error']], 502);
        }

        $counts = [];
        foreach ($list as $c) {
            $g = (string)$c['group'];
            $counts[$g] = (isset($counts[$g]) ? $counts[$g] : 0) + 1;
        }
        arsort($counts);
        $groups = [];
        foreach ($counts as $name => $cnt) {
            $groups[] = ['name' => $name, 'count' => $cnt];
        }
        json_out(['groups' => $groups, 'total' => count($list)]);
    } catch (Throwable $e) {
        $msg = $e->getMessage();
        json_out(['error' => $msg !== '' ? $msg : 'هەڵە لە خوێندنەوەی لیست'], 502);
    }
}

// ---- POST — کەناڵەکانی گروپێک + گەڕان ----
if ($method === 'POST') {
    try {
        $body = body_json();
        $agg = aggregate_channels();
        $list = pick_list($agg['bySection'], $body['section'] ?? null, $body['kind'] ?? null);

        $group = trim_str($body['group'] ?? '');
        if ($group !== '' && $group !== 'all') {
            $filtered = [];
            foreach ($list as $c) if ($c['group'] === $group) $filtered[] = $c;
            $list = $filtered;
        }
        $search = trim_str($body['search'] ?? '');
        if ($search !== '') {
            $q = mb_strtolower($search);
            $filtered = [];
            foreach ($list as $c) {
                if (strpos(mb_strtolower((string)$c['name']), $q) !== false) $filtered[] = $c;
            }
            $list = $filtered;
        }

        // کورتکردنەوە بۆ شێوەی کەناڵی ئاسایی — srcSection دەڕووێنرێتەوە
        $channels = [];
        foreach ($list as $c) {
            unset($c['srcSection']);
            $channels[] = $c;
        }
        $limit = (int)($body['limit'] ?? 400);
        if ($limit <= 0) $limit = 400;
        if ($limit > 1000) $limit = 1000;
        json_out([
            'channels' => array_slice($channels, 0, $limit),
            'total'    => count($channels),
        ]);
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵەیەک ڕوویدا'], 500);
    }
}

json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
