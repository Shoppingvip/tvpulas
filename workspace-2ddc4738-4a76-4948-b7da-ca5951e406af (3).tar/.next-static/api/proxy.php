<?php
// پرۆکسی پەخش و وێنەکان — چارەسەری CORS و Mixed Content
// وەشانێکی PHP ی src/app/api/proxy/route.ts
// تێبینی: لە InfinityFree پەخشی قورس بە پرۆکسی پێشنیار نەکراوە — بە zۆری
// پەخشەکان ڕاستەوخۆ لە کلاینتەوە کار دەکەن و ئەمە تەنها فەلباکە.
require __DIR__ . '/lib.php';
handle_preflight();

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
}

$target = isset($_GET['url']) ? (string)$_GET['url'] : '';
if ($target === '' || !preg_match('/^https?:\/\//i', $target)) {
    json_out(['error' => 'بەستەری دروست نییە'], 400);
}

$isImgParam = (isset($_GET['k']) && $_GET['k'] === 'img');
$looksManifest = preg_match('/\.m3u8(\?|$)/i', $target) ? 1 : 0;
$cfg = iptv_config();

// ئەگەر پەخش بە پرۆکسی ناچالاک بێت — تەنها وێنە و لیستی HLS ڕێگەپێدراون
if (!$isImgParam && !$looksManifest && ($cfg['proxy_streams'] ?? true) === false) {
    json_out(['error' => 'پەخش بە پرۆکسی ناچالاکە — لە فایلی api/config.php بگۆڕە'], 403);
}

$ch = curl_init($target);
$hdrs = ['Accept: */*'];
if (isset($_SERVER['HTTP_RANGE']) && $_SERVER['HTTP_RANGE'] !== '') {
    $hdrs[] = 'Range: ' . $_SERVER['HTTP_RANGE'];
}

$respHeaders = [];
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER     => $hdrs,
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_TIMEOUT        => 300,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS      => 6,
    // سنووری بیرگە — پارچە گەورەکان بە Range دێن، بەڵام بۆ ئاسوودەیی سنوور دانراوە
    CURLOPT_MAXFILESIZE    => 33554432, // ٣٢ مێگابایت
    CURLOPT_HEADERFUNCTION => function ($ch, $line) use (&$respHeaders) {
        $respHeaders[] = trim($line);
        return strlen($line);
    },
]);

$res = curl_exec($ch);
if ($res === false) {
    $err = curl_error($ch);
    curl_close($ch);
    json_out(['error' => net_msg(['error' => $err])], 502);
}
$code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
$ct = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
$finalUrl = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
$length = (int)curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
curl_close($ch);

// دۆزینەوەی جۆرەکە
$isManifest = strpos($ct, 'mpegurl') !== false || strpos($ct, 'vnd.apple') !== false || $looksManifest === 1;
$isImage = $isImgParam || preg_match('/^image\//i', $ct);

header('Access-Control-Allow-Origin: *');

// ---- لیستی HLS — بەستەرەکان بۆ پرۆکسی دەگۆڕدرێن ----
if ($isManifest && $code >= 200 && $code < 300) {
    header('Content-Type: application/vnd.apple.mpegurl');
    header('Cache-Control: no-store');
    http_response_code(200);
    echo rewrite_manifest_text((string)$res, $finalUrl !== '' ? $finalUrl : $target);
    exit;
}

// ---- پارچە، وێنە و فایلەکان — ڕاپەکردنی ڕاستەوخۆ ----
header('Content-Type: ' . ($ct !== '' ? $ct : 'application/octet-stream'));
header('Cache-Control: ' . ($isImage && $code >= 200 && $code < 300 ? 'public, max-age=604800, immutable' : 'no-store'));

foreach ($respHeaders as $h) {
    if (preg_match('/^accept-ranges:\s*(.+)$/i', $h, $m)) header('Accept-Ranges: ' . trim($m[1]));
    if (preg_match('/^content-range:\s*(.+)$/i', $h, $m)) header('Content-Range: ' . trim($m[1]));
}
// تەنها کاتێک Content-Length بنێرە کە ناوەڕۆک پەستێوراو نەبێت
$hasEncoding = false;
foreach ($respHeaders as $h) {
    if (preg_match('/^content-encoding:/i', $h)) { $hasEncoding = true; break; }
}
if (!$hasEncoding && $length > 0) header('Content-Length: ' . $length);

http_response_code($code);
echo $res;
exit;

// ─────────────────────────────── یارمەتیدەرەکان ───────────────────────────────

function proxied_url(string $u): string
{
    return '/api/proxy?url=' . rawurlencode($u);
}

// هاوشێوەی new URL(uri, base) لە JavaScript
function absolutize(string $base, string $uri): string
{
    if (preg_match('/^https?:\/\//i', $uri)) return $uri;
    $p = parse_url($base);
    if (!isset($p['scheme']) || !isset($p['host'])) return $uri;
    if ($uri !== '' && $uri[0] === '/') {
        return $p['scheme'] . '://' . $p['host'] . $uri;
    }
    $path = isset($p['path']) ? $p['path'] : '/';
    $dir = preg_replace('/\/[^\/]*$/', '/', $path);
    return $p['scheme'] . '://' . $p['host'] . $dir . $uri;
}

function rewrite_manifest_text(string $text, string $base): string
{
    $lines = preg_split('/\r?\n/', $text);
    $out = [];
    if (!is_array($lines)) return $text;
    foreach ($lines as $line) {
        $t = trim($line);
        if ($t === '') { $out[] = $line; continue; }
        if ($t[0] === '#') {
            $line = preg_replace_callback('/URI="([^"]+)"/', function ($m) use ($base) {
                return 'URI="' . proxied_url(absolutize($base, $m[1])) . '"';
            }, $line);
            $line = preg_replace_callback("/URI='([^']+)'/", function ($m) use ($base) {
                return "URI='" . proxied_url(absolutize($base, $m[1])) . "'";
            }, $line);
            $out[] = $line;
        } else {
            $out[] = proxied_url(absolutize($base, $t));
        }
    }
    return implode("\n", $out);
}
