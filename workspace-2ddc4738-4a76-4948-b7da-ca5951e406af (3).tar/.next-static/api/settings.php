<?php
// ڕێکخستنەکانی ئەپ — وەشانێکی PHP ی src/app/api/settings/route.ts
require __DIR__ . '/lib.php';
handle_preflight();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// ---- GET — زانیاری ڕێکخستنەکان (بەبێ نهێنییەکان) ----
if ($method === 'GET') {
    try {
        json_out(build_status(is_admin()));
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵە لە خوێندنەوەی ڕێکخستنەکان'], 500);
    }
}

// ---- POST — پاشەکەوتکردنی زانیارییەکان ----
if ($method === 'POST') {
    try {
        $body = body_json();
        $current = settings_row();

        // پاراستن — تەنها بەڕێوەبەر دەتوانێت زانیارییەکان بگۆڕێت
        // بەڵام ئەگەر هێشتا کۆدی بەڕێوەبەر دانەنراوە (یەکەم جارە) — ئازادە
        if (!empty($current['adminPin']) && !is_admin()) forbidden();

        $adminPin = trim_str($body['adminPin'] ?? '');
        if ($adminPin !== '' && !preg_match('/^\d{3,6}$/', $adminPin)) {
            json_out(['error' => 'کۆدی بەڕێوەبەر دەبێت ٣ بۆ ٦ ژمارە بێت'], 400);
        }

        $host     = trim_null($body['xtreamHost'] ?? null);
        $username = trim_null($body['xtreamUsername'] ?? null);
        $password = trim_null($body['xtreamPassword'] ?? null);
        $m3uUrl   = trim_null($body['m3uUrl'] ?? null);

        $usingXtream = ($host !== null && $username !== null && $password !== null);
        $usingM3u    = ($m3uUrl !== null);

        if (!$usingXtream && !$usingM3u) {
            json_out(['error' => 'تکایە زانیارییەکانی Xtream یان بەستەری M3U داخڵ بکە'], 400);
        }

        // پشکنینی بەستەر
        $info = null;
        if ($usingXtream) {
            $info = test_xtream((string)$host, (string)$username, (string)$password);
        } elseif ($m3uUrl !== null) {
            $r = http_get($m3uUrl, 25);
            if (!empty($r['error'])) throw new RuntimeException(net_msg($r));
            if ($r['status'] < 200 || $r['status'] >= 300) throw new RuntimeException('بەستەری M3U وەڵام نەدایەوە');
            if (strpos($r['body'], '#EXTM3U') === false) throw new RuntimeException('فایلەکە لیستی M3U نییە');
        }

        $appName   = trim_str($body['appName'] ?? '');
        if ($appName === '') $appName = 'تیڤی ئەپی من';
        // کۆدی بەڕێوەبەر تەنها لە یەکەم جار دادەنرێت
        $pinUpdate = (empty($current['adminPin']) && $adminPin !== '') ? $adminPin : null;

        turso_exec(
            "UPDATE \"Settings\" SET \"appName\" = ?, \"xtreamHost\" = ?, \"xtreamUsername\" = ?, \"xtreamPassword\" = ?, \"m3uUrl\" = ?, \"updatedAt\" = " . sql_now() . " WHERE \"id\" = 'main'",
            [$appName, $usingXtream ? $host : null, $usingXtream ? $username : null, $usingXtream ? $password : null, $usingXtream ? null : $m3uUrl]
        );
        if ($pinUpdate !== null) {
            turso_exec("UPDATE \"Settings\" SET \"adminPin\" = ? WHERE \"id\" = 'main'", [$pinUpdate]);
        }

        // لیستی سەرەکی M3U — سەرچاوەکانی (هەردووکیان) بە لیستە نوێیەکە دەگوازرێنەوە
        if ($usingM3u && $m3uUrl !== null) {
            turso_exec("DELETE FROM \"M3uSource\" WHERE \"section\" = 'both'");
            $c = turso_one("SELECT COUNT(*) AS n FROM \"M3uSource\"");
            turso_exec(
                "INSERT INTO \"M3uSource\" (\"id\", \"name\", \"url\", \"section\", \"sortOrder\") VALUES (?, 'لیستی سەرەکی', ?, 'both', ?)",
                [cuid(), $m3uUrl, (int)($c ? $c['n'] : 0)]
            );
        }

        json_out([
            'ok'                => true,
            'expiryDate'        => $info ? $info['expiryDate'] : null,
            'activeConnections' => $info ? $info['activeConnections'] : null,
            'maxConnections'    => $info ? $info['maxConnections'] : null,
            'status'            => $info ? $info['status'] : null,
        ]);
    } catch (Throwable $e) {
        $msg = $e->getMessage();
        json_out(['error' => $msg !== '' ? $msg : 'هەڵەیەکی نەزانراو ڕوویدا'], 400);
    }
}

json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
