<?php
// پرۆکسی بۆ APIی Xtream Codes — وەشانێکی PHP ی src/app/api/xtream/route.ts
require __DIR__ . '/lib.php';
handle_preflight();

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
}

try {
    $s = settings_row();
    if (empty($s['xtreamHost']) || empty($s['xtreamUsername']) || empty($s['xtreamPassword'])) {
        json_out(['error' => 'سەرەتا زانیارییەکان دابنێ'], 400);
    }

    $body = body_json();
    $action = trim_str($body['action'] ?? '');
    $ttl = ttl_for_action($action);
    $key = null;
    if ($ttl !== null) {
        $key = 'xtream|' . $action . '|' . trim_str($body['categoryId'] ?? '') . '|' . trim_str($body['id'] ?? '') . '|' . trim_str($body['limit'] ?? '');
        $hit = cache_get($key);
        if ($hit !== null && time() - (int)($hit['at'] ?? 0) < $ttl) {
            json_out($hit['data']);
        }
    }

    $base = rtrim((string)$s['xtreamHost'], '/');
    $params = [
        'username' => (string)$s['xtreamUsername'],
        'password' => (string)$s['xtreamPassword'],
    ];
    if ($action !== '') $params['action'] = $action;
    if (!empty($body['categoryId'])) $params['category_id'] = (string)$body['categoryId'];
    if (!empty($body['id'])) {
        if ($action === 'get_series_info') $params['series_id'] = (string)$body['id'];
        elseif ($action === 'get_vod_info') $params['vod_id'] = (string)$body['id'];
        else $params['stream_id'] = (string)$body['id'];
    }
    if (!empty($body['limit'])) $params['limit'] = (string)(int)$body['limit'];

    $r = http_get($base . '/player_api.php?' . http_build_query($params), 20);
    if (!empty($r['error'])) throw new RuntimeException(net_msg($r));
    if ($r['status'] < 200 || $r['status'] >= 300) throw new RuntimeException('سێرڤەر وەڵام نەدایەوە');
    $data = json_decode($r['body'], true);
    if (!is_array($data)) throw new RuntimeException('وەڵامی سێرڤەر دروست نییە');

    if ($key !== null) cache_set($key, $data);
    json_out($data);
} catch (Throwable $e) {
    $msg = $e->getMessage();
    json_out(['error' => $msg !== '' ? $msg : 'پەیوەندی نەکرا'], 502);
}
