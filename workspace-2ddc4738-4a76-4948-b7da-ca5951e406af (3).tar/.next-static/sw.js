// سێرڤیس وۆرکەری سادە — تەنها بۆ کردنەوەی ئەپ بە شێوەی ئەپ (PWA)
// هیچی کاش ناکات — هەمیشە لە تۆڕەوە، بۆ ئەوەی پەخشەکان هەمیشە تازە بن
const CACHE = "iptv-shell-v2";
const ASSETS = ["/", "/manifest.webmanifest", "/icon-192.png", "/icon-512.png"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// تۆڕ-سەرەتا: ئەگەر تۆڕ هەبوو ڕاستەوخۆ لە تۆڕەوە، ئەگەر نەبوو لە کاش
self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== self.location.origin) return;
  if (url.pathname.startsWith("/api/")) return; // API هەمیشە لە تۆڕەوە

  e.respondWith(
    fetch(e.request)
      .then((res) => {
        if (res.ok && (e.request.mode === "navigate" || ASSETS.includes(url.pathname))) {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(e.request, copy));
        }
        return res;
      })
      .catch(() => caches.match(e.request).then((m) => m || caches.match("/")))
  );
});
