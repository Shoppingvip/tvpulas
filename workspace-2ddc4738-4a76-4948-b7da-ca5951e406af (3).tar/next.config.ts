import type { NextConfig } from "next";

// BUILD_STATIC=1 → بنیاتنانی جێگیر (static export) بۆ هۆستی وەک InfinityFree
// ئاسایی → standalone بۆ Vercel / سێرڤەر
const isStatic = process.env.BUILD_STATIC === "1";

const nextConfig: NextConfig = isStatic
  ? {
      output: "export",
      trailingSlash: true,
      images: { unoptimized: true },
      distDir: ".next-static",
      typescript: { ignoreBuildErrors: true },
      reactStrictMode: false,
    }
  : {
      output: "standalone",
      typescript: { ignoreBuildErrors: true },
      reactStrictMode: false,
      // CORS — ڕێگە بە فرۆنتی InfinityFree دەدات API ی لەسەر Vercel بانگ بکات
      async headers() {
        return [
          {
            source: "/api/:path*",
            headers: [
              { key: "Access-Control-Allow-Origin", value: "*" },
              {
                key: "Access-Control-Allow-Methods",
                value: "GET,POST,PUT,PATCH,DELETE,OPTIONS",
              },
              {
                key: "Access-Control-Allow-Headers",
                value: "Content-Type, Authorization, X-Admin-Token",
              },
              { key: "Access-Control-Max-Age", value: "86400" },
            ],
          },
        ];
      },
    };

export default nextConfig;
