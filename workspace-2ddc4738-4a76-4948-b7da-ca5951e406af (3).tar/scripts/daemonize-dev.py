#!/usr/bin/env python3
# دێمۆنەکەر — سێرڤەرەکە دووقەرە fork دەکات بۆ ئەوەی لە کوژەری پرۆسە ڕابکات
import os, sys

DEVNULL = os.open(os.devnull, os.O_RDWR)

def daemonize():
    if os.fork() > 0:
        sys.exit(0)          # باوک دەڕوات
    os.setsid()
    if os.fork() > 0:
        sys.exit(0)          # باوکی یەکەم دەڕوات — ئێستا منداڵی tini یە
    os.dup2(DEVNULL, 0)
    os.dup2(DEVNULL, 1)
    os.dup2(DEVNULL, 2)

if __name__ == '__main__':
    daemonize()
    os.chdir('/home/z/my-project')
    os.execvp('bash', ['bash', '/home/z/my-project/scripts/keep-dev.sh'])
