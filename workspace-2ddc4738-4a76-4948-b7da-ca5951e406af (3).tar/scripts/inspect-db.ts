// پشکنینی داتابەیس و پاشکۆکان — کامەیان زانیارییان تێدایە؟
import { PrismaClient } from '@prisma/client'
import { PrismaLibSQL } from '@prisma/adapter-libsql'
import { readdirSync } from 'fs'
import { join } from 'path'

const files = [
  '/home/z/my-project/db/custom.db',
  ...readdirSync('/home/z/my-project/db/backups')
    .filter((f) => f.endsWith('.db'))
    .sort()
    .map((f) => join('/home/z/my-project/db/backups', f)),
]

for (const f of files) {
  try {
    const db = new PrismaClient({
      datasources: { db: { url: `file:${f}` } },
    })
    const s = await db.settings.findUnique({ where: { id: 'main' } })
    const banner = await db.banner.count()
    const product = await db.product.count()
    const fav = await db.favorite.count()
    const hist = await db.history.count()
    console.log(
      JSON.stringify({
        file: f.replace('/home/z/my-project/db', ''),
        appName: s?.appName,
        pin: s?.adminPin ? 'SET' : 'NO',
        xtream: s?.xtreamHost ? `${s.xtreamHost} | ${s.xtreamUsername}` : null,
        m3u: s?.m3uUrl ? s.m3uUrl.slice(0, 60) : null,
        banner,
        product,
        fav,
        hist,
      })
    )
    await db.$disconnect()
  } catch (e) {
    console.log(JSON.stringify({ file: f, error: String(e).slice(0, 120) }))
  }
}
