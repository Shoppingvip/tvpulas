#!/bin/bash
# سەرپەرشتیاری سێرڤەری dev — ئەگەر ڕاوەستا، خۆکارانە دەستپێدەکاتەوە
# + پارێزەری داتابەیس: پێش هەر دەستپێکردنەوەیەک چاککردنەوەی خۆکار لە پاشکۆوە
# + پاشکۆی داتابەیس هەر ١٠ خولەک (بۆ پاراستنی زانیارییەکان لە لەدەستچان)
cd /home/z/my-project

BACKUP_DIR=/home/z/my-project/db/backups
mkdir -p "$BACKUP_DIR"
last_backup=0

while true; do
  # پاشکۆی داتابەیس — هەر ١٠ خولەک جارێک، تەنها ئەگەر فایلەکە هەیە و بەتاڵ نییە
  now=$(date +%s)
  if [ $((now - last_backup)) -ge 600 ] && [ -s /home/z/my-project/db/custom.db ]; then
    cp /home/z/my-project/db/custom.db "$BACKUP_DIR/custom-$(date '+%Y%m%d-%H%M').db" 2>/dev/null
    last_backup=$now
    # تەنها ٢٠ پاشکۆی کۆتایی بهێڵەوە
    ls -1t "$BACKUP_DIR"/custom-*.db 2>/dev/null | tail -n +21 | xargs -r rm -f
  fi

  # ئەگەر پێشتر کاردەکات، چاوەڕێ بکە
  if curl -s -o /dev/null --max-time 3 http://localhost:3000; then
    sleep 10
    continue
  fi

  # ئەگەر node_modules ون بووە (دوای recycle ی sandbox) — دایبمەزرێنە
  if [ ! -d /home/z/my-project/node_modules/next ]; then
    echo "[supervisor] $(date '+%H:%M:%S') installing dependencies (bun install)..." >> /tmp/next-dev.log
    /usr/local/bin/bun install >> /tmp/next-dev.log 2>&1
    /usr/local/bin/bunx prisma generate >> /tmp/next-dev.log 2>&1
  fi

  # پارێزەری داتابەیس — پشکنین و چاککردنەوەی خۆکار پێش دەستپێکردنەوە
  /usr/local/bin/bun run /home/z/my-project/scripts/ensure-db.ts >> /tmp/next-dev.log 2>&1

  echo "[supervisor] $(date '+%H:%M:%S') starting next dev..." >> /tmp/next-dev.log
  node ./node_modules/.bin/next dev -p 3000 >> /tmp/next-dev.log 2>&1
  echo "[supervisor] $(date '+%H:%M:%S') next dev exited, restarting in 3s" >> /tmp/next-dev.log
  sleep 3
done
