#!/usr/bin/env python3
"""PHP sanity checks — bracket balance outside strings/comments, common issues."""
import re, sys, pathlib

ROOT = pathlib.Path('/home/z/my-project/deploy/infinityfree-php/api')

def strip_strings_comments(src: str) -> str:
    out = []
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        nxt = src[i + 1] if i + 1 < n else ''
        # line comments
        if c == '/' and nxt == '/':
            j = src.find('\n', i)
            i = n if j == -1 else j
            continue
        if c == '#':
            j = src.find('\n', i)
            i = n if j == -1 else j
            continue
        # block comments
        if c == '/' and nxt == '*':
            j = src.find('*/', i + 2)
            i = n if j == -1 else j + 2
            continue
        # single/double quoted strings
        if c in ("'", '"'):
            q = c
            i += 1
            while i < n:
                if src[i] == '\\':
                    i += 2
                    continue
                if src[i] == q:
                    i += 1
                    break
                i += 1
            continue
        # heredoc — skip (not used)
        out.append(c)
        i += 1
    return ''.join(out)

problems = []
for f in sorted(ROOT.rglob('*.php')):
    src = f.read_text(encoding='utf-8')
    st = strip_strings_comments(src)
    # bracket balance
    stack = []
    pairs = {')': '(', ']': '[', '}': '{'}
    for ln, line in enumerate(st.split('\n'), 1):
        for ch in line:
            if ch in '([{':
                stack.append((ch, ln))
            elif ch in ')]}':
                if not stack or stack[-1][0] != pairs[ch]:
                    problems.append(f'{f.name}:{ln}: unbalanced "{ch}"')
                    stack = []
                    break
                stack.pop()
    if stack:
        problems.append(f'{f.name}: unclosed {stack[-1][0]} from line {stack[-1][1]}')
    # php open tag
    if not src.lstrip().startswith('<?php'):
        problems.append(f'{f.name}: missing <?php')
    # suspicious:  ], 4 0 0 patterns like "], 400]);"
    if re.search(r'\]\s*\]\s*;', src) and 'json_out' in src:
        pass  # legal in nested arrays, ignore
    # check no leftover placeholder
    for m in re.finditer(r'TODO|XXX|FIXME', src):
        problems.append(f'{f.name}: placeholder {m.group(0)}')

if problems:
    print('PROBLEMS:')
    for p in problems:
        print(' -', p)
    sys.exit(1)
print(f'OK — all PHP files balanced ({len(list(ROOT.rglob("*.php")))} files)')
