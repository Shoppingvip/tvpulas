#!/bin/bash
# دووبارە دروستکردنی پاکێجی بڵاوکردنەوە — iptv-app-deploy.zip
# لیستی فایلەکان لە scripts/deploy-files.txt دێت (بەردەوام پارێزراوە)
set -e
cd /home/z/my-project

STAGING=/tmp/deploy-staging
rm -rf "$STAGING"
mkdir -p "$STAGING"

FILE_LIST="$(dirname "$0")/deploy-files.txt"
if [ ! -f "$FILE_LIST" ]; then
  echo "❌ لیستی فایلەکان نییە: $FILE_LIST" >&2
  exit 1
fi

# کۆپیکردنی هەموو فایلەکان بۆ staging
while IFS= read -r f; do
  case "$f" in
    .env.example)
      cp "$f" "$STAGING/.env.example" ;;
    GUIDE-KURDISH.md)
      cp "download/GUIDE-KURDISH.md" "$STAGING/GUIDE-KURDISH.md" ;;
    *)
      if [ -f "$f" ]; then
        mkdir -p "$STAGING/$(dirname "$f")"
        cp "$f" "$STAGING/$f"
      else
        echo "❌ نیە: $f" >&2
        exit 1
      fi ;;
  esac
done < "$FILE_LIST"

# دروستکردنی زیپ
cd "$STAGING"
rm -f /home/z/my-project/download/iptv-app-deploy.zip
zip -q -r /home/z/my-project/download/iptv-app-deploy.zip . -x '.*DS_Store*'
echo "✅ زیپ دروستکرا:"
unzip -l /home/z/my-project/download/iptv-app-deploy.zip | tail -3
