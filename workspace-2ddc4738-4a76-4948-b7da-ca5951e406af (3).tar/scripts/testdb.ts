import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()
async function main() {
  await db.settings.upsert({
    where: { id: 'main' },
    update: { adminPin: '1234', xtreamHost: 'http://demo-server.local:8080', xtreamUsername: 'demo', xtreamPassword: 'demo' },
    create: { id: 'main', adminPin: '1234', xtreamHost: 'http://demo-server.local:8080', xtreamUsername: 'demo', xtreamPassword: 'demo' },
  })
  console.log('OK - settings with PIN 1234 set')
}
main().finally(() => db.$disconnect())
