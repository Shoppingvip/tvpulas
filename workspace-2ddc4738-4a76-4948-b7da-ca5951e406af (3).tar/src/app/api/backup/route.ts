// پاشکۆی دەستکرد — دەرهێنان و هێنانەوەی هەموو زانیارییەکان بە جۆری JSON
// تەنها بەڕێوەبەر دەتوانێت ئەمە بەکاربهێنێت
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { isAdminRequest, forbidden } from '@/lib/admin'
import { backupDbFile } from '@/lib/backup'

export const dynamic = 'force-dynamic'

// ---- دەرهێنان — فایلێکی JSON ی هەموو زانیارییەکان دادەبەزێت ----
export async function GET(req: NextRequest) {
  if (!(await isAdminRequest(req))) return forbidden()
  try {
    const [settings, banners, products, favorites, history, m3uSources] = await Promise.all([
      db.settings.findMany(),
      db.banner.findMany({ orderBy: { sortOrder: 'asc' } }),
      db.product.findMany({ orderBy: { sortOrder: 'asc' } }),
      db.favorite.findMany({ orderBy: { createdAt: 'asc' } }),
      db.history.findMany({ orderBy: { watchedAt: 'desc' } }),
      db.m3uSource.findMany({ orderBy: { sortOrder: 'asc' } }),
    ])
    const payload = {
      app: 'iptv-web',
      version: 1,
      exportedAt: new Date().toISOString(),
      settings,
      banners,
      products,
      favorites,
      history,
      m3uSources,
    }
    const stamp = new Date().toISOString().slice(0, 10)
    return new NextResponse(JSON.stringify(payload, null, 2), {
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="iptv-backup-${stamp}.json"`,
      },
    })
  } catch {
    return NextResponse.json({ error: 'هەڵە لە دەرهێنانی زانیارییەکان' }, { status: 500 })
  }
}

// ---- هێنانەوە — فایلی پاشکۆ بار دەکرێت و زانیارییەکان دەگەڕێنرێنەوە ----
export async function POST(req: NextRequest) {
  if (!(await isAdminRequest(req))) return forbidden()
  try {
    const body = (await req.json()) as {
      settings?: Array<Record<string, unknown>>
      banners?: Array<Record<string, unknown>>
      products?: Array<Record<string, unknown>>
      favorites?: Array<Record<string, unknown>>
      history?: Array<Record<string, unknown>>
      m3uSources?: Array<Record<string, unknown>>
    }

    if (!Array.isArray(body.settings) || body.settings.length === 0) {
      return NextResponse.json({ error: 'فایلەکە پاشکۆیەکی دروست نییە — زانیاری ڕێکخستنی تێدا نییە' }, { status: 400 })
    }

    // پاشکۆیەک لە دۆخی ئێستا بگرە پێش گۆڕین — بۆ ئەگەری هەڵە
    backupDbFile('before-import')

    const str = (v: unknown): string | null => (v == null ? null : String(v))
    const s0 = body.settings[0] as Record<string, unknown>

    await db.$transaction([
      // ڕێکخستنەکان — بەسەر تۆماری main دەنووسرێتەوە
      db.settings.upsert({
        where: { id: 'main' },
        update: {
          appName: str(s0.appName) ?? 'تیڤی ئەپی من',
          adminPin: str(s0.adminPin),
          xtreamHost: str(s0.xtreamHost),
          xtreamUsername: str(s0.xtreamUsername),
          xtreamPassword: str(s0.xtreamPassword),
          m3uUrl: str(s0.m3uUrl),
        },
        create: {
          id: 'main',
          appName: str(s0.appName) ?? 'تیڤی ئەپی من',
          adminPin: str(s0.adminPin),
          xtreamHost: str(s0.xtreamHost),
          xtreamUsername: str(s0.xtreamUsername),
          xtreamPassword: str(s0.xtreamPassword),
          m3uUrl: str(s0.m3uUrl),
        },
      }),
      // خشتەکانی تر — پاک دەکرێنەوە و لە فایلەکەوە دادەنرێن
      db.banner.deleteMany(),
      db.product.deleteMany(),
      db.favorite.deleteMany(),
      db.history.deleteMany(),
      db.m3uSource.deleteMany(),
    ])

    // زانیارییەکان یەک بە یەک زیاد دەکرێن
    for (const b of body.banners ?? []) {
      if (!str(b.data)) continue
      await db.banner
        .create({
          data: {
            id: str(b.id) ?? undefined,
            name: str(b.name) ?? '',
            data: String(b.data),
            sortOrder: Number(b.sortOrder ?? 0) || 0,
          },
        })
        .catch(() => {})
    }
    for (const p of body.products ?? []) {
      if (!str(p.name)) continue
      await db.product
        .create({
          data: {
            id: str(p.id) ?? undefined,
            name: String(p.name),
            price: str(p.price) ?? '',
            description: str(p.description) ?? '',
            image: str(p.image),
            sortOrder: Number(p.sortOrder ?? 0) || 0,
          },
        })
        .catch(() => {})
    }
    for (const f of body.favorites ?? []) {
      if (!str(f.itemId)) continue
      await db.favorite
        .create({
          data: {
            id: str(f.id) ?? undefined,
            itemType: str(f.itemType) ?? 'live',
            itemId: String(f.itemId),
            name: str(f.name) ?? '',
            logo: str(f.logo),
            extra: str(f.extra),
          },
        })
        .catch(() => {}) // دووبارەیی — پشتگوێ بخە
    }
    for (const h of body.history ?? []) {
      if (!str(h.itemId)) continue
      await db.history
        .create({
          data: {
            id: str(h.id) ?? undefined,
            itemType: str(h.itemType) ?? 'live',
            itemId: String(h.itemId),
            name: str(h.name) ?? '',
            logo: str(h.logo),
            extra: str(h.extra),
          },
        })
        .catch(() => {})
    }
    // لیستەکانی M3U — بەپێی ڕیزەکەیان دەگەڕێنرێنەوە
    for (const m of body.m3uSources ?? []) {
      if (!str(m.url)) continue
      await db.m3uSource
        .create({
          data: {
            id: str(m.id) ?? undefined,
            name: str(m.name) ?? '',
            url: String(m.url),
            section: str(m.section) ?? 'both',
            sortOrder: Number(m.sortOrder ?? 0) || 0,
          },
        })
        .catch(() => {})
    }

    // پاشکۆی نوێ لە دۆخی گەڕاندراوە
    backupDbFile('after-import')

    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'نەکرا فایلەکە بهێنرێتەوە — دڵنیابە فایلی پاشکۆی دروستە' }, { status: 400 })
  }
}
