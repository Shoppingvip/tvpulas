import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { isAdminRequest, forbidden } from '@/lib/admin'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    if (!(await isAdminRequest(req))) return forbidden()
    const items = await db.favorite.findMany({ orderBy: { createdAt: 'desc' } })
    return NextResponse.json({ items })
  } catch {
    return NextResponse.json({ error: 'هەڵە لە خوێندنەوەی دڵخوازەکان' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    if (!(await isAdminRequest(req))) return forbidden()
    const body = (await req.json()) as {
      itemType: string
      itemId: string
      name: string
      logo?: string | null
      extra?: string | null
    }
    if (!body.itemType || !body.itemId || !body.name) {
      return NextResponse.json({ error: 'زانیاری ناتەواو' }, { status: 400 })
    }
    const existing = await db.favorite.findUnique({
      where: { itemType_itemId: { itemType: body.itemType, itemId: body.itemId } },
    })
    if (existing) {
      await db.favorite.delete({ where: { id: existing.id } })
      return NextResponse.json({ ok: true, added: false })
    }
    await db.favorite.create({
      data: {
        itemType: body.itemType,
        itemId: body.itemId,
        name: body.name,
        logo: body.logo ?? null,
        extra: body.extra ?? null,
      },
    })
    return NextResponse.json({ ok: true, added: true })
  } catch {
    return NextResponse.json({ error: 'هەڵە لە تۆمارکردن' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  try {
    if (!(await isAdminRequest(req))) return forbidden()
    const itemType = req.nextUrl.searchParams.get('itemType')
    const itemId = req.nextUrl.searchParams.get('itemId')
    if (itemType === 'ALL') {
      await db.favorite.deleteMany({})
      return NextResponse.json({ ok: true })
    }
    if (!itemType || !itemId) {
      return NextResponse.json({ error: 'زانیاری ناتەواو' }, { status: 400 })
    }
    await db.favorite.deleteMany({ where: { itemType, itemId } })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'هەڵە لە سڕینەوە' }, { status: 500 })
  }
}
