import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { isAdminRequest, forbidden, ADMIN_COOKIE, adminToken, adminCookieOptions } from '@/lib/admin'

export const dynamic = 'force-dynamic'

// نوێکردنەوەی کۆدی بەڕێوەبەر — تەنها بەڕێوەبەر
// (کۆدی داخڵکردنی ئەپ بۆ بەکارهێنەری ئاسایی بە تەواوی لابراوە — ئەپەکە ڕاستەوخۆ دەکرێتەوە)
export async function POST(req: NextRequest) {
  try {
    if (!(await isAdminRequest(req))) return forbidden()

    const body = (await req.json()) as { adminPin?: string | null }
    const adminPin = body.adminPin?.trim() || null

    if (body.adminPin !== undefined && adminPin && !/^\d{3,6}$/.test(adminPin)) {
      return NextResponse.json({ error: 'کۆدی بەڕێوەبەر دەبێت ٣ بۆ ٦ ژمارە بێت' }, { status: 400 })
    }

    const s = await db.settings.findUnique({ where: { id: 'main' } })
    const data: { adminPin?: string | null } = {}
    if (body.adminPin !== undefined) data.adminPin = adminPin

    if (!s) {
      await db.settings.create({ data: { id: 'main', ...data } })
    } else {
      await db.settings.update({ where: { id: 'main' }, data })
    }

    const res = NextResponse.json({ ok: true })
    // cookie نوێ دابنێ بۆ بەردەوامی دانیشتنەکە
    if (body.adminPin !== undefined) {
      if (adminPin) {
        res.cookies.set(ADMIN_COOKIE, adminToken(adminPin), adminCookieOptions())
      } else {
        // کۆدەکە لابرا — cookie بسڕەوە
        res.cookies.set(ADMIN_COOKIE, '', { path: '/', maxAge: 0 })
      }
    }
    return res
  } catch {
    return NextResponse.json({ error: 'هەڵەیەک ڕوویدا' }, { status: 500 })
  }
}
