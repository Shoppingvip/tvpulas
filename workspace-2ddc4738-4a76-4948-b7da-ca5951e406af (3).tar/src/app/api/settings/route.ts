import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import type { AppSettingsStatus } from '@/lib/iptv'
import { isAdminRequest, forbidden } from '@/lib/admin'
import { backupDbFile } from '@/lib/backup'
import { hasAnySource } from '@/lib/m3u'

export const dynamic = 'force-dynamic'

// زانیاری ڕێکخستنەکان — بەبێ نهێنییەکان
export async function readSettings() {
  let s = await db.settings.findUnique({ where: { id: 'main' } })
  if (!s) {
    s = await db.settings.create({ data: { id: 'main' } })
  }
  return s
}

export async function buildStatus(admin = false): Promise<AppSettingsStatus> {
  const s = await readSettings()
  const usingXtream = !!(s.xtreamHost && s.xtreamUsername && s.xtreamPassword)
  const hasM3u = !!s.m3uUrl || (await hasAnySource())
  const mode = usingXtream ? 'xtream' : hasM3u ? 'm3u' : null
  // بۆ ئەوانەی بەڕێوەبەر نین — ناونیشانەکان دەشاردرێنەوە
  return {
    configured: !!mode,
    appName: s.appName,
    mode,
    host: admin && usingXtream ? s.xtreamHost : null,
    username: admin && usingXtream ? s.xtreamUsername : null,
    m3uUrl: admin && mode === 'm3u' ? s.m3uUrl : null,
    hasAdminPin: !!s.adminPin,
    isAdmin: admin,
    expiryDate: null,
    activeConnections: null,
    maxConnections: null,
    status: null,
  }
}

export async function GET(req: NextRequest) {
  try {
    const admin = await isAdminRequest(req)
    return NextResponse.json(await buildStatus(admin))
  } catch {
    return NextResponse.json({ error: 'هەڵە لە خوێندنەوەی ڕێکخستنەکان' }, { status: 500 })
  }
}

// وەرگێڕانی هەڵەی تۆڕ بۆ کوردی
function netErrMsg(e: unknown): string {
  const m = e instanceof Error ? e.message : String(e)
  if (/fetch failed|ENOTFOUND|EAI_AGAIN|getaddrinfo/i.test(m)) {
    return 'نەکرا پەیوەندی بە سێرڤەرەکە بکرێت — ناونیشانەکە پشکنین بکە'
  }
  if (/ECONNREFUSED/i.test(m)) return 'سێرڤەرەکە ڕەتی کردەوە — پۆرتەکە هەڵەیە لەوانەیە'
  if (/abort|timeout|timed out/i.test(m)) return 'وەڵام نەگەڕایەوە — سێرڤەرەکە خاوە یان داخڵە'
  if (/certificate|SSL|TLS/i.test(m)) return 'کێشەی گوێپاراستن (SSL) لە سێرڤەرەکەدا هەیە'
  return m
}

// پشکنینی بەستەر بە سێرڤەری Xtream
async function testXtream(host: string, username: string, password: string) {
  const base = host.replace(/\/+$/, '')
  if (!/^https?:\/\//i.test(base)) {
    throw new Error('ناونیشانی سێرڤەر دەبێت بە http:// یان https:// دەست پێبکات')
  }
  const url = `${base}/player_api.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`
  let res: Response
  try {
    res = await fetch(url, {
      signal: AbortSignal.timeout(15000),
      headers: { 'User-Agent': 'Mozilla/5.0 (IPTV Web Player)' },
    })
  } catch (e) {
    throw new Error(netErrMsg(e))
  }
  if (!res.ok) throw new Error('وەڵامی سێرڤەر نەگەڕایەوە')
  const data = (await res.json().catch(() => null)) as {
    user_info?: { auth?: number; exp_date?: string; active_cons?: string; max_connections?: string; status?: string }
  } | null
  if (!data || !data.user_info || data.user_info.auth !== 1) {
    throw new Error('زانیارییەکان هەڵەن — ناساندنی بەکارهێنەر سەرکەوتوو نەبوو')
  }
  return {
    expiryDate: data.user_info.exp_date
      ? new Date(Number(data.user_info.exp_date) * 1000).toISOString()
      : null,
    activeConnections: data.user_info.active_cons ?? null,
    maxConnections: data.user_info.max_connections ?? null,
    status: data.user_info.status ?? null,
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      appName?: string
      adminPin?: string | null
      xtreamHost?: string | null
      xtreamUsername?: string | null
      xtreamPassword?: string | null
      m3uUrl?: string | null
    }

    // پاراستن — تەنها بەڕێوەبەر دەتوانێت زانیارییەکان بگۆڕێت
    // بەڵام ئەگەر هێشتا کۆدی بەڕێوەبەر دانەنراوە (یەکەم جارە) — ئازادە بۆ داواکردن
    const current = await db.settings.findUnique({ where: { id: 'main' } })
    if (current?.adminPin && !(await isAdminRequest(req))) {
      return forbidden()
    }
    if (body.adminPin && !/^\d{3,6}$/.test(body.adminPin.trim())) {
      return NextResponse.json({ error: 'کۆدی بەڕێوەبەر دەبێت ٣ بۆ ٦ ژمارە بێت' }, { status: 400 })
    }

    const host = body.xtreamHost?.trim() || null
    const username = body.xtreamUsername?.trim() || null
    const password = body.xtreamPassword?.trim() || null
    const m3uUrl = body.m3uUrl?.trim() || null

    const usingXtream = !!(host && username && password)
    const usingM3u = !!m3uUrl

    if (!usingXtream && !usingM3u) {
      return NextResponse.json(
        { error: 'تکایە زانیارییەکانی Xtream یان بەستەری M3U داخڵ بکە' },
        { status: 400 }
      )
    }

    let info: Awaited<ReturnType<typeof testXtream>> | null = null
    if (usingXtream && host && username && password) {
      info = await testXtream(host, username, password)
    } else if (usingM3u && m3uUrl) {
      try {
        const res = await fetch(m3uUrl, { signal: AbortSignal.timeout(25000) })
        if (!res.ok) throw new Error('بەستەری M3U وەڵام نەدایەوە')
        const text = await res.text()
        if (!text.includes('#EXTM3U')) throw new Error('فایلەکە لیستی M3U نییە')
      } catch (e) {
        throw new Error(netErrMsg(e))
      }
    }

    // کۆدی بەڕێوەبەر تەنها لە یەکەم جار دادەنرێت — پاشان لە ڕێکخستنەکان دەگۆڕدرێت
    const adminPinUpdate = !current?.adminPin && body.adminPin?.trim() ? body.adminPin.trim() : undefined

    await db.settings.upsert({
      where: { id: 'main' },
      update: {
        appName: body.appName?.trim() || 'تیڤی ئەپی من',
        ...(adminPinUpdate ? { adminPin: adminPinUpdate } : {}),
        xtreamHost: usingXtream ? host : null,
        xtreamUsername: usingXtream ? username : null,
        xtreamPassword: usingXtream ? password : null,
        m3uUrl: usingXtream ? null : m3uUrl,
      },
      create: {
        id: 'main',
        appName: body.appName?.trim() || 'تیڤی ئەپی من',
        ...(adminPinUpdate ? { adminPin: adminPinUpdate } : {}),
        xtreamHost: usingXtream ? host : null,
        xtreamUsername: usingXtream ? username : null,
        xtreamPassword: usingXtream ? password : null,
        m3uUrl: usingXtream ? null : m3uUrl,
      },
    })

    // لیستی سەرەکی M3U — سەرچاوەکانی (هەردووکیان) بە لیستە نوێیەکە دەگوازرێنەوە
    // لیستە جیاکراوەکانی کەناڵ/فلیم وەک خۆیان دەمێننەوە
    if (usingM3u && m3uUrl) {
      await db.m3uSource.deleteMany({ where: { section: 'both' } })
      const count = await db.m3uSource.count()
      await db.m3uSource.create({
        data: { name: 'لیستی سەرەکی', url: m3uUrl, section: 'both', sortOrder: count },
      })
    }

    // پاشکۆی خۆکار دوای هەر گۆڕانکارییەک — زانیارییەکان هەرگیز ون نابن
    backupDbFile('settings-saved')

    return NextResponse.json({
      ok: true,
      expiryDate: info?.expiryDate ?? null,
      activeConnections: info?.activeConnections ?? null,
      maxConnections: info?.maxConnections ?? null,
      status: info?.status ?? null,
    })
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'هەڵەیەکی نەزانراو ڕوویدا'
    return NextResponse.json({ error: msg }, { status: 400 })
  }
}
