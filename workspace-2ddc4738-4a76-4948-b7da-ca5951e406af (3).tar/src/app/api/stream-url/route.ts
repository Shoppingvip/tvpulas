import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

// دروستکردنی بەستەری پەخش — وشەی نهێنی لە سێرڤەردا دەمێنێتەوە
export async function GET(req: NextRequest) {
  try {
    const s = await db.settings.findUnique({ where: { id: 'main' } })
    if (!s || !s.xtreamHost || !s.xtreamUsername || !s.xtreamPassword) {
      return NextResponse.json({ error: 'زانیارییەکان دانەنراون' }, { status: 400 })
    }

    const type = req.nextUrl.searchParams.get('type')
    const id = req.nextUrl.searchParams.get('id')
    const ext = req.nextUrl.searchParams.get('ext') || 'mp4'

    if (!id || !type) {
      return NextResponse.json({ error: 'زانیاری ناتەواو' }, { status: 400 })
    }

    const base = s.xtreamHost.replace(/\/+$/, '')
    const user = encodeURIComponent(s.xtreamUsername)
    const pass = encodeURIComponent(s.xtreamPassword)

    let url: string
    switch (type) {
      case 'live':
        url = `${base}/live/${user}/${pass}/${id}.m3u8`
        break
      case 'movie':
        url = `${base}/movie/${user}/${pass}/${id}.${ext}`
        break
      case 'series':
        url = `${base}/series/${user}/${pass}/${id}.${ext}`
        break
      default:
        return NextResponse.json({ error: 'جۆری نەزانراو' }, { status: 400 })
    }

    return NextResponse.json({ url })
  } catch {
    return NextResponse.json({ error: 'هەڵەیەک ڕوویدا' }, { status: 500 })
  }
}
