import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

// پشکنینی کۆدی PIN بۆ کردنەوەی ئەپ
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as { pin?: string }
    const s = await db.settings.findUnique({ where: { id: 'main' } })
    if (!s || !s.adminPin) return NextResponse.json({ ok: true })
    if ((body.pin ?? '').trim() === s.adminPin) {
      return NextResponse.json({ ok: true })
    }
    return NextResponse.json({ error: 'کۆدەکە هەڵەیە' }, { status: 401 })
  } catch {
    return NextResponse.json({ error: 'هەڵەیەک ڕوویدا' }, { status: 500 })
  }
}
