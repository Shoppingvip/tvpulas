import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: "تیڤی ئەپی من — پلەیەری IPTV",
  description: "ئەپێکی کەسی بۆ تەماشاکردنی کەناڵ و فلیمەکان بە پشتگیری Xtream Codes و M3U",
  manifest: "/manifest.webmanifest",
  applicationName: "تیڤی ئەپی من",
  // لە ئەندرۆید — کاتێک لە شاشەی سەرەکی دادەمەزرێت، بەبێ ناونیشانی وێبگەڕ دەکرێتەوە
  other: { "mobile-web-app-capable": "yes" },
  appleWebApp: {
    capable: true,
    title: "تیڤی ئەپی من",
    statusBarStyle: "black-translucent",
  },
  icons: {
    icon: [
      { url: "/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#07070f",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ckb" dir="rtl" className="dark">
      <head>
        {/* ڕێکخستنی runtime — ناونیشانی API (بۆ InfinityFree) پێش هەموو کۆدەکان بخوێنرێتەوە */}
        <script src="/config.js" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        {/* App Router — layout هاوبەشە بۆ هەموو لاپەڕەکان */}
        {/* eslint-disable-next-line @next/next/no-page-custom-font */}
        <link
          href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@300;400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
        {/* سێرڤیس وۆرکەر — بۆ دامەزراندنی ئەپ لەسەر موبایل و تیڤی */}
        <script
          dangerouslySetInnerHTML={{
            __html: `if('serviceWorker' in navigator){window.addEventListener('load',function(){navigator.serviceWorker.register('/sw.js').catch(function(){})})}`,
          }}
        />
      </head>
      <body className="antialiased bg-background text-foreground">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
