'use client'
import { apiUrl } from '@/lib/api'

// شاشەی سەرەکی ئەپی تیڤی — هەموو بەشەکان لێرە کۆدەکرێنەوە
import { useCallback, useEffect, useRef, useState, type ChangeEvent } from 'react'
import { Tv, Home, Film, ShoppingBag, Package, Plus, Settings, Play, RefreshCw, Trash2, LogOut, KeyRound, Info, Keyboard, Shield, ShieldOff, ChevronLeft, ChevronRight, Images, ImagePlus, DatabaseBackup, Download, Upload, Maximize2, Minimize2, CalendarClock } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { AppSettingsStatus, PlayItem, PlayListContext } from '@/lib/iptv'
import { SetupScreen, AdminLockDialog } from '@/components/iptv/setup'
import { BrowseScreen } from '@/components/iptv/browse'
import { M3uSourcesPanel } from '@/components/iptv/sources'
import { VideoPlayer, type PlayerSource } from '@/components/iptv/player'
import { MovieDialog, fetchShortEpg } from '@/components/iptv/details'
import { Spinner } from '@/components/iptv/ui-bits'
import { useTvMode } from '@/hooks/use-tv-mode'
import { useToast } from '@/hooks/use-toast'

type Tab = 'home' | 'live' | 'movie' | 'market' | 'settings'

// وێنەی ڕیکلامی بەشی ماڵەوە
interface BannerItem {
  id: string
  name: string
  data: string
}

// کاڵای مارکێت
interface ProductItem {
  id: string
  name: string
  price: string
  description: string
  image: string | null
}

// بەرواری کۆتایی هەژمار
function fmtExpiry(iso: string | null): string {
  if (!iso) return '—'
  const d = new Date(iso)
  if (isNaN(d.getTime())) return '—'
  return d.toLocaleDateString('ckb-IQ', { year: 'numeric', month: 'long', day: 'numeric' })
}

export default function Page() {
  const { toast } = useToast()
  // دۆخی تیڤی — ڕووکاری گەورە بۆ ڕیمۆت + پڕەکی (لابردنی ناونیشانی وێبگەڕ)
  const { tvMode, toggleTv, enterFullscreen, ready } = useTvMode()
  const [status, setStatus] = useState<AppSettingsStatus | null>(null)
  const [loadingStatus, setLoadingStatus] = useState(true)
  const [tab, setTab] = useState<Tab>('home')
  const [banners, setBanners] = useState<BannerItem[]>([])
  const [products, setProducts] = useState<ProductItem[]>([])
  // لە دۆخی تیڤیدا سەرەوە خۆکارانە دەشاردرێتەوە کاتێک لیستەکان دادەسکڕێن
  // — ڕووکارێکی پاک وەک ئەپی تیڤی ڕاستەقینە، نەک وێبگەڕ
  const [headerHidden, setHeaderHidden] = useState(false)
  const lastScrollY = useRef(0)
  // شاشەی دەستپێکی تیڤی — لە یەکەم لێدانی ڕیمۆت پڕەکی چالاک دەبێت و ناونیشانی وێبگەڕ دەشاردرێتەوە
  const [tvSplash, setTvSplash] = useState(false)
  const splashShownRef = useRef(false)

  // پلەیەر
  const [playing, setPlaying] = useState<PlayerSource | null>(null)
  const [epgLoading, setEpgLoading] = useState(false)
  // لیستی کەناڵەکان بۆ گۆڕین بە ڕیمۆت (دواتر/پێشتر — وەک CH+ / CH- ی تیڤی)
  const [playlist, setPlaylist] = useState<PlayListContext | null>(null)
  const playlistRef = useRef<PlayListContext | null>(null)
  // نیشانەی نەوەی لێدان — کاتێک بە خێرایی کەناڵ دەگۆڕدرێت، داواکارییە کۆنەکان پشتگوێ دەخرێن
  const playTokenRef = useRef(0)

  // دیالۆگەکان
  const [movieOpen, setMovieOpen] = useState<{ id: string; name: string; cover: string | null; ext: string } | null>(null)
  const [showSetup, setShowSetup] = useState(false)
  const [adminOpen, setAdminOpen] = useState(false)
  // فۆرمی ڕێکخستن لە دەستپێکی ئەپەکە نایەت — تەنها لە بەشی بەڕێوەبەرەوە دەکرێتەوە

  // ئایا ئەم وێبگەڕە دەسەڵاتی بەڕێوەبەری هەیە؟
  const isAdmin = !!status?.isAdmin

  // ---- خێرایی: شاشەکان لە یادەوەری دەمێننەوە ----
  // هەر شاشەیەک لە یەکەم کردنەوەدا دروست دەبێت و پاشان بە دەمارەوە دەمێنێت —
  // گۆڕینی تاب و گەڕانەوە یەکسەرە، داتا و سکرۆڵ دەمێننەوە و دووبارە بارکردن نایەت
  // (هوکەکان پێش هەموو early return ـەکان — ڕێسای هوکەکانی React)
  const configured = !!status?.configured
  const mode = status?.mode ?? 'm3u'
  // ئەگەر تەماشاکەرە — تابی ڕێکخستن قەدەغەیە
  const viewTab: Tab = !configured ? 'settings' : !isAdmin && tab === 'settings' ? 'home' : tab
  const [mountedTabs, setMountedTabs] = useState<Record<Tab, boolean>>({
    home: true, live: false, movie: false, market: false, settings: false,
  })
  useEffect(() => {
    setMountedTabs((m) => (m[viewTab] ? m : { ...m, [viewTab]: true }))
  }, [viewTab])
  // سکرۆڵ بۆ سەرەوە لە کاتی گۆڕینی تاب — شاشەی نوێ لە سەرەتاوە دەست پێدەکات (بێ دووبارە بارکردن)
  useEffect(() => { window.scrollTo(0, 0) }, [viewTab])
  // پێشبارکردن لە پاشبنەما — دوای ٣ چرکە شاشەی کەناڵ و فلیم بێدەنگ ئامادە دەبن
  useEffect(() => {
    if (!configured) return
    const t = setTimeout(() => setMountedTabs((m) => ({ ...m, live: true, movie: true })), 3000)
    return () => clearTimeout(t)
  }, [configured])
  // پێشبارکردنی hls.js لە پاشبنەما — کردنەوەی یەکەم کەناڵ/فلیم خێراتر دەبێت
  useEffect(() => {
    if (!configured) return
    const t = setTimeout(() => { void import('hls.js') }, 3500)
    return () => clearTimeout(t)
  }, [configured])

  // ---- خوێندنەوەی ڕێکخستنەکان ----
  const loadStatus = useCallback(async () => {
    try {
      const res = await fetch(apiUrl('/api/settings'))
      const data = (await res.json()) as AppSettingsStatus
      setStatus(data)
    } catch {
      setStatus({ configured: false, appName: 'تیڤی ئەپی من', mode: null, host: null, username: null, m3uUrl: null, expiryDate: null, activeConnections: null, maxConnections: null, status: null })
    } finally {
      setLoadingStatus(false)
    }
  }, [])

  useEffect(() => { loadStatus() }, [loadStatus])

  // ---- سەرەوەی خۆشارەوە (تەنها لە دۆخی تیڤی) ----
  // سکرۆڵ بۆ خوارەوە = سەرەوە بشاردرێتەوە — لیستەکان دەبن بە پاڵەوانی شاشە
  // سکرۆڵ بۆ سەرەوە = سەرەوە دەگەڕێتەوە
  useEffect(() => {
    if (!tvMode) {
      setHeaderHidden(false)
      return
    }
    const onScroll = () => {
      const y = window.scrollY
      if (y < 80) setHeaderHidden(false)
      else if (y > lastScrollY.current + 14) setHeaderHidden(true)
      else if (y < lastScrollY.current - 14) setHeaderHidden(false)
      lastScrollY.current = y
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [tvMode])

  // ---- فۆکەسی سەرەتایی لە دۆخی تیڤی ----
  // لە ماڵەوە، فۆکەس ڕاستەوخۆ بۆ یەکەم کارت دەبرێت — بەکارهێنەری ڕیمۆت یەکسەر دەتوانێت OK دابگرێت
  useEffect(() => {
    if (!tvMode || loadingStatus || !status?.configured) return
    if (tab !== 'home') return
    const t = setTimeout(() => {
      const first = document.querySelector<HTMLElement>('.quick-card')
      const active = document.activeElement
      if (first && (!active || active === document.body)) first.focus()
    }, 350)
    return () => clearTimeout(t)
  }, [tvMode, loadingStatus, tab, status])

  // یەکەم جار دۆخی تیڤی چالاک دەبێت — ڕێنماییەکی کورت بۆ بەکارهێنەر
  useEffect(() => {
    if (!ready || !tvMode) return
    try {
      if (localStorage.getItem('iptv-tv-hint') === '1') return
      localStorage.setItem('iptv-tv-hint', '1')
    } catch { return }
    toast({
      title: 'دۆخی تیڤی چالاکە 📺',
      description: 'هەر دوگمەیەکی ڕیمۆت دابگرە — پڕەکی خۆکارانە چالاک دەبێت و ناونیشانی وێبگەڕ دەشاردرێتەوە',
    })
  }, [ready, tvMode, toast])

  // ---- شاشەی دەستپێکی تیڤی — تەنها یەک جار بۆ هەر بارکردنێک ----
  // وێبگەڕی تیڤی پێویستی بە لێدانێکی بەکارهێنەرە بۆ پڕەکی — ئەم شاشەیە ئەو لێدانە بە جوانی
  // وەک شاشەی دەستپێکی ئەپی تیڤی دەگرێت، پاشان پڕەکی چالاک دەبێت و ناونیشانی وێبگەڕ دەمێنێتەوە
  useEffect(() => {
    if (!ready || !tvMode || loadingStatus) return
    if (splashShownRef.current) return
    if (!(status?.configured || isAdmin)) return
    splashShownRef.current = true
    let supported = true
    try {
      // تەنانەت ئەگەر fullscreenEnabled == false ی وێبگەڕی تیڤی بێت — شاشەی دەستپێک دەکرێتەوە
      // چونکە زۆربەی تیڤییەکان بە لێدانێکی بەکارهێنەر پڕەکی قبوڵ دەکەن تەنانەت ئەگەر ئەو ئاڵایە هەڵە بێت
      supported =
        !document.fullscreenElement &&
        !(window.matchMedia && window.matchMedia('(display-mode: fullscreen)').matches)
    } catch { supported = true }
    if (!supported) return
    setTvSplash(true)
  }, [ready, tvMode, loadingStatus, status, isAdmin])

  // هەر لێدانێک (ڕیمۆت یان دەس) — پڕەکی + داخستنی شاشەی دەستپێک
  useEffect(() => {
    if (!tvSplash) return
    const go = () => {
      void enterFullscreen()
      setTvSplash(false)
    }
    window.addEventListener('keydown', go, { once: true })
    window.addEventListener('pointerdown', go, { once: true })
    window.addEventListener('touchend', go, { once: true })
    return () => {
      window.removeEventListener('keydown', go)
      window.removeEventListener('pointerdown', go)
      window.removeEventListener('touchend', go)
    }
  }, [tvSplash, enterFullscreen])

  // ---- دوگمەی Back ی ڕیمۆت (Tizen 10009 / webOS 461 / GoBack) ----
  // هەنگاو بە هەنگاو دەگەڕێتەوە: پلەیەر → لیست، دیالۆگ → شاشە، تاب → ماڵەوە
  // هەرگیز یەکسەر ئەپەکە داخەڵێتەوە — وەک ئەپی تیڤی ڕاستەقینە
  const backStep = useCallback(() => {
    if (playing) {
      // داخستنی پلەیەر — گەڕانەوە بۆ لیستەکە
      setPlaying(null)
      playlistRef.current = null
      setPlaylist(null)
      if (tvMode) void enterFullscreen()
      return
    }
    if (movieOpen) { setMovieOpen(null); return }
    if (adminOpen) { setAdminOpen(false); return }
    if (showSetup) { setShowSetup(false); return }
    if (tab !== 'home') { setTab('home'); return }
    // لە ماڵەوە — هیچ مەکە: ئەپەکە داخەڵێتەوە نا
  }, [playing, movieOpen, adminOpen, showSetup, tab, tvMode, enterFullscreen])

  const backStepRef = useRef(backStep)
  useEffect(() => { backStepRef.current = backStep })

  // خۆپاراستن لە دووجا جێبەجێکردن — هەندێک ڕیمۆت هەم keydown دەنێرێت هەم history.back() دەکات
  const lastBackAtRef = useRef(0)
  const runBackStep = useCallback(() => {
    const now = Date.now()
    if (now - lastBackAtRef.current < 350) return
    lastBackAtRef.current = now
    backStepRef.current()
  }, [])

  useEffect(() => {
    if (!tvMode) return
    const onBack = (e: KeyboardEvent) => {
      const isBack =
        e.keyCode === 10009 || e.keyCode === 461 ||
        e.key === 'GoBack' || e.key === 'BrowserBack' || e.key === 'Backspace'
      if (!isBack) return
      const active = document.activeElement as HTMLElement | null
      const inField = !!active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.isContentEditable)
      if (inField) {
        // Backspace لەناو خانەی نووسین — بۆ سڕینەوەی نووسینە نەک گەڕانەوە
        if (e.key === 'Backspace') return
        // دوگمەی Back لەسەر ڕیمۆت — یەکەم جار خانەی نووسین بەجێدەهێڵێت، دووبارە = گەڕانەوە
        e.preventDefault()
        active.blur()
        return
      }
      // پلەیەر خۆی دوگمەکە بەڕێوە دەگرێت (داخستنی یان گەڕانەوە)
      if (playing || document.querySelector('[data-player-root]')) return
      e.preventDefault()
      runBackStep()
    }
    window.addEventListener('keydown', onBack)
    return () => window.removeEventListener('keydown', onBack)
  }, [tvMode, playing, runBackStep])

  // پارێزگاری مێژووی وێبگەڕ — Back ی وێبگەڕ و ئەندرۆید تیڤی پەڕەکە جێناهێڵێت
  // یەکەم Back = popstate → بە هەنگاو دەگەڕێتەوە نەک دەرچوون لە ئەپ
  useEffect(() => {
    if (!tvMode) return
    try { history.pushState({ iptv: 'main' }, '') } catch { /* پشتگوێخستن */ }
    const onPop = () => {
      try { history.pushState({ iptv: 'main' }, '') } catch { /* پشتگوێخستن */ }
      runBackStep()
    }
    window.addEventListener('popstate', onPop)
    return () => window.removeEventListener('popstate', onPop)
  }, [tvMode, runBackStep])

  const loadBanners = useCallback(async () => {
    try {
      const res = await fetch(apiUrl('/api/banner'))
      const data = (await res.json()) as { items: BannerItem[] }
      setBanners(data.items ?? [])
    } catch { /* پشتگوێخستن */ }
  }, [])

  const loadProducts = useCallback(async () => {
    try {
      const res = await fetch(apiUrl('/api/market'))
      const data = (await res.json()) as { items: ProductItem[] }
      setProducts(data.items ?? [])
    } catch { /* پشتگوێخستن */ }
  }, [])

  useEffect(() => {
    if (status?.configured || status?.isAdmin) {
      loadBanners()
      loadProducts()
    }
  }, [status, loadBanners, loadProducts])

  // هەرکات تابی مارکێت دەکرێتەوە، کاڵاکان نوێ دەکرێنەوە
  useEffect(() => {
    if (tab === 'market') loadProducts()
  }, [tab, loadProducts])

  // ---- قوفڵکردنەوەی بەڕێوەبەر — گەڕانەوە بۆ دۆخی ئاسایی ----
  const lockAdmin = useCallback(async () => {
    await fetch(apiUrl('/api/admin'), { method: 'DELETE' })
    await loadStatus()
    setTab('home')
    toast({ title: 'قوفڵکرا', description: 'دەسەڵاتی بەڕێوەبەر داخرا — ئێستا وەک تەماشاکەر دەبینرێت' })
  }, [loadStatus, toast])

  // ---- لێدانی پەخش ----
  // ctx — کۆنتێکستی لیستی کەناڵەکان (بۆ گۆڕینی بە ڕیمۆت). بێ ctx (فلیم) — لیست پاک دەکرێتەوە
  const playItem = useCallback(
    async (item: PlayItem, ctx?: PlayListContext) => {
      const token = ++playTokenRef.current
      playlistRef.current = ctx ?? null
      setPlaylist(ctx ?? null)

      let url = item.url
      let playKind = item.playKind

      // وەرگرتنی بەستەری پەخش لە سێرڤەرەوە (وشەی نهێنی لە سێرڤەردا دەمێنێتەوە)
      if (!url && item.streamRequest) {
        try {
          const params = new URLSearchParams({
            type: item.streamRequest.type,
            id: item.streamRequest.id,
          })
          if (item.streamRequest.ext) params.set('ext', item.streamRequest.ext)
          const res = await fetch(apiUrl(`/api/stream-url?${params.toString()}`))
          const data = (await res.json()) as { url?: string; error?: string }
          if (!res.ok || !data.url) throw new Error(data.error ?? 'نەکرا بەستەری پەخش بەدەست بێت')
          url = data.url
          playKind = item.streamRequest.type === 'live' ? 'hls' : 'direct'
        } catch (e) {
          // ئەگەر لەم ماوەیەدا کەناڵ گۆڕدرابێت — هەڵەی کۆن پشتگوێ بخرێت
          if (token !== playTokenRef.current) return
          toast({
            title: 'هەڵە',
            description: e instanceof Error ? e.message : 'نەکرا پەخشەکە بکرێتەوە',
            variant: 'destructive',
          })
          return
        }
      }

      if (!url) return
      // ئەگەر لەم ماوەیەدا کەناڵی تر کراوەتەوە — ئەم داواکارییە کۆنە پشتگوێ بخە
      if (token !== playTokenRef.current) return
      setEpgLoading(true)
      setPlaying({
        url,
        title: item.name,
        isHls: playKind === 'hls',
        isLive: item.kind === 'live' || !!ctx?.live,
      })

      // وەرگرتنی ئیپیدی بۆ کەناڵی زیندووی Xtream
      if (item.kind === 'live' && status?.mode === 'xtream') {
        fetchShortEpg(item.itemId).then((epg) => {
          if (token !== playTokenRef.current) return
          setEpgLoading(false)
          if (epg) {
            setPlaying((p) => (p ? { ...p, epgNow: epg.now || undefined, epgNext: epg.next || undefined } : p))
          }
        })
      } else {
        setEpgLoading(false)
      }
    },
    [status, toast]
  )

  // ---- گۆڕینی کەناڵ بە ڕیمۆت — وەک CH+ / CH- ی تیڤی ڕاستەقینە ----
  // لە لیستەکەدا دەگەڕێت (بە خولایی — لە کۆتاییەوە دەگەڕێتەوە سەرەتا)
  const switchChannel = useCallback(
    (dir: 1 | -1) => {
      const pl = playlistRef.current
      if (!pl || pl.list.length < 2) return
      const next = (pl.index + dir + pl.list.length) % pl.list.length
      const ctx: PlayListContext = { list: pl.list, index: next, live: pl.live }
      playlistRef.current = ctx
      setPlaylist(ctx)
      void playItem(pl.list[next], ctx)
    },
    [playItem]
  )

  // ---- هەڵبژاردنی کەناڵ لە پێرستە بچووکەکەی ناو پلەیەرەوە (دوگمەی چەپ + OK) ----
  const pickChannel = useCallback(
    (index: number) => {
      const pl = playlistRef.current
      if (!pl || index < 0 || index >= pl.list.length) return
      const ctx: PlayListContext = { list: pl.list, index, live: pl.live }
      playlistRef.current = ctx
      setPlaylist(ctx)
      void playItem(pl.list[index], ctx)
    },
    [playItem]
  )

  // ---- شاشەی بارکردن ----
  if (loadingStatus) {
    return (
      <main className="relative min-h-screen flex items-center justify-center bg-background overflow-hidden">
        <BackdropBlobs />
        <Spinner label="ئامادەکردنی ئەپەکە..." />
      </main>
    )
  }

  // ---- ئەپەکە ڕێک نەخراوە ----
  // بینەر: هیچ PIN یان فۆرمێک نابینێت — تەنها پەیامی ئامادەیی + دوگمەی بەڕێوەبەر
  // بەڕێوەبەر: کۆنسۆڵی تەواوی بەڕێوەبردن دەبینێت (هەموو بەشەکان) تەنانەت پێش ڕێکخستن
  if (!status?.configured && !isAdmin) {
    const appName = status?.appName ?? 'تیڤی ئەپی من'
    const hasAdminPinNow = !!status?.hasAdminPin
    return (
      <main className="relative min-h-screen flex items-center justify-center bg-background overflow-hidden">
        <BackdropBlobs />
        <div className="relative z-10 text-center px-4 animate-fade-up">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-2xl shadow-indigo-500/40 animate-float mb-5">
            <Tv className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold">{appName}</h1>
          <p className="text-sm text-muted-foreground mt-3 max-w-sm mx-auto leading-relaxed">
            ئەپەکە بە زانیاری سەرچاوە ڕێک نەخراوە — بەڕێوەبەر یەک جار زانیارییەکان دادەنێت
            و بۆ هەمیشە پاشەکەوت دەکرێن (پاشکۆی خۆکار + گەڕاندنەوەی خۆکار).
          </p>
          <button
            onClick={() => setAdminOpen(true)}
            className="tv-focus mt-7 inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-violet-500/20 border border-violet-400/30 hover:bg-violet-500/30 text-violet-200 font-bold text-sm transition-colors"
          >
            <Shield className="w-4.5 h-4.5" />
            بەشی بەڕێوەبەر
          </button>
        </div>
        {adminOpen ? (
          <AdminLockDialog
            hasAdminPin={hasAdminPinNow}
            onClose={() => setAdminOpen(false)}
            onUnlocked={async () => {
              setAdminOpen(false)
              await loadStatus()
              // کردنەوەی کۆنسۆڵی تەواوی بەڕێوەبەر — هەموو بەشەکان تێدایە
              setTab('settings')
            }}
          />
        ) : null}
      </main>
    )
  }

  // ---- فۆرمی زانیارییەکان — تەنها بۆ بەڕێوەبەر (یەکەم جار یان گۆڕین) ----
  if (showSetup) {
    return (
      <main className="relative min-h-screen bg-background overflow-hidden">
        <BackdropBlobs />
        <SetupScreen
          initial={status}
          isUpdate={!!status?.configured}
          onSaved={async () => {
            setShowSetup(false)
            await loadStatus()
            setTab('home')
          }}
        />
      </main>
    )
  }

  // کاتێک ڕێکنەخراوە — بەڕێوەبەر تەنها تابی ڕێکخستن دەبینێت (بەشی تر پێویستیان بە سەرچاوەیە)
  const navItems = configured
    ? NAV_ITEMS.filter((n) => isAdmin || n.id !== 'settings')
    : NAV_ITEMS.filter((n) => n.id === 'settings')

  return (
    <main className="relative min-h-screen flex flex-col bg-background overflow-hidden">
      <BackdropBlobs />

      {/* === ڕێکەی لایەنی تیڤی — ناڤیگەیشنی گەورە بۆ ڕیمۆت، تەنها لە دۆخی تیڤی === */}
      {tvMode ? (
        <nav className="tv-rail" aria-label="ناڤیگەیشنی تیڤی">
          <div className="tv-rail-brand">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/30 shrink-0">
              <Tv className="w-5 h-5 text-white" />
            </div>
            <span className="tv-rail-title">{status.appName}</span>
          </div>
          <div className="tv-rail-items">
            {navItems.map((n) => (
              <button
                key={n.id}
                onClick={() => setTab(n.id)}
                aria-current={viewTab === n.id ? 'page' : undefined}
                className={cn('tv-focus tv-rail-btn', viewTab === n.id && 'tv-rail-btn-active')}
              >
                <n.icon className="w-6 h-6" />
                <span>{n.label}</span>
              </button>
            ))}
          </div>
          <div className="tv-rail-foot">
            {status.expiryDate ? (
              <div className="tv-rail-expiry">
                <CalendarClock className="w-3.5 h-3.5 shrink-0" />
                <span>کۆتایی: {fmtExpiry(status.expiryDate)}</span>
              </div>
            ) : null}
            {isAdmin ? (
              <button onClick={lockAdmin} className="tv-focus tv-rail-btn" aria-label="قوفڵکردنەوەی بەڕێوەبەر">
                <ShieldOff className="w-5 h-5" />
                <span>قوفڵکردنەوە</span>
              </button>
            ) : null}
            <button onClick={toggleTv} className="tv-focus tv-rail-btn" aria-label="داخستنی پڕەکی">
              <Minimize2 className="w-5 h-5" />
              <span>داخستنی پڕەکی</span>
            </button>
          </div>
        </nav>
      ) : null}

      {/* === سەرەوە === */}
      <header
        className={cn(
          'app-header relative z-20 sticky top-0 glass-strong border-b border-white/5',
          tvMode && headerHidden && 'tv-header-hidden'
        )}
        onFocusCapture={() => setHeaderHidden(false)}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/30 shrink-0">
              <Tv className="w-5 h-5 text-white" />
            </div>
            <h1 className="font-extrabold text-lg truncate">{status.appName}</h1>
          </div>

          {/* ناڤیگەیشنی دێسکتۆپ */}
          <nav className="tv-desktop-nav hidden md:flex items-center gap-1" aria-label="سەرەکی">
            {navItems.map((n) => (
              <button
                key={n.id}
                onClick={() => setTab(n.id)}
                className={cn(
                  'tv-focus flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all',
                  tab === n.id ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/30' : 'text-muted-foreground hover:text-foreground hover:bg-white/5'
                )}
              >
                <n.icon className="w-4.5 h-4.5" />
                {n.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            {status.expiryDate ? (
              <span className="hidden lg:inline text-xs text-muted-foreground glass px-3 py-1.5 rounded-full">
                کۆتایی: {fmtExpiry(status.expiryDate)}
              </span>
            ) : null}
            {isAdmin ? (
              <button
                onClick={lockAdmin}
                aria-label="قوفڵکردنەوەی بەڕێوەبەر"
                title="قوفڵکردنەوە — گەڕانەوە بۆ دۆخی ئاسایی"
                className="tv-focus w-10 h-10 rounded-xl glass hover:bg-rose-500/20 text-rose-200 flex items-center justify-center transition-colors"
              >
                <ShieldOff className="w-5 h-5" />
              </button>
            ) : null}
            {/* دۆخی تیڤی — پڕەکی + ڕووکاری گەورە بۆ ڕیمۆت */}
            <button
              onClick={toggleTv}
              aria-label="دۆخی تیڤی"
              title={tvMode ? 'داخستنی دۆخی تیڤی' : 'دۆخی تیڤی — پڕەکی بەبێ ناونیشانی وێبگەڕ'}
              className={cn(
                'tv-focus w-10 h-10 rounded-xl flex items-center justify-center transition-colors',
                tvMode
                  ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/30'
                  : 'glass hover:bg-white/10 text-indigo-200'
              )}
            >
              {tvMode ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
            </button>
            <button
              onClick={() => (isAdmin ? setTab('settings') : setAdminOpen(true))}
              aria-label="ڕێکخستنەکان"
              title={isAdmin ? 'ڕێکخستنەکان' : 'کردنەوەی دەسەڵاتی بەڕێوەبەر'}
              className={cn(
                'tv-focus w-10 h-10 rounded-xl flex items-center justify-center transition-colors',
                isAdmin ? 'glass hover:bg-white/10' : 'glass hover:bg-violet-500/20 text-violet-200'
              )}
            >
              {isAdmin ? <Settings className="w-5 h-5" /> : <Shield className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* === ناوەڕۆک === */}
      {/* شاشەکان هەمیشە لە یادەوەریدان — تەنها شاشەی چالاک دەردەکەوێت، ئەوانی تر بە دەمارەوەن */}
      {/* ئەمە گۆڕینی تاب و گەڕانەوە لە پلەیەر بە خێرایی یەکسەر دەکات — داتا دووبارە داگیرا نابێت */}
      <div className="content-shell relative z-10 flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-24 md:pb-6">
        {mountedTabs.home ? (
          <div className={cn(viewTab !== 'home' && 'hidden')} aria-hidden={viewTab !== 'home'}>
            <HomeScreen
              mode={mode}
              banners={banners}
              goTo={setTab}
              appName={status.appName}
            />
          </div>
        ) : null}
        {mountedTabs.settings && isAdmin && status ? (
          <div className={cn(viewTab !== 'settings' && 'hidden')} aria-hidden={viewTab !== 'settings'}>
            <SettingsScreen
              status={status}
              isAdmin={isAdmin}
              onEditCredentials={() => setShowSetup(true)}
              onRefreshStatus={async () => {
                await loadStatus()
              }}
              onLockAdmin={lockAdmin}
              banners={banners}
              onBannersChanged={loadBanners}
              products={products}
              onProductsChanged={loadProducts}
            />
          </div>
        ) : null}
        {mountedTabs.market ? (
          <div className={cn(viewTab !== 'market' && 'hidden')} aria-hidden={viewTab !== 'market'}>
            <MarketScreen products={products} />
          </div>
        ) : null}
        {mountedTabs.live && configured ? (
          <div className={cn(viewTab !== 'live' && 'hidden')} aria-hidden={viewTab !== 'live'}>
            <BrowseScreen
              kind="live"
              mode={mode}
              tvMode={tvMode}
              onPlay={playItem}
              onOpenMovie={(id, name, cover, ext) => setMovieOpen({ id, name, cover, ext: ext || 'mp4' })}
            />
          </div>
        ) : null}
        {mountedTabs.movie && configured ? (
          <div className={cn(viewTab !== 'movie' && 'hidden')} aria-hidden={viewTab !== 'movie'}>
            <BrowseScreen
              kind="movie"
              mode={mode}
              tvMode={tvMode}
              onPlay={playItem}
              onOpenMovie={(id, name, cover, ext) => setMovieOpen({ id, name, cover, ext: ext || 'mp4' })}
            />
          </div>
        ) : null}
      </div>

      {/* === ناڤیگەیشنی مۆبایل === */}
      <nav
        className="md:hidden fixed bottom-0 inset-x-0 z-30 glass-strong border-t border-white/10 pb-[env(safe-area-inset-bottom)]"
        aria-label="سەرەکی"
      >
        <div className="grid" style={{ gridTemplateColumns: `repeat(${navItems.length}, minmax(0, 1fr))` }}>
          {navItems.map((n) => (
            <button
              key={n.id}
              onClick={() => setTab(n.id)}
              className={cn(
                'flex flex-col items-center gap-1 py-3 text-[10px] font-semibold transition-colors min-h-[56px] justify-center',
                tab === n.id ? 'text-indigo-300' : 'text-muted-foreground'
              )}
            >
              <n.icon className="w-5 h-5" />
              {n.label}
            </button>
          ))}
        </div>
      </nav>

      {/* === دیالۆگەکان === */}
      {/* === شاشەی دەستپێکی تیڤی — یەک لێدانی ڕیمۆت = پڕەکی بەبێ ناونیشانی وێبگەڕ === */}
      {tvSplash ? (
        <div className="tv-splash animate-fade-up" role="dialog" aria-label="دەستپێکردن">
          <div className="tv-splash-logo animate-float">
            <Tv className="w-11 h-11 text-white" />
          </div>
          <h2>بەخێربێیت بۆ {status.appName}</h2>
          <p>
            بۆ دەستپێکردن هەر دوگمەیەکی ڕیمۆت دابگرە — ئەپەکە بە پڕەکی دەکرێتەوە
            و ناونیشانی وێبگەڕ لە سەرەوەی شاشە دەشاردرێتەوە.
          </p>
          <button
            autoFocus
            onClick={() => { void enterFullscreen(); setTvSplash(false) }}
            className="tv-splash-btn"
          >
            <Play className="w-6 h-6 fill-white" />
            دەستپێکردن
          </button>
          <p className="tv-splash-hint">دوگمەی OK — یان هەر دوگمەیەکی تر لەسەر ڕیمۆت</p>
        </div>
      ) : null}

      {movieOpen ? (
        <MovieDialog
          vodId={movieOpen.id}
          name={movieOpen.name}
          cover={movieOpen.cover}
          onClose={() => setMovieOpen(null)}
          onPlay={() => {
            const ext = movieOpen.ext || 'mp4'
            setMovieOpen(null)
            playItem({
              kind: 'movie',
              itemId: movieOpen.id,
              name: movieOpen.name,
              logo: movieOpen.cover,
              url: '',
              playKind: 'direct',
              streamRequest: { type: 'movie', id: movieOpen.id, ext },
            })
          }}
        />
      ) : null}

      {/* === پلەیەر === */}
      {playing ? (
        <VideoPlayer
          source={playing}
          onClose={() => {
            setPlaying(null)
            // لیستی کەناڵەکان پاک بکەرەوە — پلەیەر داخرا
            playlistRef.current = null
            setPlaylist(null)
            // لە دۆخی تیڤیدا دوای داخستنی پلەیەر، پڕەکی بەردەوام دەبێت — ناونیشانی وێبگەڕ نەگەڕێتەوە
            if (tvMode) void enterFullscreen()
          }}
          // گۆڕینی کەناڵ بە ڕیمۆت — تەنها کاتێک لیستی کەناڵەکان بەردەستە (زیاتر لە یەک کەناڵ)
          onSwitchChannel={playlist && playlist.list.length > 1 ? switchChannel : undefined}
          channelNumber={playlist ? playlist.index + 1 : undefined}
          // پێرستی بچووکی کەناڵەکان — دوگمەی چەپ دەی کاتەوە، OK کەناڵ دەگۆڕێت، ڕاست/گەڕانەوە دەی داخەنێت
          channelList={playlist ? playlist.list : undefined}
          channelIndex={playlist ? playlist.index : undefined}
          onPickChannel={playlist && playlist.list.length > 1 ? pickChannel : undefined}
        />
      ) : null}

      {/* === دیالۆگی دەسەڵاتی بەڕێوەبەر === */}
      {adminOpen && status ? (
        <AdminLockDialog
          hasAdminPin={!!status.hasAdminPin}
          onClose={() => setAdminOpen(false)}
          onUnlocked={async () => {
            setAdminOpen(false)
            await loadStatus()
            setTab('settings')
            toast({ title: 'بەخێربێیت بەڕێوەبەر 👑', description: 'ئێستا دەتوانیت هەموو شتێک کۆنترۆڵ بکەیت' })
          }}
        />
      ) : null}
    </main>
  )
}

// ---- ناڤیگەیشن ----
const NAV_ITEMS: { id: Tab; label: string; icon: typeof Home }[] = [
  { id: 'home', label: 'ماڵەوە', icon: Home },
  { id: 'live', label: 'کەناڵەکان', icon: Tv },
  { id: 'movie', label: 'فلیمەکان', icon: Film },
  { id: 'market', label: 'مارکێت', icon: ShoppingBag },
  { id: 'settings', label: 'ڕێکخستن', icon: Settings },
]

// ---- پاشبنەمای گڵۆپەکان ----
function BackdropBlobs() {
  return (
    <>
      <div className="glow-blob w-[420px] h-[420px] bg-indigo-600 -top-32 -start-32" />
      <div className="glow-blob w-[380px] h-[380px] bg-violet-600 top-1/3 -end-32" />
      <div className="glow-blob w-[300px] h-[300px] bg-fuchsia-600 bottom-0 start-1/4" />
    </>
  )
}

// ---- شاشەی ماڵەوە ----
function HomeScreen({
  mode,
  banners,
  goTo,
  appName,
}: {
  mode: 'xtream' | 'm3u'
  banners: BannerItem[]
  goTo: (t: Tab) => void
  appName: string
}) {
  return (
    <div className="space-y-8">
      {/* سەرەوە — ئەگەر وێنەی ڕیکلام هەبێت کارووسێل دەردەکەوێت، ئەگەر نا بەخێربێینی ئاسایی */}
      {banners.length > 0 ? (
        <BannerCarousel banners={banners} />
      ) : (
        <section className="relative glass rounded-3xl p-6 sm:p-10 overflow-hidden animate-fade-up">
        <div className="absolute -top-20 -end-20 w-64 h-64 rounded-full bg-indigo-500/20 blur-3xl" />
        <div className="relative">
          <h2 className="text-2xl sm:text-3xl font-extrabold">بەخێربێیت بۆ {appName} 👋</h2>
          <p className="text-muted-foreground mt-2 max-w-xl leading-relaxed">
            هەموو کەناڵ و فلیمەکانت و مارکێتی کاڵاکانت لە یەک شوێن — بە ڕووکاری کوردی و پشتگیری تەواوی تیڤی و مۆبایل.
          </p>
          <div className="flex flex-wrap gap-3 mt-5">
            <button
              onClick={() => goTo('live')}
              className="tv-focus px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 hover:from-indigo-400 hover:to-violet-400 font-bold shadow-lg shadow-indigo-500/30 transition-all flex items-center gap-2"
            >
              <Play className="w-4.5 h-4.5 fill-white" />
              تەماشای کەناڵەکان
            </button>
            <button
              onClick={() => goTo('movie')}
              className="tv-focus px-6 py-3 rounded-xl glass hover:bg-white/10 font-semibold transition-colors flex items-center gap-2"
            >
              <Film className="w-4.5 h-4.5" />
              فلیمەکان
            </button>
          </div>
        </div>
        </section>
      )}

      {/* بەشەکان */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <QuickCard icon={Tv} title="کەناڵی زیندوو" desc="هەموو کەناڵەکانی تۆ لە یەک شوێن" onClick={() => goTo('live')} />
        <QuickCard icon={Film} title="فلیمەکان" desc="کتێبخانەی فلیمەکانت بە پۆلێنەکان" onClick={() => goTo('movie')} />
        <QuickCard icon={ShoppingBag} title="مارکێت" desc="کاڵا و بەرهەمەکان بۆ فرۆشتن" onClick={() => goTo('market')} />
      </section>

      {mode === 'm3u' ? (
        <p className="text-center text-xs text-muted-foreground/60">
          دۆخی M3U چالاکە — فلیمەکان بەپێی گروپەکانی لیستەکەت دابەش کراون
        </p>
      ) : null}
    </div>
  )
}

function QuickCard({ icon: Icon, title, desc, onClick }: { icon: typeof Tv; title: string; desc: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="tv-focus focus-card quick-card glass rounded-2xl p-5 text-start hover:border-indigo-400/50 hover:-translate-y-1 transition-all group"
    >
      <div className="w-12 h-12 rounded-xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
        <Icon className="w-6 h-6 text-indigo-300" />
      </div>
      <h4 className="font-bold">{title}</h4>
      <p className="text-xs text-muted-foreground mt-1">{desc}</p>
    </button>
  )
}

// ---- شاشەی ڕێکخستنەکان ----
function SettingsScreen({
  status,
  isAdmin,
  onEditCredentials,
  onRefreshStatus,
  onLockAdmin,
  banners,
  onBannersChanged,
  products,
  onProductsChanged,
}: {
  status: AppSettingsStatus
  isAdmin: boolean
  onEditCredentials: () => void
  onRefreshStatus: () => void
  onLockAdmin: () => void
  banners: BannerItem[]
  onBannersChanged: () => void
  products: ProductItem[]
  onProductsChanged: () => void
}) {
  const [busy, setBusy] = useState(false)
  const [adminPinInput, setAdminPinInput] = useState('')
  const [uploading, setUploading] = useState(false)
  const bannerFileRef = useRef<HTMLInputElement>(null)

  // پاشکۆی زانیارییەکان — هێنانەوە لە فایل
  const [importingBackup, setImportingBackup] = useState(false)
  const backupFileRef = useRef<HTMLInputElement>(null)

  // فۆرمی کاڵای مارکێت
  const [pName, setPName] = useState('')
  const [pPrice, setPPrice] = useState('')
  const [pDesc, setPDesc] = useState('')
  const [pImage, setPImage] = useState<string | null>(null)
  const [addingProduct, setAddingProduct] = useState(false)
  const productFileRef = useRef<HTMLInputElement>(null)

  // داواکردنی زانیاری هەژمار لە سێرڤەر
  const refreshInfo = async () => {
    setBusy(true)
    try {
      if (status.mode === 'xtream') {
        await fetch(apiUrl('/api/xtream'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: '' }),
        })
      }
      onRefreshStatus()
    } finally {
      setBusy(false)
    }
  }

  // گۆڕینی کۆدی بەڕێوەبەر
  const saveAdminPin = async () => {
    if (adminPinInput && !/^\d{3,6}$/.test(adminPinInput)) {
      alert('کۆدەکە دەبێت ٣ بۆ ٦ ژمارە بێت')
      return
    }
    setBusy(true)
    try {
      const res = await fetch(apiUrl('/api/settings/pin'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminPin: adminPinInput || null }),
      })
      const data = (await res.json()) as { error?: string }
      if (!res.ok) throw new Error(data.error)
      setAdminPinInput('')
      onRefreshStatus()
      alert('کۆدی بەڕێوەبەر نوێکرایەوە')
    } catch {
      alert('نەکرا کۆدی بەڕێوەبەر نوێ بکرێتەوە')
    } finally {
      setBusy(false)
    }
  }

  // ---- پاشکۆ — گەڕاندنەوەی زانیارییەکان لە فایلی JSON ----
  const importBackup = async (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    e.target.value = ''
    if (!f) return
    if (!confirm('دڵنیای لە گەڕاندنەوە؟ زانیارییەکانی ئێستا بە زانیارییەکانی ناو فایلەکە دەگۆڕدرێن.')) return
    setImportingBackup(true)
    try {
      const text = await f.text()
      const json = JSON.parse(text)
      const res = await fetch(apiUrl('/api/backup'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(json),
      })
      const d = (await res.json()) as { error?: string }
      if (!res.ok) throw new Error(d.error)
      alert('زانیارییەکان بە سەرکەوتوویی گەڕاندرانەوە ✅')
      onRefreshStatus()
      onBannersChanged()
      onProductsChanged()
    } catch (err) {
      alert(err instanceof Error ? err.message : 'نەکرا فایلەکە بهێنرێتەوە')
    } finally {
      setImportingBackup(false)
    }
  }

  // ---- وێنە ڕیکلامییەکان — پەرستن و بچووککردنەوە پێش ناردن ----
  const compressImage = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      // GIF یان وێنەی بچووک — ڕاستەوخۆ (بۆ پاراستنی جوڵە)
      if (file.type === 'image/gif' || file.size < 300 * 1024) {
        const reader = new FileReader()
        reader.onload = () => resolve(String(reader.result))
        reader.onerror = () => reject(new Error('نەکرا خوێندرایەوە'))
        reader.readAsDataURL(file)
        return
      }
      const img = new Image()
      const objectUrl = URL.createObjectURL(file)
      img.onload = () => {
        try {
          const maxW = 1920
          const scale = Math.min(1, maxW / (img.width || maxW))
          const canvas = document.createElement('canvas')
          canvas.width = Math.max(1, Math.round(img.width * scale))
          canvas.height = Math.max(1, Math.round(img.height * scale))
          const ctx = canvas.getContext('2d')
          if (!ctx) throw new Error('canvas')
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
          URL.revokeObjectURL(objectUrl)
          resolve(canvas.toDataURL('image/jpeg', 0.82))
        } catch (e) {
          URL.revokeObjectURL(objectUrl)
          reject(e)
        }
      }
      img.onerror = () => {
        URL.revokeObjectURL(objectUrl)
        reject(new Error('وێنەکە نەکرا خوێندرێتەوە'))
      }
      img.src = objectUrl
    })

  const uploadBanners = async (e: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? [])
    e.target.value = ''
    if (files.length === 0) return
    setUploading(true)
    let ok = 0
    for (const f of files) {
      try {
        const data = await compressImage(f)
        const res = await fetch(apiUrl('/api/banner'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ data, name: f.name }),
        })
        if (res.ok) {
          ok++
        } else {
          const d = (await res.json().catch(() => ({}))) as { error?: string }
          alert(d.error ?? `نەکرا وێنەکە بار بکرێت: ${f.name}`)
        }
      } catch {
        alert(`نەکرا وێنەکە بار بکرێت: ${f.name}`)
      }
    }
    setUploading(false)
    if (ok > 0) {
      onBannersChanged()
      alert(`${ok} وێنە زیادکرا`)
    }
  }

  const deleteBanner = async (id: string) => {
    if (!confirm('دڵنیای لە سڕینەوەی ئەم وێنەیە؟')) return
    await fetch(apiUrl(`/api/banner?id=${encodeURIComponent(id)}`), { method: 'DELETE' })
    onBannersChanged()
  }

  // ---- مارکێت — هەڵبژاردنی وێنەی کاڵا ----
  const pickProductImage = async (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    e.target.value = ''
    if (!f) return
    try {
      setPImage(await compressImage(f))
    } catch {
      alert('وێنەکە نەکرا خوێندرێتەوە')
    }
  }

  // زیادکردنی کاڵا بۆ مارکێت
  const addProduct = async () => {
    if (!pName.trim()) return
    setAddingProduct(true)
    try {
      const res = await fetch(apiUrl('/api/market'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: pName.trim(),
          price: pPrice.trim(),
          description: pDesc.trim(),
          image: pImage ?? undefined,
        }),
      })
      const d = (await res.json()) as { error?: string }
      if (!res.ok) throw new Error(d.error)
      setPName('')
      setPPrice('')
      setPDesc('')
      setPImage(null)
      onProductsChanged()
      alert('کاڵاکە زیادکرا ✅')
    } catch (err) {
      alert(err instanceof Error ? err.message : 'نەکرا کاڵاکە زیاد بکرێت')
    } finally {
      setAddingProduct(false)
    }
  }

  // سڕینەوەی کاڵا
  const deleteProduct = async (id: string) => {
    if (!confirm('دڵنیای لە سڕینەوەی ئەم کاڵایە؟')) return
    await fetch(apiUrl(`/api/market?id=${encodeURIComponent(id)}`), { method: 'DELETE' })
    onProductsChanged()
  }

  return (
    <div className="space-y-5 max-w-2xl">
      <div className="flex items-center gap-3">
        <div className="w-11 h-11 rounded-xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center">
          <Settings className="w-5.5 h-5.5 text-indigo-300" />
        </div>
        <h2 className="text-xl sm:text-2xl font-extrabold">ڕێکخستنەکان</h2>
      </div>

      {/* زانیاری هەژمار */}
      <section className="glass rounded-2xl p-5 space-y-3">
        <div className="flex items-center gap-2 mb-1">
          <Info className="w-4 h-4 text-indigo-300" />
          <h3 className="font-bold">زانیاری هەژمار</h3>
        </div>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <InfoRow label="جۆری سەرچاوە" value={status.mode === 'xtream' ? 'Xtream Codes' : status.mode === 'm3u' ? 'لیستی M3U' : '—'} />
          {status.mode === 'xtream' ? (
            <>
              <InfoRow label="سێرڤەر" value={status.host ?? '—'} mono />
              <InfoRow label="بەکارهێنەر" value={status.username ?? '—'} mono />
            </>
          ) : (
            <InfoRow label="بەستەری لیست" value={status.mode === 'm3u' ? 'داخڵکراوە' : '—'} />
          )}
        </div>
        {!status.mode ? (
          <p className="text-xs text-amber-300/90 glass rounded-xl px-4 py-3 leading-relaxed">
            هێشتا هیچ سەرچاوەیەک دانەنراوە — دوگمەی «دەستکاریکردنی زانیارییەکان» لە خوارەوە دابگرە و زانیارییەکانی Xtream یان M3U دابنێ.
          </p>
        ) : null}
        <button
          onClick={refreshInfo}
          disabled={busy}
          className="tv-focus flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 hover:bg-indigo-500/30 transition-colors text-sm font-semibold disabled:opacity-50"
        >
          <RefreshCw className={cn('w-4 h-4', busy && 'animate-spin')} />
          پشکنینی هەژمار
        </button>
      </section>

      {/* زانیارییەکان */}
      <section className="glass rounded-2xl p-5 space-y-4">
        <div className="flex items-center gap-2">
          <KeyRound className="w-4 h-4 text-indigo-300" />
          <h3 className="font-bold">گۆڕینی زانیارییەکان</h3>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          ئەگەر زانیارییەکانی سەرچاوەکەت گۆڕاوە، لێرە نوێیان بکەوە — تەنها تۆ دەستگەیشتنت پێیانە.
        </p>
        <button
          onClick={onEditCredentials}
          className="tv-focus px-5 py-3 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 hover:from-indigo-400 hover:to-violet-400 font-bold text-sm shadow-lg shadow-indigo-500/25 transition-all"
        >
          دەستکاریکردنی زانیارییەکان
        </button>
      </section>

      {/* لیستەکانی M3U — زیادکردن بە جیا بۆ کەناڵ و فلیم + ڕیزکردنەوە و سڕینەوە */}
      <M3uSourcesPanel mode={status.mode} onChanged={onRefreshStatus} />


      {/* دەسەڵاتی بەڕێوەبەر */}
      <section className="glass rounded-2xl p-5 space-y-4 border-violet-400/20">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-violet-300" />
          <h3 className="font-bold">دەسەڵاتی بەڕێوەبەر 👑</h3>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          ئێستا تۆ بەڕێوەبەری — تەنها تۆ دەتوانیت زانیارییەکان بگۆڕیت. کۆدێکی نوێ دادەنێیت بۆ خۆت،
          یان قوفڵ بکەوە و وەک تەماشاکەر سەیری ئەپەکە بکە وەک ئەوانی تر دەیبینن.
        </p>
        <div className="flex flex-wrap gap-2">
          <div className="flex gap-2 flex-1 min-w-56">
            <input
              value={adminPinInput}
              onChange={(e) => setAdminPinInput(e.target.value.replace(/\D/g, '').slice(0, 6))}
              dir="ltr"
              inputMode="numeric"
              placeholder="کۆدی بەڕێوەبەری نوێ..."
              className="tv-focus glass rounded-xl px-4 py-2.5 text-sm outline-none focus:border-violet-400/60 flex-1 text-left tracking-widest"
            />
            <button
              onClick={saveAdminPin}
              disabled={busy}
              className="tv-focus px-5 py-2.5 rounded-xl bg-violet-500 hover:bg-violet-400 text-sm font-bold transition-colors disabled:opacity-50 whitespace-nowrap"
            >
              گۆڕین
            </button>
          </div>
          <button
            onClick={onLockAdmin}
            className="tv-focus flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-sm font-semibold transition-colors"
          >
            <ShieldOff className="w-4 h-4" />
            قوفڵکردنەوە (وەک تەماشاکەر ببینە)
          </button>
        </div>
      </section>

      {/* وێنە ڕیکلامییەکانی ماڵەوە */}
      <section className="glass rounded-2xl p-5 space-y-4">
        <div className="flex items-center gap-2">
          <Images className="w-4 h-4 text-indigo-300" />
          <h3 className="font-bold">وێنە ڕیکلامییەکانی ماڵەوە</h3>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          ئەم وێنانە لە بەشی (ماڵەوە) وەک ڕیکلام پیشان دەدرێن — دەتوانیت چەند وێنەیەک دابنێیت،
          خۆکارانە یەک لە دوای یەک دەگۆڕدرێن. بۆ گۆڕینی وێنەیەک، بیسڕەوە و وێنەی نوێ زیاد بکە.
        </p>
        <input
          ref={bannerFileRef}
          type="file"
          accept="image/png,image/jpeg,image/webp,image/gif"
          multiple
          className="hidden"
          onChange={uploadBanners}
        />
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => bannerFileRef.current?.click()}
            disabled={uploading}
            className="tv-focus flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 hover:from-indigo-400 hover:to-violet-400 font-bold text-sm shadow-lg shadow-indigo-500/25 transition-all disabled:opacity-50"
          >
            <ImagePlus className="w-4 h-4" />
            {uploading ? 'بارکردن...' : 'زیادکردنی وێنە'}
          </button>
          {banners.length > 0 ? (
            <span className="text-xs text-muted-foreground self-center">{banners.length} وێنە چالاکە</span>
          ) : null}
        </div>
        {banners.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {banners.map((b, i) => (
              <div key={b.id} className="relative rounded-xl overflow-hidden border border-white/10">
                { }
                <img src={b.data} alt={b.name || `ڕیکلام ${i + 1}`} className="w-full h-24 object-cover" />
                <span className="absolute top-1.5 start-1.5 px-1.5 py-0.5 rounded bg-black/60 text-[10px] text-white font-bold">
                  {i + 1}
                </span>
                <button
                  onClick={() => deleteBanner(b.id)}
                  className="tv-focus absolute top-1.5 end-1.5 w-7 h-7 rounded-full bg-rose-500/90 hover:bg-rose-500 text-white flex items-center justify-center transition-colors"
                  aria-label="سڕینەوەی وێنە"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-muted-foreground/70">
            هێشتا هیچ وێنەیەک دانەنراوە — بەشی ماڵەوە بە شێوەی ئاسایی پیشان دەدرێت.
          </p>
        )}
      </section>

      {/* بەڕێوەبردنی مارکێت */}
      <section className="glass rounded-2xl p-5 space-y-4">
        <div className="flex items-center gap-2">
          <ShoppingBag className="w-4 h-4 text-emerald-300" />
          <h3 className="font-bold">بەڕێوەبردنی مارکێت 🛒</h3>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          کاڵا زیاد بکە بۆ مارکێتەکەت — لە تابی (مارکێت) بۆ هەموو بەکارهێنەران پیشان دەدرێت.
          نرخەکە بە هەر شێوەیەک دەنووسرێت (وەک: ١٥٠٠٠ د.ع یان ١٠$).
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <input
            value={pName}
            onChange={(e) => setPName(e.target.value)}
            placeholder="ناوی کاڵا *"
            className="tv-focus glass rounded-xl px-4 py-2.5 text-sm outline-none focus:border-emerald-400/60"
          />
          <input
            value={pPrice}
            onChange={(e) => setPPrice(e.target.value)}
            placeholder="نرخ — بۆ نموونە: ١٥٠٠٠ د.ع"
            className="tv-focus glass rounded-xl px-4 py-2.5 text-sm outline-none focus:border-emerald-400/60"
          />
        </div>
        <textarea
          value={pDesc}
          onChange={(e) => setPDesc(e.target.value)}
          placeholder="وردەکاری کاڵا (ئارەزوومەندانە)..."
          rows={2}
          className="tv-focus glass rounded-xl px-4 py-2.5 text-sm outline-none focus:border-emerald-400/60 w-full resize-none"
        />
        <input
          ref={productFileRef}
          type="file"
          accept="image/png,image/jpeg,image/webp,image/gif"
          className="hidden"
          onChange={pickProductImage}
        />
        <div className="flex flex-wrap items-center gap-3">
          {pImage ? (
            <div className="relative w-16 h-16 rounded-xl overflow-hidden border border-white/10 shrink-0">
              { }
              <img src={pImage} alt="وێنەی کاڵا" className="w-full h-full object-cover" />
              <button
                onClick={() => setPImage(null)}
                className="absolute top-0.5 end-0.5 w-5 h-5 rounded-full bg-rose-500/90 text-white flex items-center justify-center"
                aria-label="لابردنی وێنە"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          ) : null}
          <button
            onClick={() => productFileRef.current?.click()}
            className="tv-focus flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-sm font-semibold transition-colors"
          >
            <ImagePlus className="w-4 h-4" />
            {pImage ? 'گۆڕینی وێنە' : 'وێنەی کاڵا'}
          </button>
          <button
            onClick={addProduct}
            disabled={addingProduct || !pName.trim()}
            className="tv-focus flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-sm font-bold text-white transition-colors disabled:opacity-50"
          >
            <Plus className="w-4 h-4" />
            {addingProduct ? 'زیادکردن...' : 'زیادکردنی کاڵا'}
          </button>
        </div>
        {products.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {products.map((p) => (
              <div key={p.id} className="relative rounded-xl overflow-hidden border border-white/10">
                {p.image ? (
                   
                  <img src={p.image} alt={p.name} className="w-full h-20 object-cover" />
                ) : (
                  <div className="w-full h-20 flex items-center justify-center bg-white/5">
                    <Package className="w-6 h-6 text-muted-foreground" />
                  </div>
                )}
                <div className="p-2.5 bg-white/[0.03]">
                  <p className="text-xs font-bold truncate">{p.name}</p>
                  {p.price ? <p className="text-[11px] text-emerald-300 mt-0.5">{p.price}</p> : null}
                </div>
                <button
                  onClick={() => deleteProduct(p.id)}
                  className="tv-focus absolute top-1.5 end-1.5 w-7 h-7 rounded-full bg-rose-500/90 hover:bg-rose-500 text-white flex items-center justify-center transition-colors"
                  aria-label="سڕینەوەی کاڵا"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-muted-foreground/70">
            هێشتا هیچ کاڵایەک دانەنراوە — یەکەم کاڵا زیاد بکە.
          </p>
        )}
      </section>

      {/* ڕێنمایی کیبۆرد بۆ تیڤی */}
      <section className="glass rounded-2xl p-5 space-y-3">
        <div className="flex items-center gap-2">
          <Keyboard className="w-4 h-4 text-indigo-300" />
          <h3 className="font-bold">کۆنترۆڵ بە ڕیمۆتی تیڤی</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-muted-foreground">
          <KbdRow keys="↑ ↓" desc="ڕێژەی دەنگ" />
          <KbdRow keys="← →" desc="١٠ چرکە پێش/دوا (فلیم)" />
          <KbdRow keys="Space / OK" desc="لێدان و وەستان" />
          <KbdRow keys="M" desc="بێدەنگکردن" />
          <KbdRow keys="F" desc="پڕەکی" />
          <KbdRow keys="Esc / Back" desc="داخستنی پلەیەر" />
        </div>
      </section>

      {/* پاشکۆی زانیارییەکان — دەرهێنان و هێنانەوە */}
      <section className="glass rounded-2xl p-5 space-y-4">
        <div className="flex items-center gap-2">
          <DatabaseBackup className="w-4 h-4 text-sky-300" />
          <h3 className="font-bold">پاشکۆی زانیارییەکان 💾</h3>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          زانیارییەکان خۆکارانە پارێزراون: هەر ١٠ خولەک پاشکۆ دەکرێن و ئەگەر شتێک ڕوویدا،
          لە پاشکۆوە خۆکارانە دەگەڕێنرێنەوە. هەروەها دەتوانیت فایلێکی پاشکۆ دابەزێنیت بۆ خۆت —
          لە هەر کاتێکدا بیگەڕێنەوە، تەنانەت لەسەر ڕاژەیەکی تری نوێ.
        </p>
        <input
          ref={backupFileRef}
          type="file"
          accept="application/json,.json"
          className="hidden"
          onChange={importBackup}
        />
        <div className="flex flex-wrap gap-2">
          <a
            href="/api/backup"
            download
            className="tv-focus flex items-center gap-2 px-5 py-3 rounded-xl bg-sky-500/20 border border-sky-400/30 text-sky-200 hover:bg-sky-500/30 font-bold text-sm transition-colors"
          >
            <Download className="w-4 h-4" />
            دابەزاندنی فایلی پاشکۆ
          </a>
          <button
            onClick={() => backupFileRef.current?.click()}
            disabled={importingBackup}
            className="tv-focus flex items-center gap-2 px-5 py-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 font-bold text-sm transition-colors disabled:opacity-50"
          >
            <Upload className="w-4 h-4" />
            {importingBackup ? 'گەڕاندنەوە...' : 'گەڕاندنەوە لە فایل'}
          </button>
        </div>
      </section>

      {/* دەرچوون */}
      <section className="glass rounded-2xl p-5">
        <button
          onClick={async () => {
            if (!confirm('دڵنیای لە دەرچوون؟ زانیارییەکانت دەسڕدرێنەوە و ئەپەکە بەتاڵ دەبێت.')) return
            await fetch(apiUrl('/api/settings/logout'), { method: 'POST' })
            window.location.reload()
          }}
          className="tv-focus flex items-center gap-2 px-5 py-3 rounded-xl bg-rose-500 text-white hover:bg-rose-400 font-bold text-sm transition-colors"
        >
          <LogOut className="w-4 h-4" />
          دەرچوون و سڕینەوەی هەموو زانیارییەکان
        </button>
      </section>
    </div>
  )
}
function InfoRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="glass rounded-xl px-4 py-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={cn('text-sm font-semibold mt-1 truncate', mono && 'font-mono')} dir={mono ? 'ltr' : undefined} style={mono ? { textAlign: 'left' } : undefined}>
        {value}
      </p>
    </div>
  )
}

function KbdRow({ keys, desc }: { keys: string; desc: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="glass px-2.5 py-1 rounded-lg font-mono text-[11px] text-indigo-200 min-w-20 text-center">{keys}</span>
      <span>{desc}</span>
    </div>
  )
}

// ---- کارووسێلی وێنە ڕیکلامییەکان — بەشی ماڵەوە ----
function BannerCarousel({ banners }: { banners: BannerItem[] }) {
  const [idx, setIdx] = useState(0)
  const count = banners.length
  const active = count > 0 ? ((idx % count) + count) % count : 0

  // خۆکارانە گۆڕین هەر ٥ چرکە
  useEffect(() => {
    if (count < 2) return
    const t = setInterval(() => setIdx((i) => i + 1), 5000)
    return () => clearInterval(t)
  }, [count])

  if (count === 0) return null

  return (
    <section className="relative glass rounded-3xl overflow-hidden animate-fade-up" aria-label="ڕیکلام">
      <div className="relative h-[170px] sm:h-[260px] md:h-[340px]">
        {banners.map((b, i) => (
           
          <img
            key={b.id}
            src={b.data}
            alt={b.name || `ڕیکلام ${i + 1}`}
            className={cn(
              'absolute inset-0 w-full h-full object-cover transition-opacity duration-700',
              i === active ? 'opacity-100' : 'opacity-0'
            )}
          />
        ))}

        {banners.length > 1 ? (
          <>
            <button
              onClick={() => setIdx(active - 1)}
              aria-label="وێنەی پێشوو"
              className="tv-focus absolute start-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center backdrop-blur transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
            <button
              onClick={() => setIdx(active + 1)}
              aria-label="وێنەی دواتر"
              className="tv-focus absolute end-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center backdrop-blur transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="absolute bottom-3 inset-x-0 flex items-center justify-center gap-1.5">
              {banners.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setIdx(i)}
                  aria-label={`وێنە ${i + 1}`}
                  className={cn(
                    'h-2 rounded-full transition-all',
                    i === active ? 'w-6 bg-white' : 'w-2 bg-white/50 hover:bg-white/80'
                  )}
                />
              ))}
            </div>
          </>
        ) : null}
      </div>
    </section>
  )
}

// ---- شاشەی مارکێت — پیشاندانی کاڵاکان بۆ هەموو بەکارهێنەران ----
function MarketScreen({ products }: { products: ProductItem[] }) {
  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <div className="w-11 h-11 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center shrink-0">
          <ShoppingBag className="w-5.5 h-5.5 text-emerald-300" />
        </div>
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold">مارکێت</h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            {products.length > 0 ? `${products.length} کاڵا بەردەستە` : 'کاڵا و بەرهەمەکان بۆ فرۆشتن'}
          </p>
        </div>
      </div>

      {products.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
          <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center">
            <Package className="w-8 h-8 text-muted-foreground" />
          </div>
          <p className="text-muted-foreground">هێشتا هیچ کاڵایەک دانەنراوە</p>
        </div>
      ) : (
        <div className="nice-scroll grid-scroll-area market-grid grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4 max-h-[calc(100vh-320px)] overflow-y-auto pr-1 pb-4">
          {products.map((p) => (
            <div
              key={p.id}
              className="relative group glass rounded-2xl overflow-hidden hover:border-emerald-400/50 hover:-translate-y-1 transition-all duration-300 animate-fade-up"
            >
              <div className="relative aspect-square bg-black/25">
                {p.image ? (
                   
                  <img
                    src={p.image}
                    alt={p.name}
                    loading="lazy"
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Package className="w-1/4 h-1/4 text-muted-foreground" />
                  </div>
                )}
                {p.price ? (
                  <span className="absolute bottom-2 start-2 px-2.5 py-1 rounded-lg bg-emerald-500/90 text-white text-xs font-bold shadow-lg">
                    {p.price}
                  </span>
                ) : null}
              </div>
              <div className="p-3">
                <p className="text-sm font-bold truncate" title={p.name}>{p.name}</p>
                {p.description ? (
                  <p className="text-xs text-muted-foreground mt-1 leading-relaxed" style={{ display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                    {p.description}
                  </p>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
