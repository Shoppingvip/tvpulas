'use client'
import { apiUrl } from '@/lib/api'

// شاشەکانی گەڕان — کەناڵی زیندوو و فلیم
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Play, Info, Tv, Film } from 'lucide-react'
import { CategoryChips, SearchInput, Spinner, ErrorBox, LogoImg } from './ui-bits'
import { cn } from '@/lib/utils'
import type { PlayItem, PlayListContext } from '@/lib/iptv'

// ---------- کێشدنی داتا لە سێرڤەر ----------

async function xtreamApi(action: string, extra: Record<string, string> = {}) {
  const res = await fetch(apiUrl('/api/xtream'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action, ...extra }),
  })
  if (!res.ok) {
    const d = (await res.json().catch(() => ({}))) as { error?: string }
    throw new Error(d.error ?? 'هەڵە لە پەیوەندی')
  }
  return res.json()
}

export interface BrowseHandle {
  kind: 'live' | 'movie'
}

// ---------- کارتەکان ----------

// پاککردنەوەی ناوی فلیم لە ناوی تەکنیکی — کوالیتی و کۆدێکان لادەبێت بۆ پیشاندانی جوان
// نموونە: "Alarum.2025.720p.WEBRip.x264.AAC-[YTS.MX]" ← "Alarum 2025"
function prettyMovieName(raw: string): string {
  if (!raw) return raw
  let n = raw.replace(/\.(mp4|mkv|avi|mov)$/i, '')
  n = n.replace(/\[[^\]]*\]/g, ' ') // [ناوی سایت] لابردن
  n = n.replace(/\((?!\d{4}\))[^)]*\)/g, ' ') // پرانتزی بێ ساڵ لابردن — ساڵ دەمێنێتەوە
  n = n.replace(/\b(480p|720p|1080p|2160p|4k)\b/gi, ' ')
  n = n.replace(/\b(web[\-. ]?rip|web[\-. ]?dl|bluray|blu[\-. ]?ray|brrip|hdrip|hdtv|dvdrip|remux)\b/gi, ' ')
  n = n.replace(/\b(x264|x265|h\.?264|h\.?265|hevc|aac|ac3|eac3|ddp|dts|truehd|atmos|10bit|8bit|hdr)\b/gi, ' ')
  n = n.replace(/\b(yts|yify|rarbg|eztv|tgx)\b/gi, ' ')
  n = n.replace(/[\.\-_]+/g, ' ')
  n = n.replace(/\s{2,}/g, ' ').trim()
  n = n.replace(/[\s\-–:]+$/g, '').trim()
  return n || raw
}

function ChannelCard({
  name,
  logo,
  onPlay,
}: {
  name: string
  logo?: string | null
  onPlay: () => void
}) {
  return (
    <button
      onClick={onPlay}
      className="tv-focus focus-card group glass rounded-2xl overflow-hidden text-start animate-fade-up"
      aria-label={`پەخشی ${name}`}
    >
      <div className="card-logo relative flex items-center justify-center bg-black/25 h-28">
        <LogoImg src={logo} alt={name} className="w-full h-full p-4" fallbackIcon="tv" />
        {/* پەڵەی فۆکەس/هۆڤەر — دوگمەی پەخشی گەورە */}
        <div className="absolute inset-0 bg-indigo-500/25 opacity-0 group-focus-visible:opacity-100 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <span className="w-12 h-12 rounded-full bg-indigo-500 shadow-xl shadow-indigo-500/50 flex items-center justify-center scale-90 group-focus-visible:scale-100 group-hover:scale-100 transition-transform">
            <Play className="w-6 h-6 text-white fill-white" />
          </span>
        </div>
      </div>
      <div className="p-3">
        <p className="text-sm font-semibold truncate" title={name}>{name}</p>
        <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
          <Play className="w-3 h-3" />
          پەخش
        </p>
      </div>
    </button>
  )
}

function PosterCard({
  name,
  poster,
  rating,
  onOpen,
  action = 'info',
}: {
  name: string
  poster?: string | null
  rating?: string | null
  onOpen: () => void
  icon: 'movie'
  // کردار — 'info' بۆ فلیمی Xtream (دیالۆگی زانیاری) — 'play' بۆ M3U (ڕاستەوخۆ پەخش)
  action?: 'info' | 'play'
}) {
  const hasPoster = !!poster && poster.trim() !== ''
  return (
    <button
      onClick={onOpen}
      className="tv-focus focus-card group glass rounded-2xl overflow-hidden text-start animate-fade-up"
      aria-label={name}
    >
      <div className="relative aspect-[2/3] bg-black/30">
        {hasPoster ? (
          <LogoImg src={poster} alt={name} className="absolute inset-0 w-full h-full" fallbackIcon="movie" />
        ) : (
          /* نەبوونی پۆستەر لە لیستی M3U — کارتی پۆستەری جوان: گرادیێنت + ناوی فلیم لە ناوەڕاست */
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/20 via-slate-900/40 to-violet-600/25 flex flex-col items-center justify-center gap-3 p-4 text-center">
            <span className="w-14 h-14 rounded-2xl bg-indigo-500/25 border border-indigo-400/30 flex items-center justify-center shrink-0 group-focus-visible:scale-110 group-hover:scale-110 transition-transform">
              <Film className="w-7 h-7 text-indigo-300" />
            </span>
            <p className="text-[15px] font-bold leading-snug line-clamp-4 text-indigo-100/90" title={name}>
              {name}
            </p>
          </div>
        )}
        {rating && Number(rating) > 0 ? (
          <span className="absolute bottom-2 end-2 px-2 py-0.5 rounded-md bg-black/70 text-amber-300 text-xs font-bold">
            ★ {Number(rating).toFixed(1)}
          </span>
        ) : null}
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent opacity-0 group-focus-visible:opacity-100 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-end pb-4">
          <span className="flex items-center gap-1.5 text-sm font-semibold text-white">
            {action === 'play' ? (
              <>
                <Play className="w-4 h-4" />
                پەخش
              </>
            ) : (
              <>
                <Info className="w-4 h-4" />
                زانیاری
              </>
            )}
          </span>
        </div>
      </div>
      {/* ناوی خوارەوە — تەنها کاتێک پۆستەر هەیە، لەبەر ئەوەی لە کارتی بێ پۆستەردا ناوەکە لە ناوەوەیە */}
      {hasPoster ? (
        <div className="p-3">
          <p className="text-sm font-semibold truncate" title={name}>{name}</p>
        </div>
      ) : null}
    </button>
  )
}

// ---------- گەڕانی گشتی ----------

export interface BrowseProps {
  kind: 'live' | 'movie'
  mode: 'xtream' | 'm3u'
  tvMode?: boolean
  // کۆنتێکستی لیست دەنێرینەوە — بۆ گۆڕینی کەناڵ بە ڕیمۆت (دواتر/پێشتر) لەناو پلەیەردا
  onPlay: (item: PlayItem, ctx?: PlayListContext) => void
  onOpenMovie: (vodId: string, name: string, cover: string | null, ext?: string) => void
  onOpenM3uMovie?: (ch: { name: string; logo: string; url: string }) => void
}

export function BrowseScreen({ kind, mode, tvMode, onPlay, onOpenMovie }: BrowseProps) {
  const [categories, setCategories] = useState<{ id: string; name: string; count?: number }[]>([])
  const [activeCat, setActiveCat] = useState('all')
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // داتاکانی Xtream
  const [rawCategories, setRawCategories] = useState<{ category_id: string; category_name: string }[]>([])
  const [items, setItems] = useState<Record<string, unknown>[]>([])

  // داتاکانی M3U
  const [m3uChannels, setM3uChannels] = useState<{ name: string; logo: string; url: string }[]>([])
  const [debouncedSearch, setDebouncedSearch] = useState('')

  const isLive = kind === 'live'
  const kindLabel = isLive ? 'کەناڵی زیندوو' : 'فلیمەکان'
  const m3uKind = isLive ? 'live' : 'movie'

  // گۆڕانی گەڕان بە دواکەوتن
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 350)
    return () => clearTimeout(t)
  }, [search])

  // بارکردنی گروپەکان
  useEffect(() => {
    let cancelled = false
    async function load() {
      setLoading(true)
      setError(null)
      try {
        if (mode === 'xtream') {
          const action = isLive ? 'get_live_categories' : 'get_vod_categories'
          const data = (await xtreamApi(action)) as { category_id: string; category_name: string }[]
          if (!Array.isArray(data)) throw new Error('وەڵامی سێرڤەر نەدرێژ')
          if (cancelled) return
          setRawCategories(data)
          setCategories(data.map((c) => ({ id: c.category_id, name: c.category_name })))
        } else {
          // بەشەکە دەنێرین — لیستی کەناڵ و فلیم بە جیا کۆکراونەتەوە
          const res = await fetch(apiUrl(`/api/m3u?section=${m3uKind}`))
          const data = (await res.json()) as {
            groups?: { name: string; count: number }[]
            error?: string
          }
          if (!res.ok) throw new Error(data.error ?? 'هەڵە لە خوێندنەوەی لیست')
          if (cancelled) return
          setCategories([
            { id: 'all', name: 'هەموو', count: undefined },
            ...(data.groups ?? []).map((g) => ({ id: g.name, name: g.name, count: g.count })),
          ])
        }
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : 'هەڵەیەک ڕوویدا')
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    load()
    return () => { cancelled = true }
  }, [mode, kind, isLive])

  // بارکردنی کەناڵ/فلیمەکان
  const fetchM3u = useCallback(async () => {
    const body = JSON.stringify({
      kind: m3uKind,
      group: activeCat,
      search: debouncedSearch,
      limit: 500,
    })
    let res = await fetch(apiUrl('/api/m3u'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
    })
    // ئەگەر cache هێشتا ئامادە نەبوو — سەرەتا لیست بکێشە بۆ پڕکردنەوەی cache، پاشان دووبارە بپرسە
    if (res.status === 400) {
      await fetch(apiUrl(`/api/m3u?section=${m3uKind}`)).catch(() => {})
      res = await fetch(apiUrl('/api/m3u'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body,
      })
    }
    const data = (await res.json()) as { channels?: { name: string; logo: string; url: string }[] }
    setM3uChannels(data.channels ?? [])
  }, [m3uKind, activeCat, debouncedSearch])

  const fetchXtreamItems = useCallback(async () => {
    const action = isLive ? 'get_live_streams' : 'get_vod_streams'
    const extra: Record<string, string> = {}
    if (activeCat !== 'all') extra.category_id = activeCat
    const data = (await xtreamApi(action, extra)) as Record<string, unknown>[]
    if (!Array.isArray(data)) throw new Error('وەڵامی سێرڤەر نەدرێژ')
    setItems(data)
  }, [isLive, kind, activeCat])

  const dataKey = `${mode}|${kind}|${activeCat}`
  const lastKeys = useRef({ data: '', search: '' })
  const chipsRef = useRef<HTMLDivElement>(null)

  // خێرایی: تەنها بەشێکی لیستەکە ڕەندەر دەکرێت — لیستی گەورە (هەزاران کارت) تیڤی هێواش دەکات
  // «زیاتر پیشان بدە» بەشەکانی دواتر دەکاتەوە بەبێ بارکردنی دووبارە
  const PAGE_SIZE = 600
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE)
  useEffect(() => { setVisibleCount(PAGE_SIZE) }, [dataKey, debouncedSearch])

  // لە دۆخی تیڤیدا دوای بارکردن، فۆکەس بۆ یەکەم چیپی پۆلێن دەبرێت — بۆ ئەوەی ڕیمۆت ڕاستەوخۆ کار بکات
  useEffect(() => {
    if (!tvMode) return
    if (loading || error) return
    const t = setTimeout(() => {
      const first = chipsRef.current?.querySelector<HTMLButtonElement>('button')
      if (first && document.activeElement === document.body) first.focus()
    }, 250)
    return () => clearTimeout(t)
  }, [tvMode, loading, error, dataKey])

  useEffect(() => {
    if (mode === 'm3u') return
    if (lastKeys.current.data === dataKey && items.length > 0) return
    let cancelled = false
    setLoading(true)
    setError(null)
    fetchXtreamItems()
      .catch((e: unknown) => { if (!cancelled) setError(e instanceof Error ? e.message : 'هەڵە') })
      .finally(() => { if (!cancelled) setLoading(false) })
    lastKeys.current.data = dataKey
    return () => { cancelled = true }
  }, [dataKey, mode, fetchXtreamItems])

  useEffect(() => {
    if (mode !== 'm3u') return
    // کلیلەکە گروپ و گەڕان و جۆرەکە پێکەوە دەگرێتەوە — هەر گۆڕانکارییەک دووبارە بارکردن دەکات
    const key = `${dataKey}|${debouncedSearch}`
    if (lastKeys.current.search === key) return
    lastKeys.current.search = key
    let cancelled = false
    setLoading(true)
    setError(null)
    fetchM3u()
      .catch(() => { if (!cancelled) setError('هەڵە لە بارکردنی لیست') })
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [dataKey, debouncedSearch, mode, fetchM3u])

  // فلتەری گەڕان بۆ Xtream
  const filteredItems = useMemo(() => {
    if (mode !== 'xtream') return items
    if (!debouncedSearch.trim()) return items
    const q = debouncedSearch.trim().toLowerCase()
    return items.filter((i) => String(i.name ?? '').toLowerCase().includes(q))
  }, [items, debouncedSearch, mode])

  // ژمارەی ئەنجامەکان — بۆ پیشاندانی کورتی لە سەرەوەی لیست
  const resultCount = mode === 'm3u' ? m3uChannels.length : filteredItems.length

  // لیستی کەناڵە زیندووەکانی Xtream بۆ گۆڕینی بە ڕیمۆت (دواتر/پێشتر) — لە ئەنجامە ئێستاکانەوە دروست دەکرێت
  const liveList = useMemo<PlayItem[]>(() => {
    if (!isLive || mode !== 'xtream') return []
    return filteredItems.map((it) => ({
      kind: 'live' as const,
      itemId: String(it.stream_id ?? ''),
      name: String(it.name ?? ''),
      logo: (it.stream_icon ?? it.cover ?? '') as string,
      url: '', // لە سێرڤەرەوە وەردەگیرێت بە پارێزراوی
      playKind: 'hls' as const,
      streamRequest: { type: 'live' as const, id: String(it.stream_id ?? '') },
    }))
  }, [filteredItems, isLive, mode])

  // لیستی کەناڵە زیندووەکانی M3U — هەمان شێواز بۆ گۆڕینی بە ڕیمۆت
  const m3uLiveList = useMemo<PlayItem[]>(() => {
    if (!isLive || mode !== 'm3u') return []
    return m3uChannels.map((ch) => ({
      kind: 'm3u' as const,
      itemId: ch.url,
      name: ch.name,
      logo: ch.logo,
      url: ch.url,
      playKind: (ch.url.includes('.m3u8') ? 'hls' : 'direct') as 'hls' | 'direct',
    }))
  }, [m3uChannels, isLive, mode])

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center shrink-0">
            <Tv className="w-5.5 h-5.5 text-indigo-300" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold">{kindLabel}</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {mode === 'm3u' ? 'سەرچاوە: لیستی M3U' : 'سەرچاوە: Xtream Codes'}
              {!loading && !error ? (
                <span className="text-indigo-300/90 font-semibold"> · {resultCount} {isLive ? 'کەناڵ' : 'فلیم'}</span>
              ) : null}
            </p>
          </div>
        </div>
        <SearchInput value={search} onChange={setSearch} placeholder={`گەڕان لە ${kindLabel}...`} />
      </div>

      {categories.length > 0 ? (
        <div ref={chipsRef}>
          <CategoryChips categories={categories} active={activeCat} onSelect={setActiveCat} />
        </div>
      ) : null}

      {loading && resultCount === 0 ? (
        <Spinner label="بارکردنی..." />
      ) : error && resultCount === 0 ? (
        <ErrorBox
          message={error}
          onRetry={() => {
            lastKeys.current = { data: '', search: '' }
            if (mode === 'xtream') setItems([])
            else setM3uChannels([])
            setLoading(true)
          }}
        />
      ) : mode === 'xtream' ? (
        <div className="space-y-3">
          {/* خێرایی: لیستی کۆن دەمێنێتەوە لە کاتی نوێکردنەوەدا — گۆڕینی پۆلێن یەکسەر دەبێت */}
          {loading && resultCount > 0 ? (
            <p className="text-xs text-indigo-300/80 animate-pulse flex items-center gap-2">
              <span className="w-3 h-3 rounded-full border-2 border-indigo-400/30 border-t-indigo-400 animate-spin" />
              نوێکردنەوە...
            </p>
          ) : null}
          {error && resultCount > 0 ? (
            <p className="text-xs text-rose-300/90">{error}</p>
          ) : null}
          {filteredItems.length === 0 ? (
            <p className="text-center text-muted-foreground py-12">هیچ ئەنجامێک نەدۆزرایەوە</p>
          ) : (
            <div
            className={cn(
              'nice-scroll grid-scroll-area grid max-h-[calc(100vh-320px)] overflow-y-auto pr-1 pb-4',
              tvMode
                ? (isLive
                  ? 'gap-5 grid-cols-2 sm:grid-cols-3 lg:grid-cols-4'
                  : 'gap-5 grid-cols-3 sm:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6')
                : (isLive
                  ? 'gap-3 sm:gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6'
                  : 'gap-3 sm:gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-7')
            )}
          >
            {filteredItems.slice(0, visibleCount).map((it, i) => {
              const id = String(it.stream_id ?? '')
              const name = String(it.name ?? '')
              const logo = (it.stream_icon ?? it.cover ?? '') as string
              if (isLive) {
                return (
                  <ChannelCard
                    key={id}
                    name={name}
                    logo={logo}
                    onPlay={() =>
                      // لیستەکە دەنێرینەوە — بۆ ئەوەی بە ڕیمۆت بتوانرێت بۆ کەناڵی دواتر/پێشتر بڕوات
                      onPlay(liveList[i], { list: liveList, index: i, live: true })
                    }
                  />
                )
              }
              return (
                <PosterCard
                  key={id}
                  name={name}
                  poster={logo}
                  rating={it.rating as string | undefined}
                  icon="movie"
                  onOpen={() => onOpenMovie(id, name, logo, it.container_extension as string | undefined)}
                />
              )
            })}
          </div>
          )}
          {/* زیاتر پیشان بدە — بەبێ دووبارە بارکردن */}
          {filteredItems.length > visibleCount ? (
            <div className="flex justify-center pt-1 pb-6">
              <button
                onClick={() => setVisibleCount((c) => c + PAGE_SIZE)}
                className="tv-focus px-6 py-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-sm font-bold transition-colors"
              >
                زیاتر پیشان بدە — {filteredItems.length - visibleCount} ی تر
              </button>
            </div>
          ) : null}
        </div>
      ) : (
        <div className="space-y-3">
          {loading && resultCount > 0 ? (
            <p className="text-xs text-indigo-300/80 animate-pulse flex items-center gap-2">
              <span className="w-3 h-3 rounded-full border-2 border-indigo-400/30 border-t-indigo-400 animate-spin" />
              نوێکردنەوە...
            </p>
          ) : null}
          {error && resultCount > 0 ? (
            <p className="text-xs text-rose-300/90">{error}</p>
          ) : null}
          {m3uChannels.length === 0 ? (
            <p className="text-center text-muted-foreground py-12">هیچ ئەنجامێک نەدۆزرایەوە</p>
          ) : (
            <div
            className={cn(
              'nice-scroll grid-scroll-area grid max-h-[calc(100vh-320px)] overflow-y-auto pr-1 pb-4',
              tvMode
                ? (isLive
                  ? 'gap-5 grid-cols-2 sm:grid-cols-3 lg:grid-cols-4'
                  : 'gap-5 grid-cols-3 sm:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6')
                : (isLive
                  ? 'gap-3 sm:gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6'
                  : 'gap-3 sm:gap-4 grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7')
            )}
          >
            {m3uChannels.slice(0, visibleCount).map((ch, i) => {
              const playKind: 'hls' | 'direct' = ch.url.includes('.m3u8') ? 'hls' : 'direct'
              // لە شاشەی کەناڵەکاندا لیستەکە دەنێرینەوە — بۆ گۆڕینی کەناڵ بە ڕیمۆت
              const play = () => onPlay(m3uLiveList[i], { list: m3uLiveList, index: i, live: true })
              // فلیمەکانی M3U بە کارتی پۆستەری ستوونی — جوانتر و ڕێکتر لە کارتی کەناڵ
              if (!isLive) {
                const pretty = prettyMovieName(ch.name)
                return (
                  <PosterCard
                    key={`${ch.url}-${i}`}
                    name={pretty}
                    poster={ch.logo || null}
                    icon="movie"
                    action="play"
                    onOpen={() => onPlay({ kind: 'm3u', itemId: ch.url, name: pretty, logo: ch.logo, url: ch.url, playKind })}
                  />
                )
              }
              return (
                <ChannelCard
                  key={`${ch.url}-${i}`}
                  name={ch.name}
                  logo={ch.logo}
                  onPlay={play}
                />
              )
            })}
          </div>
          )}
          {/* زیاتر پیشان بدە — بەبێ دووبارە بارکردن */}
          {m3uChannels.length > visibleCount ? (
            <div className="flex justify-center pt-1 pb-6">
              <button
                onClick={() => setVisibleCount((c) => c + PAGE_SIZE)}
                className="tv-focus px-6 py-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-sm font-bold transition-colors"
              >
                زیاتر پیشان بدە — {m3uChannels.length - visibleCount} ی تر
              </button>
            </div>
          ) : null}
        </div>
      )}
    </div>
  )
}
