'use client'

// پلەیەری ڤیدیۆ — HLS.js لەگەڵ پشتگیری تەواوی تیڤی و مۆبایل
import { useCallback, useEffect, useRef, useState } from 'react'
import {
  Play, Pause, Volume2, VolumeX, Maximize, Minimize, X,
  RotateCcw, RotateCw, Loader2, AlertTriangle, Settings2, SkipBack, SkipForward, Tv,
} from 'lucide-react'
import { streamProxy, type PlayItem } from '@/lib/iptv'
import { LogoImg } from '@/components/iptv/ui-bits'
import { cn } from '@/lib/utils'

export interface PlayerSource {
  url: string
  title: string
  subtitle?: string
  isHls: boolean
  isLive: boolean
  epgNow?: string
  epgNext?: string
}

interface HlsLevel {
  height: number
  bitrate: number
}

// لیستی کەناڵەکان — بەرزی ڕیز و قەبارەی پەنجەرەی ڕێندەر (بۆ لیستی زۆر درێژ)
const LIST_ITEM_STRIDE = 42 // h-10 (40px) + space-y-0.5 (2px)
const LIST_RENDER_ALL = 120 // هەتا ١٢٠ کەناڵ هەموو ڕیزەکان ڕێندەر دەکرێن
const LIST_WIN = 40 // لە سەروو و خوارەوەی نیشاندەر — بۆ لیستە درێژەکان تەنها ٨١ ڕیز ڕێندەر دەکرێن

export function VideoPlayer({
  source,
  onClose,
  onFinished,
  onSwitchChannel,
  channelNumber,
  channelList,
  channelIndex,
  onPickChannel,
}: {
  source: PlayerSource
  onClose: () => void
  onFinished?: () => void
  // گۆڕینی کەناڵ بە ڕیمۆت (دواتر/پێشتر) — تەنها بۆ کەناڵی زیندوو کە لیستەکە بەردەستە
  onSwitchChannel?: (dir: 1 | -1) => void
  // ژمارەی کەناڵی ئێستا — بۆ ئاماژەی گۆڕینی کەناڵ (وەک تیڤی ڕاستەقینە)
  channelNumber?: number
  // لیستی کەناڵەکان — بۆ پێرستی بچووکی لای چەپ (دوگمەی چەپ دەی کاتەوە، ڕاست/گەڕانەوە دەی داخەنێت)
  channelList?: PlayItem[]
  // ژمارەی کەناڵی ئێستا لە لیستەکەدا (index)
  channelIndex?: number
  // هەڵبژاردنی کەناڵ لە لیستەکەوە
  onPickChannel?: (index: number) => void
}) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const shellRef = useRef<HTMLDivElement>(null)
  const hlsRef = useRef<{ destroy: () => void; currentLevel: number } | null>(null)
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const [playing, setPlaying] = useState(false)
  const [buffering, setBuffering] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [muted, setMuted] = useState(false)
  const [volume, setVolume] = useState(1)
  const [fullscreen, setFullscreen] = useState(false)
  const [controlsVisible, setControlsVisible] = useState(true)
  const [progress, setProgress] = useState(0)
  const [duration, setDuration] = useState(0)
  const [currentTime, setCurrentTime] = useState(0)
  const [levels, setLevels] = useState<HlsLevel[]>([])
  const [activeLevel, setActiveLevel] = useState(-1)
  const [showQuality, setShowQuality] = useState(false)
  const [useProxy, setUseProxy] = useState(false)
  const [retryCount, setRetryCount] = useState(0)
  // ئاماژەی گۆڕینی کەناڵ — وەک تیڤی ڕاستەقینە کاتی گۆڕین دەردەکەوێت
  const [zap, setZap] = useState<{ dir: 1 | -1 } | null>(null)
  const zapTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  // کاتی دوا گۆڕینی کەناڵ — بۆ خۆپاراستن لە گۆڕینی زۆر خێرا بە ڕاگرتنی دوگمەی ڕیمۆت
  const lastZapRef = useRef(0)
  // پێرستی بچووکی کەناڵەکان (دوگمەی چەپ)
  const [listOpen, setListOpen] = useState(false)
  const [listCursor, setListCursor] = useState(0)
  const listScrollRef = useRef<HTMLDivElement>(null)

  const tryPlay = useCallback(() => {
    const v = videoRef.current
    if (v) v.play().catch(() => {})
  }, [])

  // ئامادەکردنی سەرچاوەی پەخش
  useEffect(() => {
    const video = videoRef.current
    if (!video) return
    let cancelled = false

    setError(null)
    setBuffering(true)
    setProgress(0)

    const finalUrl = useProxy ? streamProxy(source.url) : source.url

    async function setup() {
      if (!video) return
      if (hlsRef.current) {
        hlsRef.current.destroy()
        hlsRef.current = null
      }

      if (source.isHls) {
        const mod = await import('hls.js')
        const Hls = mod.default
        if (cancelled) return
        if (Hls.isSupported()) {
          const hls = new Hls({
            maxBufferLength: 30,
            // دەستپێکی خێرا: ٢ سێگمێنت لە لێواری زیندووەوە (لە ٣ەوە)، پارچەی یەکەم پێشتر دەکێشرێت
            liveSyncDurationCount: 2,
            startFragPrefetch: true,
            // دوای بارکردن، خێرا دەگەڕێتەوە لێواری زیندوو — کەمتر وەستانی "لە پاشەوە"
            maxLiveSyncPlaybackRate: 1.5,
            // پاشبەری کەمتر — بیرگەی تیڤی پارێزراو دەمێنێت
            backBufferLength: 60,
            enableWorker: true,
          })
          hlsRef.current = hls
          hls.loadSource(finalUrl)
          hls.attachMedia(video)
          hls.on(Hls.Events.MANIFEST_PARSED, () => {
            if (cancelled) return
            const lv = hls.levels.map((l) => ({ height: l.height ?? 0, bitrate: l.bitrate ?? 0 }))
            setLevels(lv)
            setBuffering(false)
            tryPlay()
          })
          hls.on(Hls.Events.LEVEL_SWITCHED, (_e, d) => setActiveLevel(hls.autoLevelEnabled ? -1 : d.level))
          hls.on(Hls.Events.ERROR, (_e, data) => {
            if (!data.fatal || cancelled) return
            if (data.type === 'networkError' && !useProxy) {
              // هەوڵ بدە بە پرۆکسی دووبارە بکەوە
              setUseProxy(true)
            } else if (data.type === 'mediaError') {
              hls.recoverMediaError()
            } else {
              setBuffering(false)
              setError('پەخشەکە نەکرا بکرێتەوە — لەوانەیە سێرڤەرەکە داخڵ بێت یان بەستەرەکە کۆن بووە')
            }
          })
        } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
          video.src = finalUrl
          tryPlay()
        } else {
          setError('ئەم وێبگەڕە پشتگیری پەخشی HLS ناکات')
        }
      } else {
        video.src = finalUrl
        tryPlay()
      }
    }
    setup()

    return () => {
      cancelled = true
      if (hlsRef.current) {
        hlsRef.current.destroy()
        hlsRef.current = null
      }
    }
  }, [source.url, source.isHls, useProxy, retryCount, tryPlay])

  // کۆنترۆڵەکانی ڤیدیۆ
  useEffect(() => {
    const v = videoRef.current
    if (!v) return
    const onPlay = () => { setPlaying(true) }
    const onPause = () => { setPlaying(false) }
    const onWaiting = () => setBuffering(true)
    const onPlaying = () => { setBuffering(false); setError(null) }
    const onTime = () => {
      setCurrentTime(v.currentTime)
      if (v.duration && isFinite(v.duration)) {
        setProgress((v.currentTime / v.duration) * 100)
        setDuration(v.duration)
      }
    }
    const onMeta = () => setDuration(isFinite(v.duration) ? v.duration : 0)
    const onEnded = () => { setPlaying(false); onFinished?.() }
    const onErr = () => {
      setBuffering(false)
      if (!source.isHls || useProxy) {
        setError('ڤیدیۆکە نەکرا بکرێتەوە — جۆری فایلەکە لەوانەیە پشتگیری نەکرابێت')
      }
    }
    v.addEventListener('play', onPlay)
    v.addEventListener('pause', onPause)
    v.addEventListener('waiting', onWaiting)
    v.addEventListener('playing', onPlaying)
    v.addEventListener('timeupdate', onTime)
    v.addEventListener('loadedmetadata', onMeta)
    v.addEventListener('ended', onEnded)
    v.addEventListener('error', onErr)
    return () => {
      v.removeEventListener('play', onPlay)
      v.removeEventListener('pause', onPause)
      v.removeEventListener('waiting', onWaiting)
      v.removeEventListener('playing', onPlaying)
      v.removeEventListener('timeupdate', onTime)
      v.removeEventListener('loadedmetadata', onMeta)
      v.removeEventListener('ended', onEnded)
      v.removeEventListener('error', onErr)
    }
  }, [onFinished, source.isHls, useProxy])

  // تەشریقەکانی تەماشا
  const togglePlay = useCallback(() => {
    const v = videoRef.current
    if (!v) return
    if (v.paused) v.play().catch(() => {})
    else v.pause()
  }, [])

  const toggleMute = useCallback(() => {
    const v = videoRef.current
    if (!v) return
    v.muted = !v.muted
    setMuted(v.muted)
  }, [])

  const changeVolume = useCallback((val: number) => {
    const v = videoRef.current
    if (!v) return
    v.volume = Math.min(1, Math.max(0, val))
    setVolume(v.volume)
    setMuted(v.volume === 0)
  }, [])

  const seekBy = useCallback((sec: number) => {
    const v = videoRef.current
    if (!v || !isFinite(v.duration)) return
    v.currentTime = Math.min(v.duration - 1, Math.max(0, v.currentTime + sec))
  }, [])

  const toggleFullscreen = useCallback(async () => {
    if (!document.fullscreenElement) {
      await shellRef.current?.requestFullscreen().catch(() => {})
    } else {
      await document.exitFullscreen().catch(() => {})
    }
  }, [])

  useEffect(() => {
    const onFs = () => setFullscreen(!!document.fullscreenElement)
    document.addEventListener('fullscreenchange', onFs)
    return () => document.removeEventListener('fullscreenchange', onFs)
  }, [])

  // گۆڕینی کەناڵ + ئاماژەی تیڤی — وەک CH+ / CH-
  // ڕاگرتنی دوگمەی ڕیمۆت هەر ٤٥٠ms جارێک کەناڵ دەگۆڕێت — وەک تیڤی ڕاستەقینە، نەک ٢٠ کەناڵ لە چرکەیەکدا
  const doSwitchChannel = useCallback(
    (dir: 1 | -1) => {
      if (!onSwitchChannel) return
      const now = Date.now()
      if (now - lastZapRef.current < 450) return
      lastZapRef.current = now
      onSwitchChannel(dir)
      setZap({ dir })
      if (zapTimer.current) clearTimeout(zapTimer.current)
      zapTimer.current = setTimeout(() => setZap(null), 2600)
    },
    [onSwitchChannel]
  )

  // ---- پێرستی بچووکی کەناڵەکان ----
  // دەکرێتەوە بە دوگمەی چەپ — داخەنێت بە ڕاست یان گەڕانەوە — هەڵدەبژێردرێت بە OK
  const canShowList = !!(source.isLive && channelList && channelList.length > 0 && onPickChannel)

  const openChannelList = useCallback(() => {
    if (!canShowList) return
    const idx = typeof channelIndex === 'number' ? Math.min(channelIndex, channelList!.length - 1) : 0
    setListCursor(Math.max(0, idx))
    setListOpen(true)
  }, [canShowList, channelIndex, channelList])

  const moveListCursor = useCallback(
    (d: 1 | -1) => {
      if (!channelList || channelList.length === 0) return
      setListCursor((c) => (c + d + channelList.length) % channelList.length)
    },
    [channelList]
  )

  const pickFromList = useCallback(
    (i: number) => {
      if (!onPickChannel) return
      onPickChannel(i)
      // لیستەکە کراوە دەمێنێتەوە — بە ڕاست یان گەڕانەوە دادەخرێت
    },
    [onPickChannel]
  )

  // کاتێک کەناڵ دەگۆڕدرێت (CH+ / CH- یان هەڵبژاردن) — نیشاندەر بۆ کەناڵی نوێ بجوڵێ
  useEffect(() => {
    if (typeof channelIndex === 'number') setListCursor(channelIndex)
  }, [channelIndex])

  // خشتەی پێرستەکە لەگەڵ نیشاندەر بلێرەوە — بۆ تیڤی کە سکڕۆڵ بە ماوسی نییە
  useEffect(() => {
    if (!listOpen) return
    const cont = listScrollRef.current
    if (!cont) return
    const el = cont.querySelector<HTMLElement>(`[data-idx="${listCursor}"]`)
    if (!el) return
    const top = el.offsetTop
    const bottom = top + el.offsetHeight
    if (top < cont.scrollTop) cont.scrollTop = top
    else if (bottom > cont.scrollTop + cont.clientHeight) cont.scrollTop = bottom - cont.clientHeight
  }, [listOpen, listCursor])

  // کۆنترۆڵی تیڤی و کیبۆرد
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      // دگمەی Back ی ڕیمۆتی تیڤی — Tizen (10009) و webOS (461) و GoBack/BrowserBack
      // هەروەها Backspace (keyCode 8) — بۆ ڕیمۆتەکانی ئەندرۆید تیڤی و بۆکسەکان
      // هەمیشە هەنگاوێک بەرەو دواوە: پێرستە بچووکەکە → پلەیەر (هەرگیز ئەپەکە داخەڵێتەوە نا)
      if (e.keyCode === 10009 || e.keyCode === 461 || e.keyCode === 8 || e.key === 'GoBack' || e.key === 'BrowserBack' || e.key === 'Backspace') {
        e.preventDefault()
        // ئەگەر پێرستی کەناڵەکان کراوەیە — یەکەم گەڕانەوە تەنها پێرستەکە دادەخرێت
        if (listOpen) {
          setListOpen(false)
          return
        }
        onClose()
        return
      }
      // دوگمەی OK ی ڕیمۆتی تیڤی (Enter — keyCode 13) — هەڵبژاردنی کەناڵ لە پێرستەکە
      if (listOpen && (e.key === 'Enter' || e.keyCode === 13)) {
        e.preventDefault()
        pickFromList(listCursor)
        return
      }
      // دوگمەکانی گۆڕینی کەناڵ لەسەر ڕیمۆتی تیڤی — CH+ / CH-
      // Tizen و webOS: keyCode 427 (ChannelUp) و 428 (ChannelDown) — هەندێک ڕیمۆت: PageUp/PageDown
      // هەروەها MediaTrackNext/Previous — بۆ ڕیمۆتەکانی ئەندرۆید تیڤی و بۆکسی ئاسایی
      if (source.isLive && onSwitchChannel) {
        if (e.key === 'ChannelUp' || e.keyCode === 427 || e.key === 'PageUp' || e.key === 'MediaTrackNext') {
          e.preventDefault()
          doSwitchChannel(1)
          showControlsTemporarily()
          return
        }
        if (e.key === 'ChannelDown' || e.keyCode === 428 || e.key === 'PageDown' || e.key === 'MediaTrackPrevious') {
          e.preventDefault()
          doSwitchChannel(-1)
          showControlsTemporarily()
          return
        }
      }
      switch (e.key) {
        case ' ':
          e.preventDefault()
          togglePlay()
          break
        case 'ArrowRight': {
          e.preventDefault()
          // پێرستەکە کراوەیە — دوگمەی ڕاست دەی داخەنێت (لیستەکە لا دەچێت)
          if (listOpen) {
            setListOpen(false)
            return
          }
          if (source.isLive) changeVolume(volume + 0.1)
          else seekBy(10)
          break
        }
        case 'ArrowLeft': {
          e.preventDefault()
          // پێرستەکە کراوەیە — چەپ هیچ ناکات (تەنها ڕاست و گەڕانەوە دادەخەنێت)
          if (listOpen) return
          // دوگمەی چەپ — پێرستی بچووکی کەناڵەکان دەکرێتەوە (تەنها بۆ کەناڵی زیندوو)
          if (canShowList) {
            openChannelList()
            return
          }
          if (source.isLive) changeVolume(volume - 0.1)
          else seekBy(-10)
          break
        }
        case 'ArrowUp':
          e.preventDefault()
          // پێرستەکە کراوەیە — نیشاندەر بەرەو سەرەوە دەجوڵێت
          if (listOpen) {
            moveListCursor(-1)
            return
          }
          // پەخشی زیندوو — سەرەوە وەک CH+ کەناڵ دەگۆڕێت (وەک تیڤی ڕاستەقینە بە ڕیمۆت)
          if (source.isLive && onSwitchChannel) doSwitchChannel(1)
          else changeVolume(volume + 0.1)
          break
        case 'ArrowDown':
          e.preventDefault()
          // پێرستەکە کراوەیە — نیشاندەر بەرەو خوارەوە دەجوڵێت
          if (listOpen) {
            moveListCursor(1)
            return
          }
          // پەخشی زیندوو — خوارەوە وەک CH- کەناڵ دەگۆڕێت
          if (source.isLive && onSwitchChannel) doSwitchChannel(-1)
          else changeVolume(volume - 0.1)
          break
        case 'm':
        case 'M':
          toggleMute()
          break
        case 'f':
        case 'F':
          toggleFullscreen()
          break
        case 'Escape':
          // ئەگەر پێرستەکە کراوەیە — یەکەم Esc تەنها پێرستەکە دادەخرێت
          if (listOpen) {
            setListOpen(false)
            return
          }
          // ئەگەر پلەیەر خۆی لە پڕەکیدا بێت — یەکەم Esc تەنها پڕەکی دەخات (وێبگەڕ)
          if (document.fullscreenElement && document.fullscreenElement === shellRef.current) return
          onClose()
          break
      }
      showControlsTemporarily()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [togglePlay, toggleMute, toggleFullscreen, onClose, seekBy, changeVolume, volume, source.isLive, onSwitchChannel, doSwitchChannel, listOpen, canShowList, openChannelList, moveListCursor, pickFromList, listCursor])

  // شاردنەوەی خۆکاری کۆنترۆڵەکان
  const showControlsTemporarily = useCallback(() => {
    setControlsVisible(true)
    if (hideTimer.current) clearTimeout(hideTimer.current)
    hideTimer.current = setTimeout(() => {
      setControlsVisible(false)
      setShowQuality(false)
    }, 3500)
  }, [])

  useEffect(() => {
    showControlsTemporarily()
    return () => {
      if (hideTimer.current) clearTimeout(hideTimer.current)
      if (zapTimer.current) clearTimeout(zapTimer.current)
    }
  }, [showControlsTemporarily])

  const fmtTime = (s: number) => {
    if (!isFinite(s)) return '—'
    const h = Math.floor(s / 3600)
    const m = Math.floor((s % 3600) / 60)
    const sec = Math.floor(s % 60)
    return h > 0
      ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
      : `${m}:${String(sec).padStart(2, '0')}`
  }

  // ڕێندەری پەنجەرەیی — بۆ لیستی زۆر درێژ تەنها دەوروبەری نیشاندەر ڕێندەر دەکرێت
  // (تیڤی خێرا نەوەستێت کاتێک لیستی هەزاران کەناڵ دەکرێتەوە)
  const listN = channelList?.length ?? 0
  const listWindowed = listN > LIST_RENDER_ALL
  const winStart = listWindowed
    ? Math.max(0, Math.min(listCursor - LIST_WIN, listN - LIST_WIN * 2 - 1))
    : 0
  const winEnd = listWindowed ? Math.min(listN, winStart + LIST_WIN * 2 + 1) : listN

  return (
    <div
      ref={shellRef}
      data-player-root
      className={cn('fixed inset-0 z-50 bg-black flex flex-col', !controlsVisible && 'player-idle')}
      onMouseMove={showControlsTemporarily}
      onClick={showControlsTemporarily}
      role="dialog"
      aria-label={`پەخشی ${source.title}`}
    >
      {/* سەرەوە — ناو و زانیاری */}
      <div
        className={cn(
          'absolute top-0 inset-x-0 z-20 p-4 sm:p-6 bg-gradient-to-b from-black/85 via-black/40 to-transparent transition-opacity duration-300',
          controlsVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
        )}
      >
        <div className="flex items-start gap-3">
          <button
            onClick={onClose}
            aria-label="داخستنی پلەیەر"
            className="tv-focus shrink-0 w-11 h-11 rounded-full glass flex items-center justify-center hover:bg-white/15 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="min-w-0 flex-1">
            <h2 className="text-base sm:text-xl font-bold truncate drop-shadow">{source.title}</h2>
            {source.subtitle ? <p className="text-xs sm:text-sm text-white/60 truncate mt-0.5">{source.subtitle}</p> : null}
            {source.epgNow ? (
              <p className="text-xs sm:text-sm text-indigo-300 truncate mt-1">
                <span className="font-semibold">ئێستا:</span> {source.epgNow}
              </p>
            ) : null}
            {source.epgNext ? (
              <p className="text-xs text-white/45 truncate">
                <span>دواتر:</span> {source.epgNext}
              </p>
            ) : null}
          </div>
          {source.isLive ? (
            <span className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-rose-500/20 border border-rose-400/40 text-rose-300 text-xs font-bold">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse-glow" />
              زیندوو
            </span>
          ) : null}
        </div>
      </div>

      {/* ڤیدیۆ */}
      <div className="flex-1 relative flex items-center justify-center min-h-0">
        <video
          ref={videoRef}
          className="w-full h-full object-contain"
          playsInline
          autoPlay
          preload="auto"
          aria-label={source.title}
        />

        {/* نیشاندانی بارکردن */}
        {buffering && !error ? (
          <div className="absolute inset-0 flex items-center justify-center bg-black/30">
            <Loader2 className="w-14 h-14 text-indigo-400 animate-spin" />
          </div>
        ) : null}

        {/* هەڵە */}
        {error ? (
          <div className="absolute inset-0 flex items-center justify-center bg-black/70 p-6">
            <div className="glass-strong rounded-2xl p-6 max-w-md text-center flex flex-col items-center gap-4">
              <AlertTriangle className="w-12 h-12 text-amber-400" />
              <p className="text-sm leading-relaxed">{error}</p>
              <div className="flex gap-2 flex-wrap justify-center">
                <button
                  onClick={() => { setError(null); setBuffering(true); setRetryCount((c) => c + 1) }}
                  className="tv-focus px-5 py-2.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 transition-colors text-sm font-semibold"
                >
                  دووبارە هەوڵ بدە
                </button>
                {!useProxy ? (
                  <button
                    onClick={() => { setError(null); setUseProxy(true) }}
                    className="tv-focus px-5 py-2.5 rounded-xl glass hover:bg-white/10 transition-colors text-sm"
                  >
                    بە پرۆکسی تاقی بکەوە
                  </button>
                ) : null}
                <button
                  onClick={onClose}
                  className="tv-focus px-5 py-2.5 rounded-xl glass hover:bg-white/10 transition-colors text-sm"
                >
                  داخستن
                </button>
              </div>
            </div>
          </div>
        ) : null}

        {/* ئاماژەی گۆڕینی کەناڵ — وەک تیڤی ڕاستەقینە: ژمارەی کەناڵ + ناوی نوێ */}
        {zap ? (
          <div
            className="absolute top-20 sm:top-24 end-4 sm:end-8 z-30 animate-fade-up"
            role="status"
            aria-live="polite"
          >
            <div className="glass-strong rounded-2xl px-4 py-3.5 sm:px-5 sm:py-4 flex items-center gap-3.5 shadow-2xl shadow-black/60">
              <div className="flex flex-col items-center justify-center w-13 h-13 min-w-13 rounded-xl bg-indigo-500/20 border border-indigo-400/30 shrink-0">
                <span className="text-lg font-extrabold text-indigo-300 leading-none tabular-nums">
                  {channelNumber ?? '•'}
                </span>
                <span className="text-[9px] text-indigo-200/70 font-bold mt-1 tracking-wider">CH</span>
              </div>
              <div className="min-w-0">
                <p className="text-[11px] font-semibold text-white/55 flex items-center gap-1.5">
                  {zap.dir === 1 ? <SkipForward className="w-3.5 h-3.5" /> : <SkipBack className="w-3.5 h-3.5" />}
                  {zap.dir === 1 ? 'کەناڵی دواتر' : 'کەناڵی پێشتر'}
                </p>
                <p className="text-sm font-bold truncate mt-1 max-w-52 sm:max-w-64">{source.title}</p>
              </div>
            </div>
          </div>
        ) : null}

        {/* نیشاندانی پەخش لە ناوەڕاست */}
        {!playing && !buffering && !error ? (
          <button
            onClick={togglePlay}
            aria-label="لێدانی پەخش"
            className="tv-focus absolute w-20 h-20 rounded-full bg-indigo-500/90 flex items-center justify-center shadow-2xl shadow-indigo-500/40 hover:scale-105 transition-transform"
          >
            <Play className="w-9 h-9 fill-white text-white mr-1" />
          </button>
        ) : null}
      </div>

      {/* خوارەوە — کۆنترۆڵەکان */}
      <div
        className={cn(
          'absolute bottom-0 inset-x-0 z-20 p-4 sm:p-5 bg-gradient-to-t from-black/90 via-black/50 to-transparent transition-opacity duration-300',
          controlsVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
        )}
      >
        {/* بارێکەری پێشکەوتن بۆ فلیمەکان */}
        {!source.isLive ? (
          <div className="flex items-center gap-3 mb-3" dir="ltr">
            <span className="text-xs text-white/60 w-14 text-center tabular-nums">{fmtTime(currentTime)}</span>
            <div className="flex-1 h-2 rounded-full bg-white/15 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-violet-400 rounded-full transition-[width] duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
            <span className="text-xs text-white/60 w-14 text-center tabular-nums">{fmtTime(duration)}</span>
          </div>
        ) : null}

        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={togglePlay}
            aria-label={playing ? 'وەستان' : 'لێدان'}
            className="tv-focus w-12 h-12 rounded-full bg-indigo-500 hover:bg-indigo-400 flex items-center justify-center transition-colors shrink-0"
          >
            {playing ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white mr-0.5" />}
          </button>

          {/* دوگمەکانی گۆڕینی کەناڵ — تەنها بۆ پەخشی زیندوو کە لیستەکە بەردەستە */}
          {source.isLive && onSwitchChannel ? (
            <>
              <button
                onClick={() => doSwitchChannel(-1)}
                aria-label="کەناڵی پێشتر"
                title="کەناڵی پێشتر (CH- / PageDown / خوارەوە)"
                className="tv-focus w-11 h-11 rounded-full glass flex items-center justify-center hover:bg-white/15 transition-colors shrink-0"
              >
                <SkipBack className="w-4.5 h-4.5" />
              </button>
              <button
                onClick={() => doSwitchChannel(1)}
                aria-label="کەناڵی دواتر"
                title="کەناڵی دواتر (CH+ / PageUp / سەرەوە)"
                className="tv-focus w-11 h-11 rounded-full glass flex items-center justify-center hover:bg-white/15 transition-colors shrink-0"
              >
                <SkipForward className="w-4.5 h-4.5" />
              </button>
            </>
          ) : null}

          {!source.isLive ? (
            <>
              <button onClick={() => seekBy(-10)} aria-label="١٠ چرکە بۆ دواوە" className="tv-focus w-11 h-11 rounded-full glass flex items-center justify-center hover:bg-white/15 transition-colors shrink-0">
                <RotateCcw className="w-4.5 h-4.5" />
              </button>
              <button onClick={() => seekBy(10)} aria-label="١٠ چرکە بۆ پێشەوە" className="tv-focus w-11 h-11 rounded-full glass flex items-center justify-center hover:bg-white/15 transition-colors shrink-0">
                <RotateCw className="w-4.5 h-4.5" />
              </button>
            </>
          ) : null}

          <div className="flex items-center gap-2 glass rounded-full px-3 h-11 shrink-0">
            <button onClick={toggleMute} aria-label={muted ? 'کردنی دەنگ' : 'بێدەنگکردن'} className="tv-focus">
              {muted || volume === 0 ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={muted ? 0 : volume}
              onChange={(e) => changeVolume(Number(e.target.value))}
              aria-label="ڕێژەی دەنگ"
              className="w-16 sm:w-24 accent-indigo-400"
              dir="ltr"
            />
          </div>

          <div className="flex-1" />

          {/* هەڵبژاردەی کوالیتی */}
          {levels.length > 1 ? (
            <div className="relative shrink-0">
              <button
                onClick={() => setShowQuality((s) => !s)}
                aria-label="کوالیتی"
                className="tv-focus w-11 h-11 rounded-full glass flex items-center justify-center hover:bg-white/15 transition-colors"
              >
                <Settings2 className="w-5 h-5" />
              </button>
              {showQuality ? (
                <div className="absolute bottom-14 inset-inline-end-0 glass-strong rounded-xl p-1.5 min-w-32 max-h-56 overflow-y-auto nice-scroll">
                  <button
                    onClick={() => { if (hlsRef.current) { hlsRef.current.currentLevel = -1 }; setActiveLevel(-1); setShowQuality(false) }}
                    className={cn('tv-focus w-full text-start px-3 py-2 rounded-lg text-xs hover:bg-white/10', activeLevel === -1 && 'text-indigo-300 font-bold')}
                  >
                    خۆکار
                  </button>
                  {levels.map((l, i) => (
                    <button
                      key={i}
                      onClick={() => { if (hlsRef.current) { hlsRef.current.currentLevel = i }; setActiveLevel(i); setShowQuality(false) }}
                      className={cn('tv-focus w-full text-start px-3 py-2 rounded-lg text-xs hover:bg-white/10', activeLevel === i && 'text-indigo-300 font-bold')}
                    >
                      {l.height ? `${l.height}p` : `${Math.round(l.bitrate / 1000)}k`}
                    </button>
                  ))}
                </div>
              ) : null}
            </div>
          ) : null}

          <button
            onClick={toggleFullscreen}
            aria-label={fullscreen ? 'چوونە دەرەوە لە پڕەکی' : 'پڕەکی'}
            className="tv-focus w-11 h-11 rounded-full glass flex items-center justify-center hover:bg-white/15 transition-colors shrink-0"
          >
            {fullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* پێرستی بچووکی کەناڵەکان — دوگمەی چەپ دەی کاتەوە، ڕاست/گەڕانەوە دەی داخەنێت، OK کەناڵ دەگۆڕێت */}
      {listOpen && channelList && channelList.length > 0 ? (
        <div
          className="absolute left-3 sm:left-5 top-1/2 -translate-y-1/2 z-40 w-52 sm:w-72 h-[68%] max-h-[560px] animate-fade-up"
          role="listbox"
          aria-label="لیستی کەناڵەکان"
        >
          <div className="h-full rounded-2xl border border-white/10 bg-black/55 backdrop-blur-md shadow-2xl shadow-black/60 flex flex-col overflow-hidden">
            {/* سەرەوەی پێرست */}
            <div className="shrink-0 px-3 py-2.5 flex items-center justify-between border-b border-white/10 bg-white/[0.03]">
              <span className="text-[11px] font-bold text-white/55">لیستی کەناڵەکان</span>
              <span className="text-[10px] tabular-nums text-white/40">
                {listCursor + 1}/{channelList.length}
              </span>
            </div>
            {/* کەناڵەکان — بە بچوکی و کاڵ، ڤیدیۆکە لە پاشەوە دیار دەمێنێت */}
            <div ref={listScrollRef} className="relative flex-1 overflow-y-auto nice-scroll p-1.5 space-y-0.5">
              {listWindowed ? <div style={{ height: winStart * LIST_ITEM_STRIDE }} aria-hidden="true" /> : null}
              {channelList!.slice(winStart, winEnd).map((ch, i) => {
                const idx = winStart + i
                const isCursor = idx === listCursor
                const isNow = idx === channelIndex
                return (
                  <button
                    key={`${ch.itemId}-${idx}`}
                    data-idx={idx}
                    onClick={() => pickFromList(idx)}
                    className={cn(
                      'w-full flex items-center gap-2 px-2 h-10 rounded-lg text-start transition-colors',
                      isCursor ? 'bg-white/15 text-white' : 'text-white/55 hover:bg-white/5'
                    )}
                  >
                    <span
                      className={cn(
                        'shrink-0 w-7 text-center text-[10px] tabular-nums',
                        isCursor ? 'text-indigo-300 font-bold' : 'text-white/35'
                      )}
                    >
                      {idx + 1}
                    </span>
                    <LogoImg
                      src={ch.logo}
                      alt={ch.name}
                      fallbackIcon="tv"
                      className="shrink-0 w-7 h-7 rounded-md bg-white/5 p-0.5"
                    />
                    <span className="min-w-0 flex-1 truncate text-xs font-semibold">{ch.name}</span>
                    {isNow ? <span className="shrink-0 w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse-glow" /> : null}
                  </button>
                )
              })}
              {listWindowed ? <div style={{ height: (listN - winEnd) * LIST_ITEM_STRIDE }} aria-hidden="true" /> : null}
            </div>
            {/* ڕێنمایی دوگمەکان */}
            <div className="shrink-0 px-3 py-2 border-t border-white/10 text-[9px] leading-relaxed text-white/35">
              سەرەوە/خوارەوە — هەڵبژاردن • OK — گۆڕین • ڕاست/گەڕانەوە — داخستن
            </div>
          </div>
        </div>
      ) : null}
    </div>
  )
}
