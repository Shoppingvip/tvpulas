'use client'
import { apiUrl } from '@/lib/api'

// لاپەڕەی داخڵکردنی زانیارییەکان — Xtream Codes یان M3U
import { useState } from 'react'
import { Tv, Link2, KeyRound, User, Globe, Loader2, CheckCircle2, Film, Shield } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { AppSettingsStatus } from '@/lib/iptv'

export function SetupScreen({
  initial,
  isUpdate,
  onSaved,
}: {
  initial: AppSettingsStatus | null
  isUpdate: boolean
  onSaved: () => void
}) {
  const [mode, setMode] = useState<'xtream' | 'm3u'>(initial?.mode === 'm3u' ? 'm3u' : 'xtream')
  const [appName, setAppName] = useState(initial?.appName ?? 'تیڤی ئەپی من')
  const [host, setHost] = useState(initial?.host ?? '')
  const [username, setUsername] = useState(initial?.username ?? '')
  const [password, setPassword] = useState('')
  const [m3uUrl, setM3uUrl] = useState(initial?.m3uUrl ?? '')
  const [adminPin, setAdminPin] = useState('')
  const [adminPin2, setAdminPin2] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  // ئایا پێویستە کۆدی بەڕێوەبەر دابنرێت (یەکەم جارە)؟
  const needAdminPin = !initial?.hasAdminPin

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setSuccess(null)
    // کۆدی بەڕێوەبەر — پێویستە هەردوو خانەکە یەک بن
    if (needAdminPin) {
      if (adminPin.length < 3) {
        setError('تکایە کۆدی بەڕێوەبەر دابنێ (٣ بۆ ٦ ژمارە) — ئەمە پارێزی ئەپەکەتە')
        return
      }
      if (adminPin !== adminPin2) {
        setError('هەردوو کۆدی بەڕێوەبەر یەک نین')
        return
      }
    }
    setBusy(true)
    try {
      const payload =
        mode === 'xtream'
          ? { appName, adminPin: needAdminPin ? adminPin : undefined, xtreamHost: host, xtreamUsername: username, xtreamPassword: password }
          : { appName, adminPin: needAdminPin ? adminPin : undefined, m3uUrl }
      // کاتێک وشەی نهێنی بەتاڵ ماوەتەوە — واتە نەگۆڕدراوە
      if (mode === 'xtream' && !password && initial?.configured) {
        delete (payload as { xtreamPassword?: string }).xtreamPassword
      }
      const res = await fetch(apiUrl('/api/settings'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = (await res.json()) as { error?: string; expiryDate?: string | null }
      if (!res.ok) throw new Error(data.error ?? 'هەڵەیەک ڕوویدا')
      setSuccess('بەستەر سەرکەوتوو بوو! بارکردنی کەناڵەکان...')
      setTimeout(onSaved, 900)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'هەڵەیەک ڕوویدا')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="relative z-10 min-h-screen flex items-center justify-center p-4 sm:p-6">
      <div className="w-full max-w-lg animate-fade-up">
        {/* لۆگۆ */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-2xl shadow-indigo-500/40 animate-float mb-4">
            <Tv className="w-10 h-10 text-white" />
          </div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-violet-500/20 border border-violet-400/30 text-violet-200 text-xs font-bold mb-3">
            <Shield className="w-3.5 h-3.5" />
            بەشی بەڕێوەبەر
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold">{appName}</h1>
          <p className="text-sm text-muted-foreground mt-2 text-center leading-relaxed">
            {isUpdate
              ? 'زانیارییەکان بگۆڕە — تەنها تۆ کۆنترۆڵی ئەپەکەت دەکەیت'
              : 'بەخێربێیت بەڕێوەبەر! زانیارییەکانی خۆت دابنێ بۆ ئامادەکردنی ئەپەکە بۆ تەماشاکەران'}
          </p>
        </div>

        <form onSubmit={submit} className="glass-strong rounded-3xl p-6 sm:p-8 space-y-5">
          {/* هەڵبژاردەی جۆر */}
          <div className="grid grid-cols-2 gap-2 p-1.5 rounded-2xl bg-white/5 border border-white/10">
            <button
              type="button"
              onClick={() => setMode('xtream')}
              className={cn(
                'tv-focus flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold transition-all',
                mode === 'xtream' ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/30' : 'text-muted-foreground hover:text-foreground'
              )}
            >
              <KeyRound className="w-4 h-4" />
              Xtream Codes
            </button>
            <button
              type="button"
              onClick={() => setMode('m3u')}
              className={cn(
                'tv-focus flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold transition-all',
                mode === 'm3u' ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/30' : 'text-muted-foreground hover:text-foreground'
              )}
            >
              <Link2 className="w-4 h-4" />
              لیستی M3U
            </button>
          </div>

          <div>
            <label className="block text-xs font-semibold text-muted-foreground mb-2">ناوی ئەپەکەت</label>
            <div className="relative">
              <Film className="absolute top-1/2 -translate-y-1/2 start-3.5 w-4 h-4 text-muted-foreground" />
              <input
                value={appName}
                onChange={(e) => setAppName(e.target.value)}
                className="tv-focus w-full glass rounded-xl py-3.5 ps-11 pe-4 text-sm outline-none focus:border-indigo-400/60 transition-colors"
                placeholder="تیڤی ئەپی من"
              />
            </div>
          </div>

          {mode === 'xtream' ? (
            <>
              <div>
                <label className="block text-xs font-semibold text-muted-foreground mb-2">ناونیشانی سێرڤەر</label>
                <div className="relative">
                  <Globe className="absolute top-1/2 -translate-y-1/2 start-3.5 w-4 h-4 text-muted-foreground" />
                  <input
                    value={host}
                    onChange={(e) => setHost(e.target.value)}
                    dir="ltr"
                    className="tv-focus w-full glass rounded-xl py-3.5 ps-11 pe-4 text-sm outline-none focus:border-indigo-400/60 transition-colors text-left"
                    placeholder="http://سێرڤەر:پۆرت"
                    required
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground mb-2">بەکارهێنەر</label>
                  <div className="relative">
                    <User className="absolute top-1/2 -translate-y-1/2 start-3.5 w-4 h-4 text-muted-foreground" />
                    <input
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      dir="ltr"
                      className="tv-focus w-full glass rounded-xl py-3.5 ps-11 pe-4 text-sm outline-none focus:border-indigo-400/60 transition-colors text-left"
                      placeholder="username"
                      required
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground mb-2">
                    وشەی نهێنی {isUpdate && initial?.configured ? '(بۆ نەگۆڕین بەتاڵی بێلە)' : ''}
                  </label>
                  <div className="relative">
                    <KeyRound className="absolute top-1/2 -translate-y-1/2 start-3.5 w-4 h-4 text-muted-foreground" />
                    <input
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      dir="ltr"
                      type="password"
                      className="tv-focus w-full glass rounded-xl py-3.5 ps-11 pe-4 text-sm outline-none focus:border-indigo-400/60 transition-colors text-left"
                      placeholder="password"
                      required={!isUpdate || !initial?.configured}
                    />
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div>
              <label className="block text-xs font-semibold text-muted-foreground mb-2">بەستەری لیستی M3U</label>
              <div className="relative">
                <Link2 className="absolute top-1/2 -translate-y-1/2 start-3.5 w-4 h-4 text-muted-foreground" />
                <input
                  value={m3uUrl}
                  onChange={(e) => setM3uUrl(e.target.value)}
                  dir="ltr"
                  className="tv-focus w-full glass rounded-xl py-3.5 ps-11 pe-4 text-sm outline-none focus:border-indigo-400/60 transition-colors text-left"
                  placeholder="http://... get.php?... type=m3u_plus"
                  required
                />
              </div>
              <p className="text-[11px] text-muted-foreground/70 mt-2 leading-relaxed">
                پاش پاشەکەوتکردن، لە ڕێکخستنەکاندا دەتوانیت لیستی جیا زیاد بکەیت — لیستێک بۆ کەناڵەکان
                و لیستێک بۆ فلیمەکان، بە ڕیزکردنەوە و سڕینەوە.
              </p>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-muted-foreground mb-2">
              <span className="text-violet-300 font-bold">★ کۆدی بەڕێوەبەر</span> — تەنها تۆ دەیزانیت (٣ بۆ ٦ ژمارە)
            </label>
            <div className="relative">
              <Shield className="absolute top-1/2 -translate-y-1/2 start-3.5 w-4 h-4 text-violet-300" />
              <input
                value={adminPin}
                onChange={(e) => setAdminPin(e.target.value.replace(/\D/g, '').slice(0, 6))}
                dir="ltr"
                inputMode="numeric"
                required={!initial?.hasAdminPin}
                className="tv-focus w-full glass rounded-xl py-3.5 ps-11 pe-4 text-sm outline-none focus:border-violet-400/60 transition-colors text-left tracking-widest"
                placeholder="بۆ نموونە: 9988"
              />
            </div>
            <p className="text-[11px] text-muted-foreground/70 mt-2 leading-relaxed">
              بەم کۆدە تۆ دەچیتە ژوورەوە بۆ گۆڕینی زانیارییەکان — بەکارهێنەری تر تەنها کەناڵ و فلیم دەبینن.
            </p>
          </div>
          {needAdminPin ? (
            <div>
              <label className="block text-xs font-semibold text-muted-foreground mb-2">دووبارەکردنەوەی کۆدی بەڕێوەبەر</label>
              <div className="relative">
                <Shield className="absolute top-1/2 -translate-y-1/2 start-3.5 w-4 h-4 text-violet-300" />
                <input
                  value={adminPin2}
                  onChange={(e) => setAdminPin2(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  dir="ltr"
                  inputMode="numeric"
                  required={!initial?.hasAdminPin}
                  className="tv-focus w-full glass rounded-xl py-3.5 ps-11 pe-4 text-sm outline-none focus:border-violet-400/60 transition-colors text-left tracking-widest"
                  placeholder="دووبارە..."
                />
              </div>
            </div>
          ) : null}

          {error ? (
            <div className="rounded-xl bg-rose-500/15 border border-rose-400/30 px-4 py-3 text-sm text-rose-200">
              {error}
            </div>
          ) : null}
          {success ? (
            <div className="rounded-xl bg-emerald-500/15 border border-emerald-400/30 px-4 py-3 text-sm text-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              {success}
            </div>
          ) : null}

          <button
            type="submit"
            disabled={busy}
            className="tv-focus w-full py-4 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 hover:from-indigo-400 hover:to-violet-400 text-white font-bold text-base shadow-xl shadow-indigo-500/30 transition-all disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {busy ? <Loader2 className="w-5 h-5 animate-spin" /> : null}
            {busy ? 'پشکنین...' : isUpdate ? 'نوێکردنەوەی زانیارییەکان' : 'دەستپێکردن'}
          </button>
        </form>

        <p className="text-center text-xs text-muted-foreground/60 mt-6 leading-relaxed">
          زانیارییەکان تەنها لە داتابەیسی ئەپەکەی تۆدا خەزن دەکرێن
        </p>
      </div>
    </div>
  )
}

// دیالۆگی دەسەڵاتی بەڕێوەبەر — کردنەوە بە کۆد یان دروستکردنی کۆد بۆ یەکەم جار
export function AdminLockDialog({
  hasAdminPin,
  onClose,
  onUnlocked,
}: {
  hasAdminPin: boolean
  onClose: () => void
  onUnlocked: () => void
}) {
  const [pin, setPin] = useState('')
  const [pin2, setPin2] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    if (!hasAdminPin && pin !== pin2) {
      setError('هەردوو کۆدەکە یەک نین')
      return
    }
    setBusy(true)
    try {
      const res = await fetch(apiUrl('/api/admin'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin }),
      })
      const data = (await res.json()) as { error?: string }
      if (!res.ok) {
        setError(data.error ?? 'هەڵەیەک ڕوویدا')
        setPin('')
        setPin2('')
        return
      }
      onUnlocked()
    } catch {
      setError('هەڵەیەک ڕوویدا')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <form
        onSubmit={submit}
        onClick={(e) => e.stopPropagation()}
        className="glass-strong rounded-3xl p-7 w-full max-w-sm space-y-5 animate-fade-up"
      >
        <div className="text-center space-y-2">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-violet-500/20 border border-violet-400/30 flex items-center justify-center">
            <Shield className="w-7 h-7 text-violet-300" />
          </div>
          <h2 className="text-lg font-bold">{hasAdminPin ? 'دەسەڵاتی بەڕێوەبەر' : 'دروستکردنی کۆدی بەڕێوەبەر'}</h2>
          <p className="text-xs text-muted-foreground leading-relaxed">
            {hasAdminPin
              ? 'تکایە کۆدی بەڕێوەبەر دابنێ بۆ کردنەوەی ڕێکخستنەکان'
              : 'ئەم کۆدە تەنها بۆ تۆیە — بەم کۆدە دەتوانیت زانیارییەکان بگۆڕیت. بەکارهێنەری تر تەنها تەماشا دەکەن.'}
          </p>
        </div>

        <input
          value={pin}
          onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 6))}
          dir="ltr"
          inputMode="numeric"
          autoFocus
          className="tv-focus w-full glass rounded-xl py-4 text-center text-2xl tracking-[0.5em] outline-none focus:border-violet-400/60 text-left"
          placeholder="••••"
        />
        {!hasAdminPin ? (
          <input
            value={pin2}
            onChange={(e) => setPin2(e.target.value.replace(/\D/g, '').slice(0, 6))}
            dir="ltr"
            inputMode="numeric"
            className="tv-focus w-full glass rounded-xl py-4 text-center text-2xl tracking-[0.5em] outline-none focus:border-violet-400/60 text-left"
            placeholder="دووبارە..."
          />
        ) : null}

        {error ? <p className="text-sm text-rose-300 text-center">{error}</p> : null}

        <div className="flex gap-2">
          <button
            type="button"
            onClick={onClose}
            className="tv-focus flex-1 py-3 rounded-xl glass hover:bg-white/10 font-semibold text-sm transition-colors"
          >
            پاشگەزبوونەوە
          </button>
          <button
            type="submit"
            disabled={busy || pin.length < 3 || (!hasAdminPin && pin2.length < 3)}
            className="tv-focus flex-1 py-3 rounded-xl bg-violet-500 hover:bg-violet-400 font-bold text-sm transition-colors disabled:opacity-50"
          >
            {busy ? '...' : hasAdminPin ? 'کردنەوە' : 'پاشەکەوت'}
          </button>
        </div>
      </form>
    </div>
  )
}
