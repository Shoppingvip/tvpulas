'use client'

// پێکهاتە هاوبەشەکانی ڕووکاری ئەپی تیڤی
import { useState } from 'react'
import { Tv, Film, ImageOff } from 'lucide-react'
import { imgProxy } from '@/lib/iptv'
import { cn } from '@/lib/utils'

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-10">
      <div className="w-10 h-10 rounded-full border-3 border-indigo-500/30 border-t-indigo-400 animate-spin-slow" />
      {label ? <p className="text-sm text-muted-foreground">{label}</p> : null}
    </div>
  )
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-10 text-center">
      <div className="w-12 h-12 rounded-full bg-rose-500/15 flex items-center justify-center text-rose-400 text-xl">!</div>
      <p className="text-sm text-rose-300 max-w-sm">{message}</p>
      {onRetry ? (
        <button
          onClick={onRetry}
          className="tv-focus mt-1 px-5 py-2.5 rounded-xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 hover:bg-indigo-500/30 transition-colors text-sm font-medium"
        >
          دووبارە هەوڵ بدە
        </button>
      ) : null}
    </div>
  )
}

export function LogoImg({
  src,
  alt,
  className,
  fallbackIcon,
}: {
  src?: string | null
  alt: string
  className?: string
  fallbackIcon?: 'tv' | 'movie'
}) {
  const [failed, setFailed] = useState(false)
  const proxied = imgProxy(src)
  if (!proxied || failed) {
    return (
      <div className={cn('flex items-center justify-center bg-white/5 text-muted-foreground', className)}>
        {fallbackIcon === 'movie' ? (
          <Film className="w-1/3 h-1/3 max-w-10 max-h-10" />
        ) : fallbackIcon === 'tv' ? (
          <Tv className="w-1/3 h-1/3 max-w-10 max-h-10" />
        ) : (
          <ImageOff className="w-1/3 h-1/3 max-w-10 max-h-10" />
        )}
        <span className="sr-only">{alt}</span>
      </div>
    )
  }
  return (
    <img
      src={proxied}
      alt={alt}
      loading="lazy"
      onError={() => setFailed(true)}
      className={cn('object-contain', className)}
    />
  )
}

export function CategoryChips({
  categories,
  active,
  onSelect,
}: {
  categories: { id: string; name: string; count?: number }[]
  active: string
  onSelect: (id: string) => void
}) {
  return (
    <div className="nice-scroll flex gap-2 overflow-x-auto pb-2 -mx-1 px-1">
      {categories.map((c) => (
        <button
          key={c.id}
          onClick={() => onSelect(c.id)}
          className={cn(
            'tv-focus cat-chip shrink-0 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all border',
            active === c.id
              ? 'bg-indigo-500 text-white border-indigo-400 shadow-lg shadow-indigo-500/25'
              : 'glass text-muted-foreground hover:text-foreground hover:border-indigo-400/40'
          )}
        >
          {c.name}
          {typeof c.count === 'number' ? (
            <span className={cn('mr-2 text-xs', active === c.id ? 'text-indigo-100' : 'text-muted-foreground/70')}>
              {c.count}
            </span>
          ) : null}
        </button>
      ))}
    </div>
  )
}

export function SearchInput({
  value,
  onChange,
  placeholder,
}: {
  value: string
  onChange: (v: string) => void
  placeholder?: string
}) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder ?? 'گەڕان...'}
      className="tv-focus glass w-full max-w-sm rounded-xl px-4 py-2.5 text-sm outline-none placeholder:text-muted-foreground/60 focus:border-indigo-400/60 transition-colors"
    />
  )
}
