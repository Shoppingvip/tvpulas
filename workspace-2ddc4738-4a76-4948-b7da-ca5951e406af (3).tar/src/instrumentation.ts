// ئەم فایلە کاتێک ئەپ لەسەر Vercel (ی هەر سێرڤەرێکی تر) کاردەکات، جارێک لە دەستپێکدا
// خشتەکانی داتابەیس لە Turso دروست دەکات — ئەگەر پێشتر نەبوون.
// لە ناوخۆدا (بێ TURSO_DATABASE_URL) هیچ ناکات.
export async function register() {
  if (process.env.NEXT_RUNTIME !== 'nodejs') return
  const tursoUrl = process.env.TURSO_DATABASE_URL
  if (!tursoUrl) return

  try {
    const { createClient } = await import('@libsql/client')
    const client = createClient({
      url: tursoUrl,
      authToken: process.env.TURSO_AUTH_TOKEN,
    })

    await client.executeMultiple(`
      CREATE TABLE IF NOT EXISTS "Settings" (
          "id" TEXT NOT NULL PRIMARY KEY DEFAULT 'main',
          "appName" TEXT NOT NULL DEFAULT 'تیڤی ئەپی من',
          "adminPin" TEXT,
          "xtreamHost" TEXT,
          "xtreamUsername" TEXT,
          "xtreamPassword" TEXT,
          "m3uUrl" TEXT,
          "updatedAt" DATETIME NOT NULL
      );

      CREATE TABLE IF NOT EXISTS "M3uSource" (
          "id" TEXT NOT NULL PRIMARY KEY,
          "name" TEXT NOT NULL DEFAULT '',
          "url" TEXT NOT NULL,
          "section" TEXT NOT NULL DEFAULT 'both',
          "sortOrder" INTEGER NOT NULL DEFAULT 0,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS "DriveVideo" (
          "id" TEXT NOT NULL PRIMARY KEY,
          "fileId" TEXT NOT NULL,
          "name" TEXT NOT NULL,
          "folderId" TEXT,
          "folderName" TEXT,
          "thumbnail" TEXT,
          "size" TEXT,
          "sortOrder" INTEGER NOT NULL DEFAULT 0,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      );
      CREATE UNIQUE INDEX IF NOT EXISTS "DriveVideo_fileId_key" ON "DriveVideo"("fileId");

      CREATE TABLE IF NOT EXISTS "Favorite" (
          "id" TEXT NOT NULL PRIMARY KEY,
          "itemType" TEXT NOT NULL,
          "itemId" TEXT NOT NULL,
          "name" TEXT NOT NULL,
          "logo" TEXT,
          "extra" TEXT,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      );
      CREATE UNIQUE INDEX IF NOT EXISTS "Favorite_itemType_itemId_key" ON "Favorite"("itemType", "itemId");

      CREATE TABLE IF NOT EXISTS "History" (
          "id" TEXT NOT NULL PRIMARY KEY,
          "itemType" TEXT NOT NULL,
          "itemId" TEXT NOT NULL,
          "name" TEXT NOT NULL,
          "logo" TEXT,
          "extra" TEXT,
          "watchedAt" DATETIME NOT NULL
      );
      CREATE UNIQUE INDEX IF NOT EXISTS "History_itemType_itemId_key" ON "History"("itemType", "itemId");

      CREATE TABLE IF NOT EXISTS "Banner" (
          "id" TEXT NOT NULL PRIMARY KEY,
          "name" TEXT NOT NULL DEFAULT '',
          "data" TEXT NOT NULL,
          "sortOrder" INTEGER NOT NULL DEFAULT 0,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS "Product" (
          "id" TEXT NOT NULL PRIMARY KEY,
          "name" TEXT NOT NULL,
          "price" TEXT NOT NULL DEFAULT '',
          "description" TEXT NOT NULL DEFAULT '',
          "image" TEXT,
          "sortOrder" INTEGER NOT NULL DEFAULT 0,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      );
    `)
    // ستوونی driveApiKey — بۆ داتابەیسە کۆنەکان (هەڵەی «duplicate column» پشتگوێ دەخرێت)
    try {
      await client.execute(`ALTER TABLE "Settings" ADD COLUMN "driveApiKey" TEXT`)
    } catch { /* پێشتر هەیە */ }
    console.log('[instrumentation] خشتەکانی Turso ئامادەن')
  } catch (e) {
    console.error('[instrumentation] هەڵە لە دروستکردنی خشتەکان:', e)
  }
}
