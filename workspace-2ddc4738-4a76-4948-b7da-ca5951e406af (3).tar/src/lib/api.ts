// ناونیشانی بنکەی API — بۆ کاتێک فرۆنت و لە دوو شوێنی جیاواز مێژ دەبن
// (بۆ نموونە: فرۆنت لەسەر InfinityFree + API لەسەر Vercel)
//
// ڕیزبەندی خوێندنەوە:
//   1. window.__API_BASE__ — لە فایلی /config.js دادەنرێت (دواترین وەسڵ — دەستکاری بکە بەبێ دووبارە بنیاتنان)
//   2. process.env.NEXT_PUBLIC_API_BASE — لە کاتی بنیاتنان (build) دیاری دەکرێت
//   3. "" — بەتاڵ = هەمان دۆمەین (dev و Vercel ئاسایی)
export function apiUrl(path: string): string {
  const runtimeBase =
    typeof window !== 'undefined'
      ? ((window as unknown as { __API_BASE__?: string }).__API_BASE__ ?? '')
      : ''
  const base = (runtimeBase.trim() || process.env.NEXT_PUBLIC_API_BASE || '').replace(/\/+$/, '')
  return base + path
}
