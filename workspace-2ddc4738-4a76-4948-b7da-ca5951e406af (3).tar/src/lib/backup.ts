// پاشکۆکردنی فایلی داتابەیس — تەنها لە دۆخی SQLite ی ناوخۆیی (لە Turso پێویست نییە)
import { copyFileSync, mkdirSync, existsSync, statSync, readdirSync, unlinkSync } from 'fs'
import { dirname, join } from 'path'

const DATABASE_URL = process.env.DATABASE_URL ?? 'file:/home/z/my-project/db/custom.db'
const dbPath = DATABASE_URL.replace(/^file:/, '')
const backupDir = join(dirname(dbPath), 'backups')

// پاشکۆیەکی نوێ دروست دەکات — ئەگەر سەرکەوتوو بوو true دەگەڕێنێتەوە
export function backupDbFile(tag = ''): boolean {
  if (process.env.TURSO_DATABASE_URL) return false // Turso — پاشکۆی فایل بەکار نایەت
  try {
    if (!existsSync(dbPath) || statSync(dbPath).size < 4096) return false
    mkdirSync(backupDir, { recursive: true })
    const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14)
    const name = tag ? `custom-${stamp}-${tag}.db` : `custom-${stamp}.db`
    copyFileSync(dbPath, join(backupDir, name))
    // زۆر پاشکۆ مەهێڵە — ٢٠ی کۆتایی
    const files = readdirSync(backupDir)
      .filter((f) => f.endsWith('.db'))
      .map((f) => join(backupDir, f))
      .sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs)
    for (const old of files.slice(20)) {
      try {
        unlinkSync(old)
      } catch {}
    }
    return true
  } catch {
    return false
  }
}
