// کتێبخانەی Google Drive — شیکردنەوەی بەستەری هاوبەش، لیستی فۆڵدەر و بەستەری پەخش
// بنەڕەت بە embeddedfolderview کار دەکات — بێ هەژمار و بێ API Key
// ئەگەر کلیلی API دانرابێت — بۆ فۆڵدەر بە Drive API v3 وردتر کار دەکات (ناوی فۆڵدەر و قەبارە)

export const DRIVE_FILE_EXTS =
  /\.(mp4|mkv|avi|mov|webm|m4v|mpg|mpeg|ts|flv|wmv|3gp|ogv|mts|m2ts)$/i

// بەستەری پەخشی ڕاستەوخۆی فایلەکە — بە confirm=t لە پەڕەی ئاگاداری ڤایرۆس دەڕوات
export function driveStreamUrl(fileId: string): string {
  return `https://drive.usercontent.google.com/download?id=${encodeURIComponent(fileId)}&export=download&confirm=t`
}

// بەستەری وێنۆچکەی فایلەکە — بۆ پۆستەری فلیمەکە
export function driveThumbUrl(fileId: string, size = 400): string {
  return `https://drive.google.com/thumbnail?id=${encodeURIComponent(fileId)}&sz=w${size}`
}

// ناسنامەی فایل لە هەر شێوەیەکی بەستەری Drive:
// https://drive.google.com/file/d/FILE_ID/view...
// https://drive.google.com/open?id=FILE_ID
// https://drive.google.com/uc?export=download&id=FILE_ID
// https://drive.usercontent.google.com/download?id=FILE_ID...
export function extractFileId(url: string): string | null {
  const m =
    /[?&]id=([\w-]{10,})/.exec(url) ??
    /\/file\/d\/([\w-]{10,})/.exec(url) ??
    /\/download\/([\w-]{10,})/.exec(url)
  return m?.[1] ?? null
}

// ناسنامەی فۆڵدەر لە بەستەری:
// https://drive.google.com/drive/folders/FOLDER_ID...
// https://drive.google.com/drive/u/0/folders/FOLDER_ID
export function extractFolderId(url: string): string | null {
  const m = /\/folders\/([\w-]{10,})/.exec(url)
  return m?.[1] ?? null
}

// شیکردنەوەی هەر بەستەرێکی Drive — فایل یان فۆڵدەر
export function extractDriveId(link: string): { type: 'file' | 'folder'; id: string } | null {
  const folderId = extractFolderId(link)
  if (folderId) return { type: 'folder', id: folderId }
  const fileId = extractFileId(link)
  if (fileId) return { type: 'file', id: fileId }
  return null
}

// پاککردنەوەی ناوی فلیم لە ناوی فایلەوە — درێژکردنەکە و خاڵ و هێڵی ژێر دەسڕێتەوە
export function cleanMovieName(fileName: string): string {
  let n = fileName.replace(DRIVE_FILE_EXTS, '')
  n = n.replace(/[_]+/g, ' ').replace(/\.{2,}/g, '.').replace(/\s+/g, ' ').trim()
  return n || fileName
}

export interface DriveFolderFile {
  id: string
  name: string
  thumbnail?: string | null
  size?: string | null
}

export interface DriveFolderResult {
  folderName: string | null
  files: DriveFolderFile[]
}

// لیستی فۆڵدەر — ئەگەر کلیلی API هەبوو بە v3، ئەگینا بە embeddedfolderview (بێ کلیل)
export async function listFolderVideos(
  folderId: string,
  apiKey?: string | null
): Promise<DriveFolderResult> {
  if (apiKey) {
    try {
      const r = await listFolderViaApi(folderId, apiKey)
      if (r.files.length > 0) return r
      // ئەگەر بە کلیل هیچ نەدۆزرایەوە — لەوانەیە کلیلەکە سنووردار بێت، بە embeddedfolderview تاقی بکەرەوە
    } catch {
      /* کەوتە خوارەوە — بە embeddedfolderview تاقی بکەرەوە */
    }
  }
  return listFolderEmbedded(folderId)
}

// ---- ڕێگای ١ — Google Drive API v3 (پێویستی بە API Key هەیە) ----
async function listFolderViaApi(folderId: string, apiKey: string): Promise<DriveFolderResult> {
  const listUrl =
    `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
      `'${folderId}' in parents and trashed = false`
    )}&fields=${encodeURIComponent('nextPageToken,files(id,name,size,thumbnailLink,mimeType)')}&pageSize=200&key=${encodeURIComponent(apiKey)}`

  const res = await fetch(listUrl, { signal: AbortSignal.timeout(30000) }).catch((e: unknown) => {
    throw new Error(netErrMsg(e))
  })
  if (res.status === 403 || res.status === 400) {
    throw new Error('کلیلی API ەکە کار ناکات یان سنووردارە — پشکنینی بکە یان بیبەسەر بکە')
  }
  if (res.status === 404) throw new Error('فۆڵدەرەکە نەدۆزرایەوە — بەستەرەکە پشکنین بکە')
  if (!res.ok) throw new Error('Google Drive وەڵام نەدایەوە — دووبارە هەوڵ بدە')

  const data = (await res.json()) as {
    files?: Array<{ id: string; name: string; size?: string; thumbnailLink?: string; mimeType?: string }>
  }
  const files: DriveFolderFile[] = (data.files ?? [])
    .filter((f) => DRIVE_FILE_EXTS.test(f.name) || /video\//i.test(f.mimeType ?? ''))
    .map((f) => ({
      id: f.id,
      name: f.name,
      thumbnail: f.thumbnailLink ?? null,
      size: f.size ?? null,
    }))

  // ناوی فۆڵدەرەکە
  let folderName: string | null = null
  try {
    const nr = await fetch(
      `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(folderId)}?fields=name&key=${encodeURIComponent(apiKey)}`,
      { signal: AbortSignal.timeout(15000) }
    )
    if (nr.ok) {
      const nd = (await nr.json()) as { name?: string }
      folderName = nd.name?.slice(0, 60) ?? null
    }
  } catch { /* ناوی فۆڵدەر ئارەزوومەندانەیە */ }

  return { folderName: folderName || 'Google Drive', files }
}

// ---- ڕێگای ٢ — embeddedfolderview (بێ API Key — بۆ فۆڵدەری گشتی) ----
async function listFolderEmbedded(folderId: string): Promise<DriveFolderResult> {
  const url = `https://drive.google.com/embeddedfolderview?id=${encodeURIComponent(folderId)}#list`
  const res = await fetch(url, {
    signal: AbortSignal.timeout(30000),
    headers: {
      'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
      Accept: 'text/html,*/*',
    },
  }).catch((e: unknown) => {
    throw new Error(netErrMsg(e))
  })

  if (res.status === 404) throw new Error('فۆڵدەرەکە نەدۆزرایەوە — بەستەرەکە پشکنین بکە')
  if (res.status === 403 || res.status === 401) {
    throw new Error('فۆڵدەرەکە گشتی نییە — لە Drive بیبەرەوە بە «هەر کەسێک بە بەستەر»')
  }
  if (!res.ok) throw new Error('فۆڵدەرەکە وەڵام نەدایەوە — دووبارە هەوڵ بدە')

  const html = await res.text()

  // فۆڵدەری تایبەت — پەڕەی چوونەژوورەوە دەگەڕێتەوە
  if (/accounts\.google\.com\/(ServiceLogin|v3\/signin)/i.test(html)) {
    throw new Error('فۆڵدەرەکە گشتی نییە — لە Drive بیبەرەوە بە «هەر کەسێک بە بەستەر»')
  }

  const folderName =
    /<title>(?:Google Drive[^—-]*[—-]\s*)?([^<]+)<\/title>/i.exec(html)?.[1]?.trim() ?? null

  // هەر تۆمارێک: <div class="flip-entry" id="entry-FILE_ID" ...> ... <div class="flip-entry-title">NAME</div>
  // ناوەوەیەکەی وێنۆچکەکەی تێدایە: <img src=".../thumbnail?id=FILE_ID&sz=w200">
  const files: DriveFolderFile[] = []
  const re = /<div class="flip-entry" id="entry-([\w-]+)"([\s\S]*?)<div class="flip-entry-title">([\s\S]*?)<\/div>/g
  let m: RegExpExecArray | null
  while ((m = re.exec(html)) !== null) {
    const fileId = m[1]
    const block = m[2]
    const name = decodeEntities(m[3]).trim()
    if (!DRIVE_FILE_EXTS.test(name)) continue // تەنها فایلی ڤیدیۆ — وێنە و بەڵگەنامە پشتگوێ دەخرێن
    const thumb = /src="(https:\/\/drive\.google\.com\/thumbnail[^"]+)"/.exec(block)?.[1] ?? null
    files.push({ id: fileId, name, thumbnail: thumb, size: null })
  }

  if (files.length === 0) {
    // ئەگەر هیچ فایلێک نەبوو — یان بەتاڵە یان هیچ ڤیدیۆیەکی تێدا نییە
    throw new Error('هیچ فایلێکی ڤیدیۆ لەم فۆڵدەرەدا نەدۆزرایەوە')
  }

  return { folderName: decodeEntities(folderName ?? '').slice(0, 60) || 'Google Drive', files }
}

// ناوی ڕەسەنی فایلەکە لە پەڕەی Drive وەردەگرێت — <title>NAME - Google Drive</title>
// ئەگەر نەکرا null دەگەڕێنێتەوە
export async function fetchFileName(fileId: string): Promise<string | null> {
  try {
    const res = await fetch(`https://drive.google.com/file/d/${encodeURIComponent(fileId)}/view`, {
      signal: AbortSignal.timeout(15000),
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
        Accept: 'text/html,*/*',
      },
      redirect: 'follow',
    })
    if (!res.ok) return null
    const html = await res.text()
    const t = /<title>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? ''
    const name = decodeEntities(t).replace(/\s*-\s*Google Drive\s*$/i, '').trim()
    return name || null
  } catch {
    return null
  }
}

// پشکنینی دەستگەیشتنی گشتی فایلەکە — تەنها یەک بایت دەکێشێت (Range: 0-0)
// ئەگەر گشتی نەبێت هەڵە بە کوردی دەگەڕێنێتەوە
export async function verifyFilePublic(fileId: string): Promise<void> {
  const res = await fetch(driveStreamUrl(fileId), {
    method: 'GET',
    headers: { Range: 'bytes=0-0', 'User-Agent': 'Mozilla/5.0 (IPTV Web Player)' },
    signal: AbortSignal.timeout(20000),
    redirect: 'follow',
  }).catch((e: unknown) => {
    throw new Error(netErrMsg(e))
  })
  // بۆ ئەوەی بەدەن دابەزێنرێت — دەستەبەر دەبەین پێش خوێندنەوە
  try {
    await res.body?.cancel()
  } catch { /* پشتگوێخستن */ }

  if (res.status === 404) throw new Error('فایلەکە نەدۆزرایەوە — لەوانەیە سڕدرابێتەوە یان بەستەرەکە هەڵە بێت')
  if (res.status === 403 || res.status === 401 || (res.redirected && /accounts\.google\.com/i.test(res.url))) {
    throw new Error('فایلەکە گشتی نییە — لە Drive بیبەرەوە بە «هەر کەسێک بە بەستەر»')
  }
  if (!res.ok && res.status !== 206) {
    throw new Error('فایلەکە وەڵام نەدایەوە — دووبارە هەوڵ بدە')
  }
}

function decodeEntities(s: string): string {
  return s
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ')
}

// وەرگێڕانی هەڵەی تۆڕ بۆ کوردی — هاوشێوەی m3u.ts
function netErrMsg(e: unknown): string {
  const m = e instanceof Error ? e.message : String(e)
  if (/fetch failed|ENOTFOUND|EAI_AGAIN|getaddrinfo/i.test(m)) {
    return 'نەکرا پەیوەندی بە Google Drive بکرێت — ئینتەرنێت پشکنین بکە'
  }
  if (/abort|timeout|timed out/i.test(m)) {
    return 'Google Drive زۆر درەنگ وەڵامی دایەوە — دووبارە هەوڵ بدە'
  }
  return m
}
