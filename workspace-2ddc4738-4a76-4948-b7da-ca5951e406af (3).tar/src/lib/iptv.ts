// کتێبخانەی هاوبەشی ئەپی تیڤی — جۆرەکان و یارمەتیدەرەکان

export type PlayKind = 'hls' | 'direct'

export interface PlayItem {
  kind: 'live' | 'movie' | 'series' | 'm3u'
  itemId: string
  name: string
  logo?: string | null
  url: string
  playKind: PlayKind
  extra?: Record<string, unknown>
  // داواکاری بەستەری پەخش لە سێرڤەرەوە (بۆ Xtream)
  streamRequest?: { type: 'live' | 'movie' | 'series'; id: string; ext?: string }
}

// کۆنتێکستی لیستی پەخش — بۆ گۆڕینی کەناڵ بە ڕیمۆت (کەناڵی دواتر/پێشتر — وەک CH+ / CH- ی تیڤی)
export interface PlayListContext {
  // لیستی تەواوی کەناڵە ئەرێنییەکان (ئەو لیستەی بەکارهێنەر لە شاشەی کەناڵەکان دەیبینێت)
  list: PlayItem[]
  // ژمارەی کەناڵی ئێستا لە لیستەکەدا
  index: number
  // ئایا لیستەکە کەناڵی زیندووە — بۆ M3U پێویستە چونکە kind ی 'm3u' لە هەردوو شاشەی کەناڵ و فلیم بەکار دەهێنرێت
  live?: boolean
}

export interface XtreamCategory {
  category_id: string
  category_name: string
  parent_id?: number
}

export interface XtreamLiveStream {
  num: number
  name: string
  stream_type: string
  stream_id: number
  stream_icon: string
  epg_channel_id: string
  added: string
  category_id: string
  custom_sid?: string
  tv_archive?: number
  direct_source?: string
  tv_archive_duration?: number
}

export interface XtreamVodStream {
  num: number
  name: string
  stream_type: string
  stream_id: number
  stream_icon: string
  rating?: string
  added: string
  category_id: string
  container_extension: string
  custom_sid?: string
  direct_source?: string
}

export interface XtreamSeries {
  num: number
  name: string
  series_id: number
  cover: string
  plot?: string
  cast?: string
  director?: string
  genre?: string
  releaseDate?: string
  last_modified?: string
  rating?: string
  rating_5based?: number
  category_id: string
}

export interface XtreamEpgEntry {
  title: string
  lang: string
  start: string
  end: string
  description: string
  channel_id: string
  start_timestamp: string
  stop_timestamp: string
}

export interface M3UChannel {
  name: string
  logo: string
  group: string
  url: string
  tvgId: string
  kind: 'live' | 'movie' | 'series'
}

export interface AppSettingsStatus {
  configured: boolean
  appName: string
  mode: 'xtream' | 'm3u' | null
  host: string | null
  username: string | null
  m3uUrl: string | null
  hasAdminPin?: boolean
  isAdmin?: boolean
  expiryDate: string | null
  activeConnections: string | null
  maxConnections: string | null
  status: string | null
}

// ---- یارمەتیدەرەکانی کلاینت ----

export function imgProxy(url?: string | null): string | null {
  if (!url || !/^https?:\/\//i.test(url)) return null
  return `/api/proxy?url=${encodeURIComponent(url)}&k=img`
}

export function streamProxy(url: string): string {
  return `/api/proxy?url=${encodeURIComponent(url)}`
}

export function formatKuDate(value?: string | null): string {
  if (!value) return '—'
  const d = new Date(value)
  if (isNaN(d.getTime())) return value
  return d.toLocaleDateString('ckb-IQ', { year: 'numeric', month: 'long', day: 'numeric' })
}

export function tsToTime(ts?: string | null): string {
  if (!ts) return ''
  const n = Number(ts)
  if (!n) return ''
  return new Date(n * 1000).toLocaleTimeString('ckb-IQ', { hour: '2-digit', minute: '2-digit' })
}
